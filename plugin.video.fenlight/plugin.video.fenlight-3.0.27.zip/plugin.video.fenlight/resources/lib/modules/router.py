# -*- coding: utf-8 -*-
from modules.kodi_utils import external, mark_phase, parse_qsl
# from modules.kodi_utils import logger

def sys_exit_check(): return external()

def _text_search_start(params, media_type):
	search_scope = params.get('search_hub')
	if search_scope not in ('true', 'combined', 'standard'): return None
	if search_scope == 'true': search_scope = 'standard'
	query = params.get('query', '')
	if not query: return None
	from xbmcgui import Window
	win = Window(10000)
	if win.getProperty('FenLight.TextSearch.Query') != query:
		try:
			from modules.search import save_text_query, _slog
			sealed_pick = win.getProperty('FenLight.TextSearch.SealNext') == '1'
			_slog('_text_search_start: nuova query="%s" scope=%s sealed_pick=%s' % (query, search_scope, sealed_pick))
			if sealed_pick: win.clearProperty('FenLight.TextSearch.SealNext')
			save_text_query(query, sealed_pick=sealed_pick)
			win.setProperty('FenLight.SearchHistory.Token', query)
		except: pass
		win.setProperty('FenLight.TextSearch.Query', query)
		win.setProperty('FenLight.TextSearch.Scope', search_scope)
		win.setProperty('FenLight.TextSearch.Movie.HasResults', 'false')
		win.setProperty('FenLight.TextSearch.TV.HasResults', 'false')
		win.clearProperty('FenLight.TextSearch.Movie.State')
		win.clearProperty('FenLight.TextSearch.TV.State')
		if search_scope == 'standard':
			win.setProperty('FenLight.TextSearch.Movie.State', 'loading')
			win.setProperty('FenLight.TextSearch.TV.State', 'loading')
	win.setProperty('FenLight.TextSearch.%s.State' % media_type, 'loading')
	win.setProperty('FenLight.TextSearch.State', 'loading')
	return win

def _search_debounce_abort(sys, params, action_filtered):
	# Debounce gate for the live search hub, run BEFORE _text_search_start so a superseded keystroke's
	# build never touches the skin state nor builds anything. paginator.search_should_abort waits the
	# debounce window and compares this build's query against the live search-box text; if they differ
	# the user has moved on -> close the (now-irrelevant) directory empty and bail.
	if params.get('action') != action_filtered or not params.get('search_hub'): return False
	from modules import paginator
	from modules.kodi_utils import get_property, end_directory
	# A watcher-driven pagination step or a global soft refresh rebuilds the SAME query in place; never
	# debounce those -- it would lag infinite-scroll and (via the Settled gate) hide the row mid-scroll.
	# Only a genuine query change is debounced.
	key = paginator.widget_key(params)
	if paginator.is_loading(key) or get_property(paginator.PG_REFRESH_PROP) == 'true':
		return False
	if not paginator.search_should_abort(params.get('query', '')): return False
	try: end_directory(int(sys.argv[1]), cacheToDisc=False)
	except: pass
	return True

def _text_search_done(win, query, media_type, num_items):
	if not win or win.getProperty('FenLight.TextSearch.Query') != query: return
	win.setProperty('FenLight.TextSearch.%s.State' % media_type, 'done')
	win.setProperty('FenLight.TextSearch.%s.HasResults' % media_type, 'true' if num_items else 'false')
	# Settled = the query whose results are actually on screen now. The skin shows the result rows only
	# while Settled matches the live search box, so a query change hides the (stale-positioned) row and
	# lets it rebuild fresh at item 0; a pagination refresh keeps Settled == query, so scrolling is
	# untouched. Set here (build done & current) rather than at _text_search_start, which also fires for
	# in-place pagination refreshes.
	win.setProperty('FenLight.TextSearch.Settled', query)
	if win.getProperty('FenLight.TextSearch.Scope') == 'combined':
		win.setProperty('FenLight.TextSearch.State', 'done')
		return
	movie_done = win.getProperty('FenLight.TextSearch.Movie.State') == 'done'
	tv_done = win.getProperty('FenLight.TextSearch.TV.State') == 'done'
	if movie_done and tv_done: win.setProperty('FenLight.TextSearch.State', 'done')

def routing(sys):
	# Marcatore (lotto 50 ter): da qui a mark_phase('indexer_in') c'e' SOLO il parsing dei parametri e
	# l'import PIGRO del modulo indexer. E' il taglio che separa "caricare i moduli" da "fare il
	# lavoro", dentro i ~10 s che nessuno strumento vedeva. Timbrato solo sui rami usati all'avvio e
	# nella navigazione serie: non serve sporcare tutti i trenta rami per rispondere a una domanda.
	mark_phase('routing_in')
	params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
	_get = params.get
	mode = _get('mode', 'navigator.main')
	# QUI C'ERA IL CANCELLO RIPRODUZIONE (lotto 111, rimosso col lotto 113).
	# Chiudeva la cartella con succeeded=False quando un widget veniva ricostruito durante la
	# riproduzione. Funzionava -- 18 invocazioni tagliate su tre film, da 5-6 s a 150-280 ms l'una --
	# ma la misura successiva ha spostato la domanda: contando i risvegli dei CDirectoryProvider per
	# fase, i provider si svegliano PRIMA del passaggio a schermo intero e DOPO Player.OnStop, e
	# ZERO volte durante il fullscreen (crash_film 5/0/0, sess_ok 5/0/40, sess_112 3/0/21). Kodi non
	# aggiorna da se' un provider che non e' visibile: la CPU durante il film era gia' tutta della
	# riproduzione, e il cancello non stava proteggendo il film ma solo i pochi secondi di
	# transizione in cui la home e' ancora a schermo. In cambio svuotava il contenitore -- non
	# esiste nessun modo, nell'API dei plugin, di chiudere una cartella dicendo "tieni quello che
	# hai": qualunque cosa diversa da un elenco completo e riuscito lascia il widget senza elementi.
	# Da qui la paginazione persa, il fuoco al primo elemento e la ricostruzione totale al ritorno.
	# La transizione ora si affronta marcandola come refresh IN POSTO (vedi 'playback.media' qui
	# sotto e Player.OnStop in service.py), non tagliandola.
	if 'navigator.' in mode:
		from indexers.navigator import Navigator
		return getattr(Navigator(params), mode.split('.')[1])()
	if 'menu_editor.' in mode:
		from modules.menu_editor import MenuEditor
		return getattr(MenuEditor(params), mode.split('.')[1])()
	if 'easynews.' in mode:
		from indexers import easynews
		return getattr(easynews, mode.split('.')[1])(params)
	if 'playback.' in mode:
		if mode == 'playback.media':
			# MARCATORE IN POSTO (lotto 113). Questo e' l'istante del Select: si apre
			# sources_playback.xml, la home passa in secondo piano e Kodi reinvalida i suoi
			# CDirectoryProvider. Senza marcatore _get_pages_legacy tratta quelle ricostruzioni come
			# l'APERTURA di un widget nuovo e torna al default (2 pagine). Nel log del 29/08 alle
			# 17:46:50 un contenitore da 101 elementi e' cosi' tornato a 50 col fuoco sul primo --
			# NOVE secondi prima di Player.OnPlay, cioe' la paginazione si perdeva gia' al Select,
			# anche senza arrivare a riprodurre niente. Il cancello non poteva vederlo: la bandiera
			# di riproduzione si alza molto dopo.
			from modules.kodi_utils import mark_inplace_rebuild
			mark_inplace_rebuild()
			from modules.sources import Sources
			return Sources().playback_prep(params)
		if mode == 'playback.video':
			from modules.player import FenLightPlayer
			return FenLightPlayer().run(_get('url', None), _get('obj', None))
	if 'choice' in mode:
		from indexers import dialogs
		return getattr(dialogs, mode)(params)
	if 'custom_key.' in mode:
		from modules import custom_keys
		return getattr(custom_keys, mode.split('custom_key.')[1])()
	if 'advancedsettings.' in mode:
		from modules import advanced_settings
		return getattr(advanced_settings, mode.split('.')[1])(params)
	if 'trakt.' in mode:
		if '.list' in mode:
			from indexers import trakt_lists
			return getattr(trakt_lists, mode.split('.')[2])(params)
		from apis import trakt_api
		return getattr(trakt_api, mode.split('.')[1])(params)
	if 'mdblist.' in mode:
		if '.list' in mode:
			from indexers import mdblist_lists
			mark_phase('indexer_in')
			return getattr(mdblist_lists, mode.split('.')[2])(params)
		from apis import mdblist_api
		return getattr(mdblist_api, mode.split('.')[1])(params)
	if 'build' in mode:
		if mode == 'build_movie_list':
			if _get('action') == 'tmdb_movies_search' and _get('search_hub'): params['action'] = 'tmdb_movies_search_filtered'
			if _search_debounce_abort(sys, params, 'tmdb_movies_search_filtered'): return
			search_win = _text_search_start(params, 'Movie') if _get('action') == 'tmdb_movies_search_filtered' else None
			if _get('action') in ('tmdb_movies_search', 'tmdb_movies_search_filtered') and _get('query', ''):
				from xbmcgui import Window
				Window(10000).clearProperty('FenLight.Discover.ContentPath')
			from indexers.movies import Movies
			movies = Movies(params)
			result = movies.fetch_list()
			_text_search_done(search_win, _get('query', ''), 'Movie', len(movies.list))
			return result
		if mode == 'build_tvshow_list':
			if _get('action') == 'tmdb_tv_search' and _get('search_hub'): params['action'] = 'tmdb_tv_search_filtered'
			if _search_debounce_abort(sys, params, 'tmdb_tv_search_filtered'): return
			search_win = _text_search_start(params, 'TV') if _get('action') == 'tmdb_tv_search_filtered' else None
			if _get('action') in ('tmdb_tv_search', 'tmdb_tv_search_filtered') and _get('query', ''):
				from xbmcgui import Window
				Window(10000).clearProperty('FenLight.Discover.ContentPath')
			from indexers.tvshows import TVShows
			tvshows = TVShows(params)
			result = tvshows.fetch_list()
			_text_search_done(search_win, _get('query', ''), 'TV', len(tvshows.list))
			return result
		if mode == 'build_season_list':
			from indexers.seasons import build_season_list
			mark_phase('indexer_in')
			return build_season_list(params)
		if mode == 'build_episode_list':
			from indexers.episodes import build_episode_list
			mark_phase('indexer_in')
			return build_episode_list(params)
		if mode == 'build_in_progress_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.progress', params)
		if mode == 'build_recently_watched_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.recently_watched', params)
		if mode == 'build_next_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.next', params)
		if mode == 'build_continue_watching':
			from indexers.continue_watching import build_continue_watching
			mark_phase('indexer_in')
			return build_continue_watching(params)
		if mode == 'build_my_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.trakt', params)
		if mode == 'build_next_episode_manager':
			from modules.episode_tools import build_next_episode_manager
			return build_next_episode_manager()
		if mode == 'build_tmdb_people':
			from indexers.people import tmdb_people
			return tmdb_people(params)
		if mode == 'build_cast_list':
			from indexers.people import build_cast_list
			return build_cast_list(params)
		if 'random.' in mode:
			from indexers.random_lists import RandomLists
			return RandomLists(params).run_random()
	if 'watched_status.' in mode:
		if mode == 'watched_status.mark_episode':
			from modules.watched_status import mark_episode
			return mark_episode(params)
		if mode == 'watched_status.mark_season':
			from modules.watched_status import mark_season
			return mark_season(params)
		if mode == 'watched_status.mark_tvshow':
			from modules.watched_status import mark_tvshow
			return mark_tvshow(params)
		if mode == 'watched_status.mark_movie':
			from modules.watched_status import mark_movie
			return mark_movie(params)
		if mode == 'watched_status.erase_bookmark':
			from modules.watched_status import erase_bookmark
			return erase_bookmark(_get('media_type'), _get('tmdb_id'), _get('season', ''), _get('episode', ''), _get('refresh', 'false'))
	if 'search.' in mode:
		if mode == 'search.get_key_id':
			from modules.search import get_key_id
			return get_key_id(params)
		if mode == 'search.clear_search':
			from modules.search import clear_search
			return clear_search()
		if mode == 'search.clear_text_history':
			from modules.search import clear_text_history
			return clear_text_history()
		if mode == 'search.close_panel':
			from modules.search import close_search_panel
			close_search_panel(params.get('source', '?'))
			# Invocato come content-directory dal container rilevatore: chiudo la directory (vuota).
			try:
				import xbmcplugin
				xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
			except: pass
			return
		if mode == 'search.remove':
			from modules.search import remove_from_search
			return remove_from_search(params)
		if mode == 'search.clear_all':
			from modules.search import clear_all
			return clear_all(_get('setting_id'), _get('refresh', 'false'))
		if mode == 'search.select_discover_filter':
			from modules.search import select_discover_filter
			return select_discover_filter(params)
		if mode == 'search.launch_discover':
			from modules.search import launch_discover
			return launch_discover(params)
		if mode == 'search.clear_discover_filters':
			from modules.search import clear_discover_filters
			return clear_discover_filters(params)
		if mode == 'search.add_to_history':
			from modules.search import add_to_history
			return add_to_history(params)
	if 'real_debrid' in mode:
		if mode == 'real_debrid.rd_cloud':
			from indexers.real_debrid import rd_cloud
			return rd_cloud()
		if mode == 'real_debrid.rd_downloads':
			from indexers.real_debrid import rd_downloads
			return rd_downloads()
		if mode == 'real_debrid.browse_rd_cloud':
			from indexers.real_debrid import browse_rd_cloud
			return browse_rd_cloud(_get('id'))
		if mode == 'real_debrid.resolve_rd':
			from indexers.real_debrid import resolve_rd
			return resolve_rd(params)
		if mode == 'real_debrid.rd_account_info':
			from indexers.real_debrid import rd_account_info
			return rd_account_info()
		if mode == 'real_debrid.authenticate':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().auth()
		if mode == 'real_debrid.revoke_authentication':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().revoke()
		if mode == 'real_debrid.delete':
			from indexers.real_debrid import rd_delete
			return rd_delete(_get('id'), _get('cache_type'))
	if 'premiumize' in mode:
		if mode == 'premiumize.pm_cloud':
			from indexers.premiumize import pm_cloud
			return pm_cloud(_get('id', None), _get('folder_name', None))
		if mode == 'premiumize.pm_transfers':
			from indexers.premiumize import pm_transfers
			return pm_transfers()
		if mode == 'premiumize.pm_account_info':
			from indexers.premiumize import pm_account_info
			return pm_account_info()
		if mode == 'premiumize.authenticate':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().auth()
		if mode == 'premiumize.revoke_authentication':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().revoke()
		if mode == 'premiumize.rename':
			from indexers.premiumize import pm_rename
			return pm_rename(_get('file_type'), _get('id'), _get('name'))
		if mode == 'premiumize.delete':
			from indexers.premiumize import pm_delete
			return pm_delete(_get('file_type'), _get('id'))
	if 'alldebrid' in mode:
		if mode == 'alldebrid.ad_cloud':
			from indexers.alldebrid import ad_cloud
			return ad_cloud(_get('id', None))
		if mode == 'alldebrid.browse_ad_cloud':
			from indexers.alldebrid import browse_ad_cloud
			return browse_ad_cloud(_get('folder'))
		if mode == 'alldebrid.resolve_ad':
			from indexers.alldebrid import resolve_ad
			return resolve_ad(params)
		if mode == 'alldebrid.ad_account_info':
			from indexers.alldebrid import ad_account_info
			return ad_account_info()
		if mode == 'alldebrid.authenticate':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().auth()
		if mode == 'alldebrid.revoke_authentication':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().revoke()
		if mode == 'alldebrid.delete':
			from indexers.alldebrid import ad_delete
			return ad_delete(_get('id'))
	if 'offcloud' in mode:
		if mode == 'offcloud.oc_cloud':
			from indexers.offcloud import oc_cloud
			return oc_cloud()
		if mode == 'offcloud.browse_oc_cloud':
			from indexers.offcloud import browse_oc_cloud
			return browse_oc_cloud(_get('folder_id'))
		if mode == 'offcloud.resolve_oc':
			from indexers.offcloud import resolve_oc
			return resolve_oc(params)
		if mode == 'offcloud.oc_account_info':
			from indexers.offcloud import oc_account_info
			return oc_account_info()
		if mode == 'offcloud.authenticate':
			from apis.offcloud_api import OffcloudAPI
			return OffcloudAPI().auth()
		if mode == 'offcloud.revoke_authentication':
			from apis.offcloud_api import OffcloudAPI
			return OffcloudAPI().revoke()
		if mode == 'offcloud.delete':
			from indexers.offcloud import oc_delete
			return oc_delete(_get('folder_id'))
	if 'easydebrid' in mode:
		if mode == 'easydebrid.authenticate':
			from apis.easydebrid_api import EasyDebridAPI
			return EasyDebridAPI().auth()
		if mode == 'easydebrid.revoke_authentication':
			from apis.easydebrid_api import EasyDebridAPI
			return EasyDebridAPI().revoke()
	if 'torbox' in mode:
		if mode == 'torbox.tb_cloud':
			from indexers.torbox import tb_cloud
			return tb_cloud()
		if mode == 'torbox.browse_tb_cloud':
			from indexers.torbox import browse_tb_cloud
			return browse_tb_cloud(_get('folder_id'), _get('media_type'))
		if mode == 'torbox.resolve_tb':
			from indexers.torbox import resolve_tb
			return resolve_tb(params)
		if mode == 'torbox.tb_account_info':
			from indexers.torbox import tb_account_info
			return tb_account_info()
		if mode == 'torbox.authenticate':
			from apis.torbox_api import TorBoxAPI
			return TorBoxAPI().auth()
		if mode == 'torbox.revoke_authentication':
			from apis.torbox_api import TorBoxAPI
			return TorBoxAPI().revoke()
		if mode == 'torbox.delete':
			from indexers.torbox import tb_delete
			return tb_delete(_get('folder_id'), _get('media_type'))
	if '_cache' in mode:
		from caches import base_cache
		if mode == 'clear_cache':
			return base_cache.clear_cache(_get('cache'))
		if mode == 'clear_all_cache':
			return base_cache.clear_all_cache()
		if mode == 'clean_databases_cache':
			return base_cache.clean_databases()
		if mode == 'check_databases_integrity_cache':
			return base_cache.check_databases_integrity()
	if '_image' in mode:
		from indexers.images import Images
		return Images().run(params)
	if '_text' in mode:
		if mode == 'show_text':
			from modules.kodi_utils import show_text
			return show_text(_get('heading'), _get('text', None), _get('file', None), _get('font_size', 'small'), _get('kodi_log', 'false') == 'true')
		if mode == 'show_text_media':
			from modules.kodi_utils import show_text_media
			return show_text(_get('heading'), _get('text', None), _get('file', None), _get('meta'), {})
	if 'settings_manager.' in mode:
		from caches import settings_cache
		return getattr(settings_cache, mode.split('.')[1])(params)
	if 'downloader.' in mode:
		from modules import downloader
		return getattr(downloader, mode.split('.')[1])(params)
	##EXTRA modes##
	if mode == 'set_view':
		from modules.kodi_utils import set_view
		return kodi_utils.set_view(_get('view_type'))
	if mode == 'fen_blur': 
		from modules.blur_service import blur_image
		return blur_image(params)
	if mode == 'sync_settings':
		from caches.settings_cache import sync_settings
		return sync_settings(params)
	if mode == 'person_direct.search':
		from indexers.people import person_direct_search
		return person_direct_search(_get('key_id') or _get('query'))
	if mode == 'kodi_refresh':
		from modules.kodi_utils import kodi_refresh
		return kodi_refresh(_get('coalesce', 'true') != 'false')
	if mode == 'kodi_refresh_ids':
		# Ricarica mirata a partire da un elenco di tmdb_id (lotto 59): la usa il monitor Trakt, che
		# dopo la ricostruzione sa quali titoli sono cambiati. Se l'elenco arriva vuoto kodi_refresh_ids
		# ricade da sola sul globale, quindi non puo' comportarsi peggio di prima.
		from modules.kodi_utils import kodi_refresh_ids
		return kodi_refresh_ids([i for i in _get('ids', '').split(',') if i], coalesce=_get('coalesce', 'true') != 'false')
	if mode == 'refresh_widgets':
		from modules.kodi_utils import refresh_widgets
		# user=true lo mette solo la voce di menu degli indexer, non il servizio.
		return refresh_widgets(_get('show_notification', 'false'), _get('user', 'false') != 'true')
	if mode == 'person_data_dialog':
		from indexers.people import person_data_dialog
		return person_data_dialog(params)
	if mode == 'favorite_people':
		from indexers.people import favorite_people
		return favorite_people()
	if mode == 'manual_add_magnet_to_cloud':
		from modules.debrid import manual_add_magnet_to_cloud
		return manual_add_magnet_to_cloud(params)
	if mode == 'upload_logfile':
		from modules.kodi_utils import upload_logfile
		return upload_logfile(params)
	if mode == 'toggle_language_invoker':
		from modules.kodi_utils import toggle_language_invoker
		return toggle_language_invoker()
	if mode == 'set_videoinfo_properties':
		from modules.skin_properties import set_videoinfo_properties
		return set_videoinfo_properties(params)
	if mode == 'build_person_credits_list':
			from indexers.people import build_person_credits_list
			return build_person_credits_list(params)
	if mode == 'open_media_info':
		from modules.skin_properties import open_media_info
		return open_media_info(params)
	if mode == 'browse_media': 
		from modules.skin_properties import browse_media
		return browse_media(params)
	if mode == 'downloader':
		from modules.downloader import runner
		return runner(params)
	if mode == 'debrid.browse_packs':
		from modules.sources import Sources
		return Sources().debridPacks(_get('provider'), _get('name'), _get('magnet_url'), _get('info_hash'))
	if mode == 'open_settings':
		from modules.kodi_utils import open_settings
		return open_settings()
	if mode == 'hide_unhide_progress_items':
		from modules.watched_status import hide_unhide_progress_items
		hide_unhide_progress_items(params)
	if mode == 'open_external_scraper_settings':
		from modules.kodi_utils import external_scraper_settings
		return external_scraper_settings()
