# -*- coding: utf-8 -*-
import re
import sys
import time
import hashlib
import unicodedata
import os
# Lock dal builtin _thread (lotto 101): e' lo stesso oggetto che espone threading.Lock, ma senza
# leggere threading.py. Thread invece e' vero threading e si importa dentro _run_pool, DOPO il
# controllo sulla lista vuota: a cache calda `missing` e' vuoto e nessun thread nasce mai, quindi
# quell'import non si paga. Vedi la nota in caches/base_cache.py.
from _thread import allocate_lock as Lock
# Import resi pigri (lotto 54). Misurato sulla stick, per OGNI interprete widget:
#   concurrent.futures -> tirava dentro logging -> traceback -> contextlib, textwrap,
#     linecache, tokenize, token, weakref. Nessuno di questi e' importato altrove in Fen Light:
#     esistevano tutti per questa sola riga. Sostituito, non reso pigro, perche' i pool stanno sul
#     percorso caldo e renderlo pigro avrebbe solo spostato il costo. Vedi _run_pool.
#   html (unescape)  -> html + html.entities, ~230 ms, per un solo uso in replace_html_codes
#   zipfile          -> tirava dentro importlib, ~100-200 ms, per un solo uso in extract_zip
#   importlib        -> usato solo dai tre helper manual_*_import
#   random           -> tirava dentro _sha512, ~160 ms, per il solo ordinamento casuale
#   _strptime        -> tirava dentro locale + _locale + calendar, ~400 ms: vedi
#     _parse_fixed_datetime, che analizza i tre formati fissi senza strptime
from datetime import datetime, timedelta, date
from modules.kodi_utils import translate_path, sleep, show_busy_dialog, hide_busy_dialog, path_exists

# Numero di worker dei pool: cpu_count + 2, con tetto per i dispositivi a poca RAM.
# E' stata provata un'impostazione utente per fissarlo a mano ed e' stata tolta: dal momento in cui la
# costruzione delle listitem gira in SEQUENZA (vedi indexers/movies.py), questi pool servono solo alla
# fase di RETE, dove l'attesa e' I/O e il GIL e' rilasciato davvero. Li' abbassare i worker non aiuta,
# serializza soltanto: con 2 worker una pagina di 20 elementi non in cache fa 10 giri di rete invece di 2.
WORKER_COUNT = max(4, min((os.cpu_count() or 4) + 2, 10))
# from modules.kodi_utils import logger

def change_image_resolution(image, replace_res):
	return re.sub(r'(w185|w300|w342|w780|w1280|h632|original)', replace_res, image)

def append_module_to_syspath(location):
	sys.path.append(translate_path(location))

def install_lazy_chardet():
	"""Rimanda chardet finche' qualcuno non lo usa davvero. Lotto 178, gemello del lotto 84.

	Il lotto 84 tolse `requests` da DENTRO Fen Light e lo sostitui' con http_client, misurando 337
	moduli contro 66. Ma cocoscrapers continua a importarlo (`modules/client.py:8`), e con lui arriva
	chardet, che sulla stick pesa 1 107 804 byte di sorgente su 48 file: piu' di requests (179 KB) e
	urllib3 (394 KB) messi insieme.

	Come ci entra, e perche' e' sprecato:

	    requests/compat.py:11     import chardet
	    chardet/__init__.py:24    from .universaldetector import UniversalDetector

	e universaldetector tira dentro ogni modello di lingua -- langbulgarianmodel, langgreekmodel,
	langhebrewmodel, langrussianmodel, langthaimodel, langturkishmodel, johabfreq -- che sono tabelle
	di frequenza enormi. Servono a UNA cosa sola: `Response.apparent_encoding`
	(requests/models.py:793), cioe' indovinare la codifica quando la risposta non la dichiara. E'
	esattamente cio' che il commento in cima a http_client.py chiamava "quello che si paga per
	niente".

	Misura del 07/09, log delle 01:3x, `playback.media`: 284 moduli, 2592 ms, cpu 89%. La riga
	'quando' del profilatore dice che il 75% del costo sta dopo il modulo 77, cioe' dopo tutto
	l'albero di Fen Light, e le tappe si chiamano `zstandard` e `codingstatemachine` -- quest'ultimo
	e' chardet.

	COSA FA. Mette in sys.modules un modulo finto PRIMA che cocoscrapers importi requests. Espone
	__version__ (che requests legge subito, per il controllo di compatibilita' in __init__.py:53) e
	__path__, e delega qualunque altro attributo al chardet vero, importandolo in quel momento. Se
	un giorno una risposta senza charset arriva davvero, `chardet.detect` lo carica e funziona come
	prima: si sposta il costo, non si toglie una funzione.

	La versione si legge da chardet/version.py senza eseguire __init__.py -- find_spec localizza il
	pacchetto e basta. Se qualcosa non torna la funzione NON installa niente e si resta come prima:
	non e' un percorso su cui valga la pena essere coraggiosi.
	"""
	if 'chardet' in sys.modules: return False
	try:
		import re as _re
		from importlib.util import find_spec
		spec = find_spec('chardet')
		if not spec or not spec.submodule_search_locations: return False
		cartella = list(spec.submodule_search_locations)[0]
		with open(os.path.join(cartella, 'version.py'), encoding='utf-8') as f:
			trovato = _re.search(r"__version__\s*=\s*[\"']([^\"']+)", f.read())
		if not trovato: return False
		versione = trovato.group(1)
	except Exception: return False
	try:
		from types import ModuleType
		vero = []
		def _carica():
			if not vero:
				from importlib import import_module
				sys.modules.pop('chardet', None)
				modulo = import_module('chardet')
				sys.modules['chardet'] = modulo
				vero.append(modulo)
			return vero[0]
		finto = ModuleType('chardet')
		finto.__version__ = versione
		finto.VERSION = versione.split('.')
		finto.__path__ = [cartella]
		finto.__file__ = os.path.join(cartella, '__init__.py')
		finto.__getattr__ = lambda nome: getattr(_carica(), nome)
		sys.modules['chardet'] = finto
		return True
	except Exception:
		sys.modules.pop('chardet', None)
		return False

def manual_function_import(location, function_name):
	from importlib import import_module
	return getattr(import_module(location), function_name)

def reload_module(location):
	from importlib import reload as rel_module
	return rel_module(manual_module_import(location))

def manual_module_import(location):
	from importlib import import_module
	return import_module(location)

class _Done:
	__slots__ = ()
	def join(self): pass

_DONE = (_Done(),)

def _run_pool(_target, _list, _style, _max_workers=None):
	# Rimpiazzo di ThreadPoolExecutor con i soli `threading.Thread` (lotto 54). Semantica da
	# preservare, verificata sull'originale:
	#  - concorrenza limitata a WORKER_COUNT, distribuzione DINAMICA (un contatore condiviso, non una
	#    partizione statica: con lavori di durata diversa la partizione statica lascia thread fermi);
	#  - la chiamata BLOCCA fino al termine di tutto, come faceva l'uscita dal blocco `with`;
	#  - le eccezioni del target vengono INGHIOTTITE. Non e' una svista da correggere: submit() le
	#    depositava in una Future che nessun chiamante legge mai, quindi il comportamento osservabile
	#    era gia' questo. Cambiarlo qui vorrebbe dire far emergere errori finora invisibili in
	#    tutt'altro punto del programma.
	if not isinstance(_list, (list, tuple)): _list = list(_list)
	total = len(_list)
	if not total: return _DONE
	# Import pigro: da qui in giu' i thread nascono davvero, quindi threading serve davvero.
	from threading import Thread
	next_index, lock = [0], Lock()
	def _worker():
		while True:
			with lock:
				index = next_index[0]
				if index >= total: return
				next_index[0] = index + 1
			try:
				item = _list[index]
				if _style == 0: _target(item)
				elif _style == 1: _target(*item)
				else: _target(index, item)
			except: pass
	# _max_workers: tetto piu' basso per fasi che aprono connessioni invece di macinare dati (vedi
	# metadata.DUB_NET_WORKERS). Omesso, resta il comportamento di sempre.
	_cap = WORKER_COUNT if not _max_workers else min(WORKER_COUNT, _max_workers)
	workers = [Thread(target=_worker) for _ in range(min(_cap, total))]
	for worker in workers: worker.start()
	for worker in workers: worker.join()
	return _DONE

def make_thread_list(_target, _list):
	return _run_pool(_target, _list, 0)

def make_thread_list_multi_arg(_target, _list):
	return _run_pool(_target, _list, 1)

def make_thread_list_enumerate(_target, _list):
	return _run_pool(_target, _list, 2)

def make_thread_list_enumerate_capped(_target, _list, max_workers):
	# Come make_thread_list_enumerate ma con un tetto proprio di worker. Serve dove il lavoro e' misto:
	# un po' di attesa su SQLite, che i thread sovrappongono davvero, e molto Python e API C++, che
	# invece si fanno la coda sul GIL e peggiorano al crescere dei worker. Misurato su
	# build_single_episode il 25/08 (lotti 79-80): a 6 worker 4422 ms di CPU per 802 ms di parete, a 1
	# worker 1056 per 1056. I due costi si muovono in direzioni opposte, quindi il numero giusto non
	# sta a nessuno dei due estremi.
	return _run_pool(_target, _list, 2, max_workers)

def chunks(item_list, limit):
	"""
	Yield successive limit-sized chunks from item_list.
	"""
	for i in range(0, len(item_list), limit): yield item_list[i:i + limit]

def string_to_float(string, default_return):
	"""
	Remove all alpha from string and return a float.
	Returns float of "default_return" upon ValueError.
	"""
	try: return float(''.join(c for c in string if (c.isdigit() or c =='.')))
	except ValueError: return float(default_return)

def string_alphanum_to_num(string):
	"""
	Remove all alpha from string and return remaining string.
	Returns original string upon ValueError.
	"""
	try: return ''.join(c for c in string if c.isdigit())
	except ValueError: return string

def jsondate_to_datetime(jsondate_object, resformat, remove_time=False):
	if not jsondate_object: return None
	if remove_time: datetime_object = datetime_workaround(jsondate_object, resformat).date()
	else: datetime_object = datetime_workaround(jsondate_object, resformat)
	return datetime_object

def get_datetime(string=False, dt=False):
	d = datetime.now()
	if dt: return d
	if string: return d.strftime('%Y-%m-%d')
	return datetime.date(d)

def get_current_timestamp():
	return int(time.time())
	
def adjust_premiered_date(orig_date, adjust_hours):
	if not orig_date: return None, None
	orig_date += ' 20:00:00'
	datetime_object = jsondate_to_datetime(orig_date, '%Y-%m-%d %H:%M:%S')
	adjusted_datetime = datetime_object + timedelta(hours=adjust_hours)
	adjusted_string = adjusted_datetime.strftime('%Y-%m-%d')
	return adjusted_datetime.date(), adjusted_string

def make_day(today, date, date_format='%Y-%m-%d', use_words=True):
	if use_words:
		day_diff = (date - today).days
		if day_diff == -1: day = 'YESTERDAY'
		elif day_diff == 0: day = 'TODAY'
		elif day_diff == 1: day = 'TOMORROW'
		elif 1 < day_diff < 7: day = date.strftime('%A').upper()
		else:
			try: day = date.strftime(date_format)
			except ValueError: day = date.strftime('%Y-%m-%d')
	else:
		try: day = date.strftime(date_format)
		except ValueError: day = date.strftime('%Y-%m-%d')
	return day

def subtract_dates(date1, date2):
	return (date1 - date2).days
	return day

# Fen Light analizza date in TRE soli formati, tutti a campi fissi e interamente numerici:
# '%Y-%m-%d', '%Y-%m-%d %H:%M:%S' e '%Y-%m-%dT%H:%M:%S.%fZ'. Interpretarli a fette di stringa evita
# strptime, e con strptime l'import di _strptime -> locale -> _locale -> calendar: quattro file che a
# cache fredda misuravano ~400 ms complessivi, per leggere 'YYYY-MM-DD'.
# Il ramo veloce e' DELIBERATAMENTE severo: al minimo scostamento (lunghezza, separatori, cifre) torna
# None e si passa a strptime, cosi' un formato inatteso non viene interpretato a caso ma solo piu'
# lentamente. Il vecchio `import _strptime` in testa al modulo esisteva per la nota corsa di CPython
# quando strptime viene invocata per la prima volta da piu' thread insieme: quella garanzia serve
# ancora al ramo di ripiego, e ora e' data dal lock invece che da un import pagato sempre.
_STRPTIME_LOCK = Lock()

def _ascii_digits(*fields):
	# int() e' piu' permissivo del formato: accetta segno, spazi e trattini bassi ('+026', '2_26'),
	# che strptime rifiuta. Restringere a sole cifre ASCII rende il ramo veloce piu' severo di
	# strptime, mai piu' permissivo: qualunque caso esotico ricade sul ripiego.
	for field in fields:
		if not field.isascii() or not field.isdigit(): return False
	return True

def _parse_fixed_datetime(data, str_format):
	try:
		if str_format == '%Y-%m-%d':
			if len(data) != 10 or data[4] != '-' or data[7] != '-': return None
			y, mo, d = data[0:4], data[5:7], data[8:10]
			if not _ascii_digits(y, mo, d): return None
			return datetime(int(y), int(mo), int(d))
		if str_format == '%Y-%m-%d %H:%M:%S':
			if len(data) != 19 or data[4] != '-' or data[7] != '-' or data[10] != ' ' \
					or data[13] != ':' or data[16] != ':': return None
			y, mo, d = data[0:4], data[5:7], data[8:10]
			h, mi, se = data[11:13], data[14:16], data[17:19]
			if not _ascii_digits(y, mo, d, h, mi, se): return None
			return datetime(int(y), int(mo), int(d), int(h), int(mi), int(se))
		if str_format == '%Y-%m-%dT%H:%M:%S.%fZ':
			if len(data) < 22 or data[4] != '-' or data[7] != '-' or data[10] != 'T' \
					or data[13] != ':' or data[16] != ':' or data[19] != '.' or data[-1] != 'Z':
				return None
			y, mo, d = data[0:4], data[5:7], data[8:10]
			h, mi, se = data[11:13], data[14:16], data[17:19]
			fraction = data[20:-1]
			# %f accetta da 1 a 6 cifre e pareggia a destra con zeri; oltre le sei strptime fallisce,
			# quindi qui si rinuncia invece di troncare e divergere.
			if not 1 <= len(fraction) <= 6: return None
			if not _ascii_digits(y, mo, d, h, mi, se, fraction): return None
			return datetime(int(y), int(mo), int(d), int(h), int(mi), int(se),
							int((fraction + '000000')[:6]))
	except ValueError: return None
	return None

def datetime_workaround(data, str_format):
	datetime_object = _parse_fixed_datetime(data, str_format)
	if datetime_object is not None: return datetime_object
	with _STRPTIME_LOCK:
		try: datetime_object = datetime.strptime(data, str_format)
		except: datetime_object = datetime(*(time.strptime(data, str_format)[0:6]))
	return datetime_object

def date_difference(current_date, compare_date, difference_tolerance, allow_postive_difference=False):
	try:
		difference = subtract_dates(current_date, compare_date)
		if not allow_postive_difference and difference > 0: return False
		else: difference = abs(difference)
		if difference > difference_tolerance: return False
		return True
	except: return True

def calculate_age(born, str_format, died=None):
	''' born and died are str objects e.g. '1972-05-28' '''
	born = datetime_workaround(born, str_format)
	if not died: today = date.today()
	else: today = datetime_workaround(died, str_format)
	return today.year - born.year - ((today.month, today.day) < (born.month, born.day))

def batch_replace(s, replace_info):
	for r in replace_info:
		s = str(s).replace(r[0], r[1])
	return s

def clean_file_name(s, use_encoding=False, use_blanks=True):
	try:
		hex_entities = [['&#x26;', '&'], ['&#x27;', '\''], ['&#xC6;', 'AE'], ['&#xC7;', 'C'],
					['&#xF4;', 'o'], ['&#xE9;', 'e'], ['&#xEB;', 'e'], ['&#xED;', 'i'],
					['&#xEE;', 'i'], ['&#xA2;', 'c'], ['&#xE2;', 'a'], ['&#xEF;', 'i'],
					['&#xE1;', 'a'], ['&#xE8;', 'e'], ['%2E', '.'], ['&frac12;', '%BD'],
					['&#xBD;', '%BD'], ['&#xB3;', '%B3'], ['&#xB0;', '%B0'], ['&amp;', '&'],
					['&#xB7;', '.'], ['&#xE4;', 'A'], ['\xe2\x80\x99', '']]
		special_encoded = [['"', '%22'], ['*', '%2A'], ['/', '%2F'], [':', ','], ['<', '%3C'],
							['>', '%3E'], ['?', '%3F'], ['\\', '%5C'], ['|', '%7C']]
		
		special_blanks = [['"', ' '], ['/', ' '], [':', ''], ['<', ' '],
							['>', ' '], ['?', ' '], ['\\', ' '], ['|', ' '], ['%BD;', ' '],
							['%B3;', ' '], ['%B0;', ' '], ["'", ""], [' - ', ' '], ['.', ' '],
							['!', ''], [';', ''], [',', '']]
		s = batch_replace(s, hex_entities)
		if use_encoding: s = batch_replace(s, special_encoded)
		if use_blanks: s = batch_replace(s, special_blanks)
		s = s.strip()
	except: pass
	return s

def normalize(txt):
	txt = re.sub(r'[^\x00-\x7f]',r'', txt)
	return txt

def safe_string(obj):
	try:
		try: return str(obj)
		except UnicodeEncodeError: return obj.encode('utf-8', 'ignore').decode('ascii', 'ignore')
		except: return ""
	except: return obj

def remove_accents(obj):
	try:
		try: obj = u'%s' % obj
		except: pass
		obj = ''.join(c for c in unicodedata.normalize('NFD', obj) if unicodedata.category(c) != 'Mn')
	except: pass
	return obj

def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding: r = re.search(r"(?i)" + from_string + r"([\S\s]+?)" + to_string, text).group(1)
	else: r = re.search(r"(?i)(" + from_string + r"[\S\s]+?" + to_string + ")", text).group(1)
	return r

def regex_get_all(text, start_with, end_with):
	r = re.findall(r"(?i)(" + start_with + r"[\S\s]+?" + end_with + ")", text)
	return r

def replace_html_codes(txt):
	from html import unescape
	txt = re.sub(r"(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
	txt = unescape(txt)
	txt = txt.replace("<ul>", "\n")
	txt = txt.replace("</ul>", "\n")
	txt = txt.replace("<li>", "\n* ")
	txt = txt.replace("</li>", "")
	txt = txt.replace("<br/><br/>", "\n")
	txt = txt.replace("&quot;", "\"")
	txt = txt.replace("&amp;", "&")
	txt = txt.replace("[spoiler]", "")
	txt = txt.replace("[/spoiler]", "")
	return txt

def gen_file_hash(file):
	try:
		md5_hash = hashlib.md5()
		with open(file, 'rb') as afile:
			buf = afile.read()
			md5_hash.update(buf)
			return md5_hash.hexdigest()
	except: pass

def sec2time(sec, n_msec=3):
	''' Convert seconds to 'D days, HH:MM:SS.FFF' '''
	if hasattr(sec,'__len__'): return [sec2time(s) for s in sec]
	m, s = divmod(sec, 60)
	h, m = divmod(m, 60)
	d, h = divmod(h, 24)
	if n_msec > 0: pattern = '%%02d:%%02d:%%0%d.%df' % (n_msec+3, n_msec)
	else: pattern = '%02d:%02d:%02d'
	if d == 0: return pattern % (h, m, s)
	return ('%d days, ' + pattern) % (d, h, m, s)

def released_key(item):
	if 'released' in item: return item['released'] or '2050-01-01'
	if 'first_aired' in item: return item['first_aired'] or '2050-01-01'
	return '2050-01-01'

def title_key(title):
	try:
		if title is None: title = ''
		articles = ['the', 'a', 'an']
		match = re.match(r'^((\w+)\s+)', title.lower())
		if match and match.group(2) in articles: offset = len(match.group(1))
		else: offset = 0
		return title[offset:]
	except: return title

def sort_for_article(_list, _key):
	_list.sort(key=lambda k: re.sub(r'(^the |^a |^an )', '', k[_key].lower()))
	return _list
	
def sort_list(sort_key, sort_direction, list_data):
	try:
		reverse = sort_direction != 'asc'
		if sort_key == 'rank': return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
		if sort_key == 'added': return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
		if sort_key == 'title': return sorted(list_data, key=lambda x: title_key(x[x['type']].get('title')), reverse=reverse)
		if sort_key == 'released': return sorted(list_data, key=lambda x: released_key(x[x['type']]), reverse=reverse)
		if sort_key == 'runtime': return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
		if sort_key == 'popularity': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		if sort_key == 'percentage': return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
		if sort_key == 'votes': return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
		if sort_key == 'random':
			# Pigro: random tira dentro anche _sha512 (~160 ms a freddo) per un ordinamento che
			# quasi nessuna lista chiede. Vedi la nota sugli import pigri in testa al modulo.
			from random import random as _random
			return sorted(list_data, key=lambda k: _random())
		return list_data
	except: return list_data

def paginate_list(item_list, page, limit=20, paginate_start=0):
	if paginate_start:
		item_list = item_list[paginate_start:]
		pages = list(chunks(item_list, limit))
		pages.insert(0, [])
	else: pages = list(chunks(item_list, limit))
	result = (pages[page - 1], len(pages))
	return result

def unzip(zip_location, destination_location, destination_check, show_busy=True):
	if show_busy: show_busy_dialog()
	try:
		from zipfile import ZipFile
		zipfile = ZipFile(zip_location)
		zipfile.extractall(path=destination_location)
		if path_exists(destination_check): status = True
		else: status = False
	except: status = False
	if show_busy: hide_busy_dialog()
	return status

def copy2clip(txt):
	if sys.platform == "win32":
		try:
			from subprocess import check_call
			cmd = 'echo ' + txt.replace('&', '^&').strip() + '|clip'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == "darwin":
		try:
			from subprocess import check_call
			cmd = 'echo ' + txt.strip() + '|pbcopy'
			return check_call(cmd, shell=True)
		except: return
	if sys.platform == "linux":
		try:
			from subprocess import Popen, PIPE
			p = Popen(['xsel', '-pi'], stdin=PIPE)
			p.communicate(input=txt)
		except: return
def traduci_episodio(mappa, esclusi, stagione, episodio):
	"""I TRE esiti della mappa episodi, al posto dei due di `mappa.get(chiave, chiave)`.

	Finche' gli esiti erano due -- "tradotto" e, per difetto, "identita'" -- **"non lo so" e
	"identita'" erano lo stesso valore**, ed e' per questo che il difetto del rimappaggio era
	silenzioso: un episodio senza corrispondenza otteneva comunque una coppia, che poteva indicare un
	altro episodio o niente.

	  coppia tradotta  la giuntura per id TVDB ha trovato il corrispondente e i due si numerano
	                   diversamente
	  la coppia stessa la giuntura non l'ha trovato ma l'identita' e' lecita (la coppia e' libera da
	                   entrambe le parti -- vedi la regola 3 in costruisci_mappa_episodi)
	  None             nessuna corrispondenza: non si traduce e non si manda. Chi chiama DEVE
	                   saltare, non ripiegare sull'identita'.

	`esclusi` e' l'insieme costruito insieme alla mappa. Vale in entrambe le direzioni: passando la
	mappa TVDB->Trakt con i suoi esclusi si traduce verso Trakt, passando l'inversa con gli esclusi
	dell'altro lato si traduce verso le righe locali.
	"""
	try: chiave = (int(stagione), int(episodio))
	except: return None
	if esclusi and chiave in esclusi: return None
	if not mappa: return chiave
	return mappa.get(chiave, chiave)
