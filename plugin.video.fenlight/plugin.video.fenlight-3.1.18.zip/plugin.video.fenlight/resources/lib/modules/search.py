# -*- coding: utf-8 -*-
import json
from urllib.parse import unquote
from caches.main_cache import main_cache
from indexers.people import person_search
from indexers.easynews import search_easynews_image
from modules import kodi_utils
logger = kodi_utils.logger

close_all_dialog, external = kodi_utils.close_all_dialog, kodi_utils.external
build_url, kodi_dialog, execute_builtin, select_dialog = kodi_utils.build_url, kodi_utils.kodi_dialog, kodi_utils.execute_builtin, kodi_utils.select_dialog
notification, kodi_refresh = kodi_utils.notification, kodi_utils.kodi_refresh
clear_history_list = [('Clear Movie Search History', 'movie_queries'),
					('Clear TV Show Search History', 'tvshow_queries'),
					('Clear Anime Search History', 'anime_queries'),
					('Clear People Search History', 'people_queries'),
					('Clear Keywords Movie Search History', 'keyword_tmdb_movie_queries'),
					('Clear Keywords TV Show Search History', 'keyword_tmdb_tvshow_queries'),
					('Clear Easynews Search History', 'easynews_video_queries'),
					('Clear Easynews Search History', 'easynews_image_queries'),
					('Clear Trakt List Search History', 'trakt_list_queries')]

def get_key_id(params):
	close_all_dialog()
	params_key_id = params.get('key_id', None)
	key_id = params_key_id or kodi_dialog().input('')
	if not key_id: return
	key_id = unquote(key_id)
	media_type = params.get('media_type', '')
	search_type = params.get('search_type', 'media_title')
	string = None
	if search_type == 'media_title':
		if media_type == 'movie': url_params, string = {'mode': 'build_movie_list', 'action': 'tmdb_movies_search'}, 'movie_queries'
		elif media_type == 'tv_show': url_params, string = {'mode': 'build_tvshow_list', 'action': 'tmdb_tv_search'}, 'tvshow_queries'
		else: url_params, string = {'mode': 'build_tvshow_list', 'action': 'tmdb_anime_search'}, 'anime_queries'
	elif search_type == 'people': string = 'people_queries'
	elif search_type == 'tmdb_keyword':
		url_params, string = {'mode': 'navigator.keyword_results', 'media_type': media_type}, 'keyword_tmdb_%s_queries' % media_type
	elif search_type == 'easynews_video':
		url_params, string = {'mode': 'easynews.search_easynews'}, 'easynews_video_queries'
	elif search_type == 'easynews_image':
		url_params, string = {'mode': 'easynews.search_easynews_image'}, 'easynews_image_queries'
	elif search_type == 'trakt_lists':
		url_params, string = {'mode': 'trakt.list.search_trakt_lists'}, 'trakt_list_queries'
	if string: add_to_search(key_id, string)
	if search_type == 'people': return person_search(key_id)
	if search_type == 'easynews_image': return search_easynews_image(key_id)
	url_params.update({'query': key_id, 'key_id': key_id, 'name': 'Search Results for %s' % key_id})
	action = 'ActivateWindow(Videos,%s,return)' if external() else 'Container.Update(%s)'
	return execute_builtin(action % build_url(url_params))

def add_to_search(search_name, search_list):
	try:
		result = []
		cache = main_cache.get(search_list)
		if cache: result = cache
		if search_name in result: result.remove(search_name)
		result.insert(0, search_name)
		result = result[:50]
		main_cache.set(search_list, result, expiration=8760)
	except: return

def remove_from_search(params):
	try:
		result = main_cache.get(params['setting_id'])
		result.remove(params.get('key_id'))
		main_cache.set(params['setting_id'], result, expiration=8760)
		notification('Success', 2500)
		kodi_refresh(coalesce=False)
	except: return

def clear_search():
	try:
		list_items = [{'line1': item[0]} for item in clear_history_list]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
		setting_id = select_dialog([item[1] for item in clear_history_list], **kwargs)
		if setting_id == None: return
		clear_all(setting_id)
	except: return

def clear_all(setting_id, refresh='false'):
	main_cache.set(setting_id, '', expiration=365)
	notification('Success', 2500)
	if refresh == 'true': kodi_refresh(coalesce=False)

def select_discover_filter(params):
    import json, xbmcgui
    from modules import meta_lists as ml
    fk = params.get('filter', '')
    mt = params.get('media_type', 'movie')
    is_movie = (mt == 'movie')
    win = xbmcgui.Window(10000)
    prop_d = 'Discover.%s' % fk
    prop_u = 'Discover.%s.url' % fk
    if fk == 'with_released':
        if win.getProperty(prop_d):
            win.clearProperty(prop_d); win.clearProperty(prop_u)
        else:
            url = ('&primary_release_date.lte=[current_date]' if is_movie
                   else '&include_null_first_air_dates=false&first_air_date.lte=[current_date]')
            win.setProperty(prop_d, 'Yes'); win.setProperty(prop_u, url)
        return
    if fk == 'with_cast':
        name = kodi_dialog().input('Include Cast')
        if not name: return
        try:
            from apis.tmdb_api import tmdb_people_info
            results = tmdb_people_info(name)['results']
        except: return notification('No Results', 2500)
        if not results: return notification('No Results', 2500)
        items = [{'line1': r['name'], 'name': r['name'], 'id': str(r['id'])} for r in results]
        choice = select_dialog(items, **{'items': json.dumps(items), 'heading': 'Include Cast', 'enumerate': 'false', 'narrow_window': 'true'})
        if choice:
            win.setProperty(prop_d, choice['name'])
            win.setProperty(prop_u, '&with_cast=%s' % choice['id'])
        return
    multi = False
    if fk == 'with_year_start':
        items = [{'name': str(i['name']), 'id': str(i['id'])} for i in (ml.years_movies if is_movie else ml.years_tvshows)]
        url_t = '&primary_release_date.gte=%s-01-01' if is_movie else '&first_air_date.gte=%s-01-01'
    elif fk == 'with_year_end':
        items = [{'name': str(i['name']), 'id': str(i['id'])} for i in (ml.years_movies if is_movie else ml.years_tvshows)]
        url_t = '&primary_release_date.lte=%s-12-31' if is_movie else '&first_air_date.lte=%s-12-31'
    elif fk in ('with_genres', 'without_genres'):
        items = [{'name': i['name'], 'id': str(i['id'])} for i in (ml.movie_genres if is_movie else ml.tvshow_genres)]
        url_t = '&with_genres=%s' if fk == 'with_genres' else '&without_genres=%s'
        multi = True
    elif fk == 'with_network':
        items = [{'name': i['name'], 'id': str(i['id'])} for i in sorted(ml.networks, key=lambda k: k['name'])]
        url_t = '&with_networks=%s'
    elif fk == 'with_rating':
        items = [{'name': str(float(i)), 'id': str(i)} for i in range(1, 11)]
        url_t = '&vote_average.gte=%s'
    elif fk == 'with_rating_votes':
        items = [{'name': '1', 'id': '1'}] + [{'name': str(i), 'id': str(i)} for i in range(50, 1001, 50)]
        url_t = '&vote_count.gte=%s'
    elif fk == 'with_sort':
        items = [{'name': i['name'], 'id': i['id']} for i in (ml.movie_sorts if is_movie else ml.tvshow_sorts)]
        url_t = '%s'
    else:
        return
    heading = fk.replace('with_', '').replace('without_', 'Exclude ').replace('_', ' ').title()
    kwargs = {'items': json.dumps([{'line1': i['name']} for i in items]), 'heading': heading, 'narrow_window': 'true'}
    if multi:
        kwargs['multi_choice'] = 'true'
        choice = select_dialog(items, **kwargs)
        if choice is not None:
            win.setProperty(prop_d, ', '.join(i['name'] for i in choice))
            win.setProperty(prop_u, url_t % ','.join(i['id'] for i in choice))
    else:
        choice = select_dialog(items, **kwargs)
        if choice is not None:
            win.setProperty(prop_d, choice['name'])
            win.setProperty(prop_u, url_t % choice['id'])

def launch_discover(params):
	import xbmc, xbmcgui, xbmcaddon
	mt = params.get('media_type', 'movie')
	is_movie = (mt == 'movie')
	win = xbmcgui.Window(10000)
	keys = ['with_year_start','with_year_end','with_genres','without_genres',
			'with_cast','with_network','with_rating','with_sort']
	user_fragments = ''.join(win.getProperty('Discover.%s.url' % k) for k in keys)
	xbmc.log('###AF3_DISCOVER### media_type=%s user_fragments=[%s]' % (mt, user_fragments), xbmc.LOGINFO)
	if not user_fragments: return notification('Set at least one filter', 2500)
	import re
	from datetime import date
	today = date.today().strftime('%Y-%m-%d')
	fragments = user_fragments
	date_key = 'primary_release_date' if is_movie else 'first_air_date'
	date_match = re.search(r'&%s\.lte=(\d{4})-12-31' % date_key, fragments)
	if date_match and '%s-12-31' % date_match.group(1) > today:
		fragments = fragments.replace('&%s.lte=%s-12-31' % (date_key, date_match.group(1)), '&%s.lte=%s' % (date_key, today))
	elif not date_match:
		fragments += '&%s.lte=%s' % (date_key, today)
	if not is_movie:
		fragments += '&include_null_first_air_dates=false'
	fragments += '&vote_count.gte=100'
	# When the user picks no sort, force vote_average.desc as the TMDb candidate pool (TMDb would otherwise
	# default to popularity, surfacing what's trending now instead of the best films). The indexer then
	# re-orders each page by the more reliable IMDb rating (it derives the direction from this sort_by; see
	# discover_imdb_sort_from_url). Explicit non-rating sorts and Random keep the pure TMDb order.
	if '[random]' not in user_fragments and 'sort_by=' not in user_fragments:
		fragments += '&sort_by=vote_average.desc'
	tmdb_url = 'https://api.themoviedb.org/3/discover/%s?language=en-US&region=US&with_original_language=en%s' % ('movie' if is_movie else 'tv', fragments)
	mode = 'build_movie_list' if is_movie else 'build_tvshow_list'
	action = 'tmdb_movies_discover' if is_movie else 'tmdb_tv_discover'
	content_path = build_url({'mode': mode, 'action': action, 'url': tmdb_url, 'name': 'Discover'})
	xbmc.log('###AF3_DISCOVER### content_path=[%s]' % content_path, xbmc.LOGINFO)
	execute_builtin('ClearProperty(Search.ActivePanel)')
	execute_builtin('SetProperty(Background.HideArtwork,True)')
	execute_builtin('SetFocus(3000)')
	xbmc.sleep(100)
	xbmc.log('###AF3_DISCOVER### clear_edit_result=[%s]' % xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'method': 'Input.SendText', 'params': {'text': '', 'done': True}, 'id': 1})), xbmc.LOGINFO)
	xbmc.sleep(100)
	# STRADA B, meta' Discover (lotto 162). Il token di paginazione appartiene al CONTENITORE, non
	# alla lista: appena cambia ContentPath, Kodi ricompone il <content> del row 505 e in coda ci
	# trova ancora il 'pages=N' della ricerca PRECEDENTE. Il plugin viene invocato, si accorge che
	# l'inquilino e' cambiato e butta via tutta l'invocazione -- 336 ms misurati il 04/09 (lotto 161),
	# 697 prima di quello. Azzerando il token QUI l'invocazione non nasce proprio.
	# Qui non c'e' nessuna corsa da vincere, ed e' il motivo per cui questa meta' e' piu' solida
	# dell'altra: le due proprieta' si scrivono nello stesso thread a microsecondi di distanza, prima
	# che il ciclo della GUI rivaluti gli $INFO del path. Il caso simmetrico -- la ricerca testuale --
	# non ha un punto come questo e deve passare da <ontextchange> nella skin.
	from modules.paginator import CTL_PAGES_PROP
	win.clearProperty(CTL_PAGES_PROP % ('1105', '505'))
	win.setProperty('FenLight.Discover.ContentPath', content_path)
	execute_builtin('SetFocus(3050)')
	# Attendi il caricamento dei risultati: se la ricerca non produce risultati,
	# riporta il focus sulla barra di ricerca (evita di restare su un elemento invisibile)
	try: no_results_label = xbmcaddon.Addon('skin.arctic.fuse.3').getLocalizedString(31046)
	except: no_results_label = ''
	xbmc.sleep(300)
	for _ in range(150):
		if not xbmc.getCondVisibility('Window.IsActive(1105)'): return
		if not xbmc.getCondVisibility('Container(1105,505).IsUpdating'): break
		xbmc.sleep(100)
	num = xbmc.getInfoLabel('Container(1105,505).NumItems') or '0'
	first = xbmc.getInfoLabel('Container(1105,505).ListItemAbsolute(0).Label')
	if num in ('0', '') or (num == '1' and no_results_label and first == no_results_label):
		execute_builtin('SetFocus(3001)')

def clear_discover_filters(params):
	import xbmcgui
	win = xbmcgui.Window(10000)
	keys = ['with_year_start','with_year_end','with_genres','without_genres',
				'with_cast','with_network','with_rating','with_rating_votes','with_sort','with_released']
	for k in keys:
		win.clearProperty('Discover.%s' % k)
		win.clearProperty('Discover.%s.url' % k)
	win.clearProperty('FenLight.Discover.ContentPath')
	if params.get('reset_type') == 'true':
		win.clearProperty('Discover.MediaType')
