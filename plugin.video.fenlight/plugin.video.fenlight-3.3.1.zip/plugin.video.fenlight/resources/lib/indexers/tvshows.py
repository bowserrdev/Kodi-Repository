# -*- coding: utf-8 -*-
import sys
from time import perf_counter as _perf
# modules.meta_lists non si importa piu' (lotto 110): questo file non ne usava un solo nome.
from modules import kodi_utils, settings
from modules import paginator, sorgenti
from modules.watchlist_label import DYNAMIC_LABEL as DYNAMIC_WATCHLIST_LABEL
from modules.metadata import tvshow_meta
from modules.metadata import tvshow_meta_prefetch, meta_prefetch_key
from modules.utils import get_datetime, make_thread_list, get_current_timestamp, paginate_list
from modules.watched_status import get_database, watched_info_tvshow, get_watched_status_tvshow, get_progress_status_tvshow
logger = kodi_utils.logger

string, external, add_items, add_dir = str, kodi_utils.external, kodi_utils.add_items, kodi_utils.add_dir
sleep, add_item, cast_label, home, tmdb_api_key = kodi_utils.sleep, kodi_utils.add_item, kodi_utils.cast_label, kodi_utils.home, settings.tmdb_api_key
set_category, make_listitem, build_url, set_property = kodi_utils.set_category, kodi_utils.make_listitem, kodi_utils.build_url, kodi_utils.set_property
set_content, end_directory, set_view_mode, folder_path = kodi_utils.set_content, kodi_utils.end_directory, kodi_utils.set_view_mode, kodi_utils.folder_path
STATO_VUOTO = kodi_utils.STATO_VUOTO
poster_empty, nextpage_landscape = kodi_utils.empty_poster, kodi_utils.nextpage_landscape
media_open_action, default_all_episodes, page_limit, paginate = settings.media_open_action, settings.default_all_episodes, settings.page_limit, settings.paginate
widget_hide_next_page, watched_indicators = settings.widget_hide_next_page, settings.watched_indicators
mpaa_region = settings.mpaa_region
run_plugin, container_update = 'RunPlugin(%s)', 'Container.Update(%s)'
# Vedi il commento in movies.py: URL per formattazione diretta invece che con build_url/urlencode.
# Sulle serie il guadagno e' maggiore perche' un elemento costruisce piu' URL, e ben sette di esse
# portavano testo libero (titolo o URL del poster) che urlencode doveva percent-encodare a ogni giro.
# Ora quel testo non viaggia piu': i gestori lo rileggono dai metadati, che avevano gia' in mano o
# che leggono da cache una volta sola, quando l'utente apre davvero la voce.
# ATTENZIONE: qualunque nuovo parametro di testo libero deve tornare a passare da build_url.
_BASE = 'plugin://plugin.video.fenlight/?'
URL_EXTRAS = _BASE + 'mode=extras_menu_choice&tmdb_id=%s&media_type=tvshow&is_external=%s&is_anime=%s'
URL_OPTIONS = _BASE + 'mode=options_menu_choice&content=tvshow&tmdb_id=%s&is_external=%s&is_anime=%s'
URL_MORE_LIKE_THIS = _BASE + 'mode=build_tvshow_list&action=imdb_more_like_this&key_id=%s&name_id=%s&is_external=%s'
URL_SEASON_LIST = _BASE + 'mode=build_season_list&tmdb_id=%s'
URL_ALL_EPISODES = _BASE + 'mode=build_episode_list&tmdb_id=%s&season=all'
URL_MARK_TVSHOW = _BASE + 'mode=watched_status.mark_tvshow&action=%s&tmdb_id=%s&tvdb_id=%s'
URL_WATCHLIST_TOGGLE = _BASE + 'mode=trakt.watchlist_toggle&media_type=tvshow&tmdb_id=%s&in_watchlist=%s'
URL_REFRESH_WIDGETS = _BASE + 'mode=refresh_widgets&user=true'
URL_EXIT_MEDIA_MENU = _BASE + 'mode=navigator.exit_media_menu'
# LOTTO 331 -- le azioni stanno in modules/sorgenti.py, con le sorgenti che le leggono. Qui restano i nomi
# che usano i rami a pagina singola (lotto 335).
_AZIONI = sorgenti.AZIONI['tvshow']
main, special, personal, trakt_main, trakt_personal = _AZIONI['main'], _AZIONI['special'], _AZIONI['personal'], \
	_AZIONI['trakt_main'], _AZIONI['trakt_personal']
trakt_special = _AZIONI['trakt_special']
view_mode, content_type = 'view.tvshows', 'tvshows'
internal_nav_check = ('build_season_list', 'build_episode_list')

class TVShows:
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'TV Shows'
		self.id_type, self.list, self.action = self.params_get('id_type', 'tmdb_id'), self.params_get('list', []), self.params_get('action', None)
		self.items, self.new_page, self.total_pages, self.is_external, self.is_home = [], {}, None, external(), home()
		# LOTTO 333 -- `preparata`: questa istanza costruisce gli elementi di una lista mista che il servizio ha
		# preparato (Trakt, MDbList). Vale la stessa regola delle righe paginate: niente rete, schede scadute
		# servite, mancanti segnalate -- per conto della lista (pg_key, pg_params), non di questa istanza.
		self.interactive = bool(self.params_get('preparata'))
		if self.interactive: self.pg_key, self.pg_params = self.params['pg_key'], self.params['pg_params']
		# Popolato da worker() prima del pool; vuoto significa solo "nessuna anticipazione", non errore.
		self.meta_prefetch = {}
		self.widget_hide_next_page = self.is_home and widget_hide_next_page()
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append
		try: self.is_anime = '_anime_' in self.action
		except: self.is_anime = False
		self.fanart_empty = kodi_utils.addon_fanart()
		# Text-search hub builds are debounced + guarded against stale (out-of-order) completion; for any
		# other build search_query is None and these guards are no-ops. See paginator.search_should_abort.
		self.search_query = self.params_get('query') if (self.action == 'tmdb_tv_search_filtered' and self.params_get('search_hub')) else None
		# L'ESITO DI QUESTA COSTRUZIONE, dichiarato qui e non dedotto a valle con getattr: i casi sono
		# quattro e uno -- il fallimento -- si raggiunge da un `except`, cioe' dal solo posto in cui e'
		# facile dimenticarsene. Lo legge la chiusura della cartella, in fondo a fetch_list.
		self.consegna = 'piena'


	# LOTTO 119. Vedi la nota al punto di chiamata di set_head.
	PG_MEDIA_TYPE = 'tvshow'
	# L'identita' di un elemento e' la coppia (tipo, id TMDb), la stessa che sta nel database: qui il
	# tipo e' fisso, questa classe costruisce serie. Vedi la gemella in indexers/movies.py.
	PG_TIPO = paginator.TIPI['tvshow']

	def pg_action(self):
		"""L'azione pubblicata per la ricarica mirata, qualificata per tipo di media.

		Non e' self.action perche' lo stesso nome di azione costruisce due widget diversi a seconda
		della classe che lo esegue. None resta None: un widget senza azione continua a essere deciso
		dal solo elenco degli id, come prima.
		"""
		if not self.action: return None
		return '%s:%s' % (self.action, self.PG_MEDIA_TYPE)

	def fetch_list(self):
		handle = int(sys.argv[1])
		_t0 = paginator.now()
		try:
			is_random = self.params_get('random', 'false') == 'true'
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if page_no == 1 and not self.is_external:
				folderpath = folder_path()
				if not any([x in folderpath for x in internal_nav_check]): set_property('fenlight.exit_params', folderpath)
			# LOTTO 333 -- una riga paginata la PREPARA il servizio: qui si legge dal database e basta. Vedi
			# la gemella in movies.py e modules/preparatore.py.
			paginata = self.is_external and not is_random and sorgenti.paginabile('tvshow', self.params)
			function = None if paginata else sorgenti.funzione_api('tvshow', self.action)
			paginator.log('tvshows fetch_list action=%s is_home=%s is_external=%s random=%s -> preparata=%s' %
						(self.action, self.is_home, self.is_external, is_random, paginata))
			if paginata:
				self.interactive = True
				kodi_utils.vieta_rete('tvshows %s' % self.action)
				self.pg_key, self.pg_params = paginator.widget_key(self.params), self.params
				self.id_type = 'tmdb_id'
				kodi_utils.tappa('tvshows.sorgente')
				paginator.log('tvshows BUILD action=%s key=%s params=%s' % (self.action, paginator.short(self.pg_key),
						{k: self.params.get(k) for k in ('mode', 'action', 'category_name', 'key_id', 'url', 'query') if self.params.get(k)}))
				pronta, self._pg_pages = paginator.passo_pronto(self.params, self.pg_key, 'tvshow', self.pg_action())
				kodi_utils.tappa('tvshows.pagine')
				self.list = [tmdb for _tipo, tmdb in (pronta.voci if pronta else ())]
				# Sorpassati per posizione: non si scrive niente sul contenitore, nemmeno lo stato dei
				# passi. Scriverlo voleva dire azzerare a 0 i passi della lista che ci ha sostituiti.
				if not paginator.passo_superato():
					paginator.set_state(self.pg_key, pronta.passi if pronta else 0, bool(pronta and pronta.fine and not pronta.altri))
			elif self.action in main:
				data = function(page_no)
				self.list = [i['id'] for i in data['results']]
				if not is_random and  data['total_pages'] > page_no: self.new_page = {'new_page': string(page_no + 1)}
			elif self.action in special:
				key_id = self.params_get('key_id') or self.params_get('query')
				if not key_id: return
				data = function(key_id, page_no)
				self.list = [i['id'] for i in data['results']]
				if not is_random and data['total_pages'] > page_no: self.new_page = {'new_page': string(page_no + 1), 'key_id': key_id}
			elif self.action in personal:
				data = function('anime' if self.is_anime else 'tvshow', page_no)
				data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_id'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'paginate_start': self.paginate_start}
			elif self.action in trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				try: self.list = [i['show']['ids'] for i in data]
				except: self.list = [i['ids'] for i in data]
				if not is_random and self.action != 'trakt_recommendations': self.new_page = {'new_page': string(page_no + 1)}
			elif self.action in trakt_special:
				self.id_type = 'trakt_dict'
				key_id = self.params_get('key_id', None)
				if not key_id: return
				data = function(key_id, page_no)
				self.list = [i['show']['ids'] for i in data]
				if not is_random: self.new_page = {'new_page': string(page_no + 1), 'key_id': key_id}
			elif self.action in trakt_personal:
				self.id_type = 'trakt_dict'
				data = function('shows', page_no)
				if self.action in ('trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites'): total_pages = 1
				else: data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				data = function('shows')
				data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action == 'tmdb_tv_discover':
				url = self.params_get('url')
				data = function(url, page_no)
				self.list = [i['id'] for i in data['results']]
				if data['total_pages'] > page_no: self.new_page = {'url': url, 'new_page': string(data['page'] + 1)}
			elif self.action == 'imdb_more_like_this':
				if self.params_get('get_imdb'):
					self.params['key_id'] = tvshow_meta('tmdb_id', self.params_get('key_id'), tmdb_api_key(), mpaa_region(), get_datetime(), get_current_timestamp())['imdb_id']
				self.id_type = 'imdb_id'
				self.list = function(self.params_get('key_id'))
			# Il nome della lista si risolve QUI, una volta, da cache. Nell'URL della voce costava una
			# percent-codifica del titolo per ogni elemento di ogni lista costruita.
			self._resolve_list_name()
			_t1 = paginator.now()
			kodi_utils.tappa('tvshows.risoluzione')
			items = self.worker()
			paginator.log_build('tvshows', self.action, _t0, _t1, paginator.now(), len(items) if items else 0,
						getattr(self, '_pg_pages', None), self.params_get('pages'))
			# Due modi di sapere che questa costruzione non parla piu' per il suo contenitore, e sono
			# diversi: search_is_stale guarda la CASELLA (l'utente ha scritto altro), passo_superato
			# guarda la risposta del SERVIZIO (un'altra lista ha preso questa posizione). Il secondo
			# vale per qualunque riga paginata, non solo per le ricerche.
			if paginator.passo_superato():
				# UN'ALTRA LISTA HA PRESO QUESTA POSIZIONE mentre costruivamo (il servizio risponde
				# 'superata'): il contenitore non e' piu' nostro. E' il difetto del 21/09 notte, quando
				# una costruzione gia' dichiarata superata pubblicava set_head con zero elementi sul
				# contenitore che un'altra stava gia' riempiendo.
				self.consegna = 'superata'
			elif self.search_query and paginator.search_is_stale(self.search_query):
				# LA CASELLA HA GIA' UN'ALTRA QUERY. Restano due fatti separati e non si fondono: li'
				# a cambiare e' stata la POSIZIONE, qui il TESTO, e solo il secondo e' una ricerca.
				self.consegna = 'lasciata'
			else:
				add_items(handle, items)
				# AZIONE QUALIFICATA PER TIPO DI MEDIA (lotto 119). 'trakt_watchlist' e' lo stesso nome di
				# azione per DUE widget distinti -- la watchlist dei film la costruisce questa classe,
				# quella delle serie la gemella in indexers/movies.py -- e finche' l'azione pubblicata era il nome nudo
				# i due erano indistinguibili: aggiungere un film ricostruiva anche la watchlist delle
				# serie. Il qualificatore lo aggiunge chi COSTRUISCE, che e' l'unico a sapere con
				# certezza di che tipo e' il proprio widget. Chi chiede senza qualificatore li prende
				# ancora entrambi: vedi paginator._action_matches.
				if self.interactive:
					paginator.set_head(self.pg_key, items, self.pg_action(), self.params, preparata=True)
					kodi_utils.tappa('tvshows.testa')
				if self.new_page and not self.widget_hide_next_page:
							self.new_page.update({'mode': 'build_tvshow_list', 'action': self.action, 'category_name': self.category_name})
							add_dir(self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], handle, 'nextpage', nextpage_landscape)
		except Exception as e:
			# MAI silenzioso: una build che esplode chiude la directory VUOTA, e il container
			# torna a ricostruirsi da capo -- e' il meccanismo per cui "spariscono le pagine
			# dopo la prima". Senza questo log il fallimento e' invisibile.
			self.consegna = 'fallita'
			import traceback
			logger('FenLight BUILD FALLITA', 'tvshows action=%s: %s\n%s' % (self.action, e, traceback.format_exc()))
		set_content(handle, content_type)
		set_category(handle, self.category_name)
		# SI DICHIARA SOLO CIO' CHE SI VEDRA'. Il ponte descrive il contenitore a schermo, e questa
		# cartella arriva a schermo soltanto se Kodi la applica -- cioe' solo se il path che l'ha
		# chiesta e' ancora quello del contenitore. Delle quattro uscite di fetch_list una sola lo e':
		#   'piena'      si e' costruito davvero. Zero titoli allora vuol dire zero risultati, e si
		#                consegna STATO_VUOTO: e' un "Nessun risultato" vero;
		#   'superata'   la posizione e' di un'altra lista: non si tocca cio' che non e' nostro;
		#   'lasciata'   la casella ha gia' un'altra query, quindi il path e' cambiato e Kodi ha gia'
		#                chiesto altro: questa cartella la SCARTA. Dichiararla portava BUILT_PROP a 0
		#                mentre a schermo c'erano i quaranta elementi di prima, e da li' in poi
		#                _search_svuota_prima -- che chiede proprio BUILT_PROP > 0 per sapere se c'e'
		#                qualcosa da togliere -- trovava 0 e si fermava. E' il difetto che la sonda
		#                delle 06:05 ha trovato nel gemello di questo ramo, router._search_debounce_abort;
		#   'fallita'    non si sa niente. Un errore non e' una risposta: dichiararlo vuoto scriveva
		#                "Nessun risultato" su una ricerca che non e' mai arrivata in fondo.
		# A svuotare davvero resta chi agisce sul path VIVO, cioe' _search_svuota_prima.
		end_directory(handle, cacheToDisc=False if self.is_external else True,
					segnaposto=STATO_VUOTO if self.consegna == 'piena' else None)
		if not self.is_external:
			if self.params_get('refreshed') == 'true': sleep(1000)
			set_view_mode(view_mode, content_type, self.is_external)

	def build_tvshow_content(self, _position, _id):
		try:
			_b0 = _perf()
			# Vedi Movies.build_movie_content: prima il lotto letto in sequenza fuori dal pool.
			_pk = meta_prefetch_key(self.id_type, _id, 'tvshow')
			meta = self.meta_prefetch.get(_pk) if _pk else None
			if meta is None:
				# Una riga preparata non scarica: la scheda che manca la chiede al servizio (lotto 333).
				if self.interactive:
					self._mancanti.append(_id); return
				meta = tvshow_meta(self.id_type, _id, self.tmdb_api_key, self.mpaa_region, self.current_date, self.current_time)
			if not meta or 'blank_entry' in meta: return
			_b1 = _perf()
			cm = []
			cm_append = cm.append
			listitem = make_listitem()
			set_properties = listitem.setProperties
			meta_get = meta.get
			premiered = meta_get('premiered')
			trailer, title, year = meta_get('trailer'), meta_get('title'), meta_get('year') or '2050'
			tvdb_id, imdb_id = meta_get('tvdb_id'), meta_get('imdb_id')
			poster, fanart, clearlogo, landscape = meta_get('poster') or poster_empty, meta_get('fanart') or self.fanart_empty, meta_get('clearlogo') or '', meta_get('landscape') or ''
			thumb = poster or landscape or fanart
			tmdb_id, total_seasons, total_aired_eps = meta_get('tmdb_id'), meta_get('total_seasons'), meta_get('total_aired_eps')
			unaired = total_aired_eps == 0
			if unaired: progress, playcount, total_watched, total_unwatched = 0, 0, 0, total_aired_eps
			else:
				playcount, total_watched, total_unwatched = get_watched_status_tvshow(self.watched_info.get(string(tmdb_id), None), total_aired_eps)
				if total_watched: progress = get_progress_status_tvshow(total_watched, total_aired_eps)
				else: progress = 0
				visible_progress = '0' if progress == 100 else progress
			extras_params = URL_EXTRAS % (tmdb_id, self.is_external, self.is_anime)
			options_params = URL_OPTIONS % (tmdb_id, self.is_external, self.is_anime)
			more_like_this_params = URL_MORE_LIKE_THIS % (imdb_id, tmdb_id, self.is_external)
			if self.all_episodes:
				if self.all_episodes == 1 and total_seasons > 1: url_params = URL_SEASON_LIST % tmdb_id
				else: url_params = URL_ALL_EPISODES % tmdb_id
			else: url_params = URL_SEASON_LIST % tmdb_id
			# Stesse voci dei film (vedi movies.py). Extras e le navigazioni secondarie non sono piu'
			# voci di menu: extras_params e more_like_this_params restano pubblicate come proprieta',
			# quindi i tasti rapidi di custom_keys.py continuano a funzionare. Da undici voci a cinque,
			# e addContextMenuItems si paga per OGNI serie costruita.
			if self.open_extras:
				cm_append(('[B]Sfoglia[/B]', container_update % url_params))
				url_params = extras_params
			cm_append(('[B]Opzioni[/B]', run_plugin % options_params))
			if not playcount and not unaired:
				cm_append(('[B]Segna come visto[/B]',
							run_plugin % (URL_MARK_TVSHOW % ('mark_as_watched', tmdb_id, tvdb_id))))
			if progress:
				cm_append(('[B]Segna come non visto[/B]',
							run_plugin % (URL_MARK_TVSHOW % ('mark_as_unwatched', tmdb_id, tvdb_id))))
			in_watchlist = string(tmdb_id) in self.watchlist_ids
			# Etichetta viva ovunque: la tiene giusta il watcher (modules/watchlist_label.py). in_watchlist
			# resta nell'URL come ripiego di watchlist_toggle quando la copia in cache manca.
			cm_append((DYNAMIC_WATCHLIST_LABEL,
						run_plugin % (URL_WATCHLIST_TOGGLE % (tmdb_id, 'true' if in_watchlist else 'false'))))
			set_properties({'watchedepisodes': string(total_watched), 'unwatchedepisodes': string(total_unwatched)})
			set_properties({'watchedprogress': visible_progress, 'totalepisodes': string(total_aired_eps), 'totalseasons': string(total_seasons)})
			# "Refresh" e' il superset di "Reload": alza fenlight.refresh_widgets e poi chiama comunque
			# kodi_refresh. Tenuta solo quella, come nei film.
			if self.is_external:
				cm_append(('[B]Aggiorna widget[/B]', run_plugin % URL_REFRESH_WIDGETS))
			else: cm_append(('[B]Esci dalla lista[/B]', run_plugin % URL_EXIT_MEDIA_MENU))
			_b2 = _perf()
			listitem.setLabel(title)
			_b3 = _perf()
			listitem.addContextMenuItems(cm)
			_b4 = _perf()
			listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': thumb, 'icon': landscape,
							'tvshow.poster': poster, 'tvshow.clearlogo': clearlogo})
			_b5 = _perf()
			info_tag = listitem.getVideoInfoTag()
			info_tag.setMediaType('tvshow'), info_tag.setTitle(title), info_tag.setTvShowTitle(title), info_tag.setOriginalTitle(meta_get('original_title'))
			info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': string(tmdb_id), 'tvdb': string(tvdb_id)}), info_tag.setIMDBNumber(imdb_id)
			info_tag.setPlot(meta_get('plot')), info_tag.setPlaycount(playcount), info_tag.setGenres(meta_get('genre')), info_tag.setYear(int(year))
			info_tag.setTagLine(meta_get('tagline')), info_tag.setStudios(meta_get('studio')), info_tag.setWriters(meta_get('writer')), info_tag.setDirectors(meta_get('director'))
			info_tag.setVotes(meta_get('votes')), info_tag.setMpaa(meta_get('mpaa')), info_tag.setDuration(meta_get('duration')), info_tag.setCountries(meta_get('country'))
			info_tag.setTrailer(meta_get('trailer')), info_tag.setPremiered(premiered)
			info_tag.setTvShowStatus(meta_get('status')), info_tag.setRating(meta_get('rating'))
			# Niente setCast: la skin del cast legge solo i nomi. Vedi kodi_utils.cast_label.
			_b6 = _perf()
			# 'Aggiungi ai preferiti' via: vedi il commento esteso in indexers/movies.py.
			_cast_props = {'fenlight.extras_params': extras_params, 'fenlight.options_params': options_params,
							'fenlight.more_like_this_params': more_like_this_params, 'hide_add_remove_favourite': 'true'}
			cast_names = cast_label(meta_get('cast'))
			if cast_names: _cast_props['fenlight.cast'] = cast_names
			set_properties(_cast_props)
			extra_ratings = meta_get('extra_ratings')
			if extra_ratings:
				_rp = {}
				for _k, _n in (('imdb', 'IMDb_Rating'), ('metascore', 'MetaCritic_Rating'), ('tomatometer', 'RottenTomatoes_Rating'), ('tomatousermeter', 'RottenTomatoes_UserMeter')):
					_r = extra_ratings.get(_k, {})
					_v = _r.get('rating', '').replace('%', '')
					if _v: _rp[_n] = _v
					_i = _r.get('icon', '')
					if _i: _rp[_n + '_Icon'] = _i
				_tmdb = meta_get('rating')
				if _tmdb: _rp['TMDb_Rating'] = str(_tmdb)
				if _rp: set_properties(_rp)
			paginator.phase_record(_b1 - _b0, _b2 - _b1, _b3 - _b2, _b4 - _b3, _b5 - _b4, _b6 - _b5, _perf() - _b6)
			self.append(((url_params, listitem, self.is_folder), _position))
		except: pass

	def worker(self):
		kodi_utils.tappa('tvshows.worker_in')
		# LOTTO 324 -- da qui in poi questa costruzione ha in mano visti, segnalibri e watchlist, e
		# quindi COPRE qualunque cambiamento di stato arrivato fin qui: una ricarica mirata per id
		# non serve piu'. Il timbro va prima delle letture, non dopo: cio' che conta e' che tutto
		# quello che si legge da questo istante in avanti sia gia' aggiornato.
		paginator.marca_stato_letto()
		self.current_date, self.current_time = get_datetime(), get_current_timestamp()
		self.tmdb_api_key, self.mpaa_region = tmdb_api_key(), mpaa_region()
		self.all_episodes, self.open_extras = default_all_episodes(), media_open_action('tvshow') == 1
		self.is_folder = False if self.open_extras else True
		self.watched_indicators = watched_indicators()
		self.watched_title = 'Trakt' if self.watched_indicators == 1 else 'Fen Light'
		self.watched_info = watched_info_tvshow(get_database(self.watched_indicators))
		# Watchlist Trakt: UNA lettura da cache per costruzione, non una per elemento. Serve solo a
		# decidere se la voce dice Aggiungi o Rimuovi. Import pigro: senza Trakt attivo non si paga il
		# caricamento di trakt_api a ogni lista, e con reuselanguageinvoker=false si pagherebbe davvero.
		if self.watched_indicators == 1:
			from apis.trakt_api import watchlist_tmdb_ids
			self.watchlist_ids = watchlist_tmdb_ids('shows')
		else: self.watchlist_ids = set()
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		paginator.phase_reset()
		kodi_utils.tappa('tvshows.preparato')
		# UNA lettura per l'intera lista, in sequenza. Vedi meta_cache.get_many.
		_pf0 = _perf()
		_ids = [i[1] for i in self.list] if self.custom_order else list(self.list)
		# LOTTO 333 -- una riga preparata serve anche le schede scadute: vedi movies.py.
		self._scadute, self._mancanti = [], []
		try: self.meta_prefetch = tvshow_meta_prefetch(self.id_type, _ids, self.current_time,
													self._scadute if self.interactive else None)
		except: self.meta_prefetch = {}
		paginator.log_prefetch('tvshows %s' % self.action, len(self.list), len(self.meta_prefetch), _perf() - _pf0)
		kodi_utils.tappa('tvshows.prefetch')
		if not self.interactive:
			self._resolve_missing(_ids)
			kodi_utils.tappa('tvshows.rete')
		# Costruzione in SEQUENZA: vedi la nota in Movies.worker -- sotto il pool le chiamate all'API
		# C++ costano fino a 74 volte tanto per l'effetto convoglio sul GIL, e qui non c'e' piu' I/O.
		if self.custom_order:
			for _position, _id in self.list: self.build_tvshow_content(_position, _id)
		else:
			for _position, _id in enumerate(self.list): self.build_tvshow_content(_position, _id)
			self.items.sort(key=lambda k: k[1])
			self.items = [i[0] for i in self.items]
		kodi_utils.tappa('tvshows.elementi')
		if self.interactive:
			tipo = self.PG_TIPO
			paginator.segnala_schede(self.pg_key, self.pg_params, 'tvshow', [(tipo, int(t)) for t in self._scadute],
									[(tipo, paginator.tmdb_di(t)) for t in self._mancanti if paginator.tmdb_di(t)])
		paginator.phase_report('tvshows %s' % self.action,
							('meta', 'prep+cm', 'setLabel', 'ctxmenu', 'setArt', 'infotag', 'cast+props'))
		return self.items

	# Prefisso del nome lista per azione: name_id porta solo il tmdb_id della serie di partenza,
	# il testo si compone qui. Sostituisce i vecchi parametri 'name'/'category_name', che portavano
	# la frase gia' fatta -- testo libero, quindi da percent-encodare, per ogni elemento di ogni lista.
	_LIST_NAME_PREFIX = {'imdb_more_like_this': 'More Like This based on %s', 'tmdb_tv_recommendations': 'Recommended based on %s'}

	def _resolve_list_name(self):
		# Se manca name_id (URL vecchia ancora in giro, widget salvato) resta il nome che c'era prima.
		name_id = self.params_get('name_id')
		if not name_id or self.params_get('name') or self.params_get('category_name'): return
		prefix = self._LIST_NAME_PREFIX.get(self.action)
		if not prefix: return
		try:
			# Una riga preparata legge solo dalla cache (lotto 333): la scheda del titolo di partenza c'e' quasi
			# sempre -- l'utente ci e' arrivato da li' -- e se non c'e' resta il nome che c'era.
			if self.interactive: meta = tvshow_meta_prefetch('tmdb_id', [name_id]).get('tmdb_id|%s' % name_id)
			else: meta = tvshow_meta('tmdb_id', name_id, tmdb_api_key(), mpaa_region(), get_datetime(), get_current_timestamp())
			if meta and meta.get('title'): self.category_name = prefix % meta['title']
		except: pass

	def _resolve_missing(self, ids):
		# Vedi Movies._resolve_missing: i thread restano solo dove il tempo e' attesa di rete.
		missing = []
		prefetch_get = self.meta_prefetch.get
		for media_id in ids:
			key = meta_prefetch_key(self.id_type, media_id, 'tvshow')
			if key and prefetch_get(key) is None: missing.append((key, media_id))
		if not missing: return
		def _fetch(entry):
			key, media_id = entry
			try:
				meta = tvshow_meta(self.id_type, media_id, self.tmdb_api_key, self.mpaa_region, self.current_date, self.current_time)
				if meta: self.meta_prefetch[key] = meta
			except: pass
		_t0 = _perf()
		threads = list(make_thread_list(_fetch, missing))
		[i.join() for i in threads]
		paginator.log_network('tvshows %s' % self.action, len(missing), _perf() - _t0)

	def paginate_list(self, data, page_no):
		if paginate(self.is_home):
			limit = page_limit(self.is_home)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_home: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages
