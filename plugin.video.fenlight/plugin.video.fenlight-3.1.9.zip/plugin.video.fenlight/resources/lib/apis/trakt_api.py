# -*- coding: utf-8 -*-
import json
import time
from caches import trakt_cache
from caches.settings_cache import get_setting, set_setting, settings_cache
from caches.base_cache import connect_database, checkpoint_database, TRAKT_AUTH_LOCK_CREATE
from caches.main_cache import cache_object
from caches.lists_cache import lists_cache_object
from modules import kodi_utils, settings
from modules.metadata import movie_meta_external_id, tvshow_meta_external_id
from modules.utils import sort_list, sort_for_article, make_thread_list, get_datetime, timedelta, replace_html_codes, copy2clip, title_key, traduci_episodio, jsondate_to_datetime as js2date

# 'requests' e la Session si creano alla PRIMA richiesta, non all'import (lotto 51). Erano a livello
# di modulo, quindi chiunque importasse trakt_api pagava l'albero di requests (urllib3, certifi, ssl,
# http.client, email) anche solo per leggere lo stato visto dal database locale. Misura del 24/08:
# build_season_list spendeva 2094 ms di import per 23 ms di lavoro. La Session resta una sola per
# interprete, esattamente come prima -- cambia solo QUANDO nasce.
_session = [None]

def _get_session():
	if _session[0] is None:
		from modules.kodi_utils import import_requests
		_session[0] = import_requests('trakt_api').Session()
	return _session[0]
sleep, with_media_removals, get_property = kodi_utils.sleep, kodi_utils.with_media_removals, kodi_utils.get_property
set_property = kodi_utils.set_property
logger, notification, xbmc_player, confirm_dialog = kodi_utils.logger, kodi_utils.notification, kodi_utils.xbmc_player, kodi_utils.confirm_dialog
kodi_dialog, addon_installed, addon_enabled, addon = kodi_utils.kodi_dialog, kodi_utils.addon_installed, kodi_utils.addon_enabled, kodi_utils.addon
path_check, get_icon, clear_property, remove_keys = kodi_utils.path_check, kodi_utils.get_icon, kodi_utils.clear_property, kodi_utils.remove_keys
execute_builtin, select_dialog, kodi_refresh = kodi_utils.execute_builtin, kodi_utils.select_dialog, kodi_utils.kodi_refresh
kodi_refresh_ids = kodi_utils.kodi_refresh_ids
progress_dialog, external, trakt_user_active, show_unaired_watchlist = kodi_utils.progress_dialog, kodi_utils.external, settings.trakt_user_active, settings.show_unaired_watchlist
lists_sort_order, trakt_client, trakt_secret, tmdb_api_key = settings.lists_sort_order, settings.trakt_client, settings.trakt_secret, settings.tmdb_api_key
clear_all_trakt_cache_data, cache_trakt_object, clear_trakt_calendar = trakt_cache.clear_all_trakt_cache_data, trakt_cache.cache_trakt_object, trakt_cache.clear_trakt_calendar
trakt_watched_cache, reset_activity, clear_trakt_list_contents_data = trakt_cache.trakt_watched_cache, trakt_cache.reset_activity, trakt_cache.clear_trakt_list_contents_data
restore_activity = trakt_cache.restore_activity
# Alzato dalle guardie self_mark quando saltano una ricostruzione: dice a trakt_sync_activities che il
# segnalibro delle attivita' NON puo' avanzare, perche' c'e' del lavoro non fatto. Vedi lotto 58.
# Le CATEGORIE di attivita' il cui lavoro e' stato rimandato in questo giro ('movies', 'episodes').
# Era un booleano, e da li' veniva il difetto del lotto 141: `restore_activity(cached)` rimetteva
# indietro il segnalibro di TUTTE le categorie, quindi il lavoro riuscito su watchlist ed episodi
# nello stesso giro veniva buttato e rifatto trenta secondi dopo. Un insieme dice QUALE rimandare, e
# il resto del giro resta buono.
# Serve anche a chi decide cosa dichiarare: 'rimandato' e 'non so cosa sia cambiato' tornavano
# entrambi None e non erano distinguibili, cosi' un lavoro NON FATTO faceva ricostruire i widget.
_SYNC_DEFERRED = set()
# Qui vivevano PROGRESS_RETRY_PROP e PROGRESS_RETRY_MAX (lotto 132): la riprova quando
# last_activities diceva 'cambiato' e sync/playback tornava identico. RIMOSSI dal lotto 133.
# Erano l'ennesima deduzione a tempo su uno stato che non era scritto: e infatti sbagliavano da
# soli -- 'azzera avanzamento' e' proprio il caso in cui l'attivita' cambia e la tabella no, perche'
# il lavoro l'abbiamo gia' fatto noi in locale, e la riprova scattava a vuoto su ENTRAMBE le
# macchine (log del 03/09, 03:29:54 e 03:30:25). Adesso una risposta vecchia non fa danni da sola:
# la riconciliazione tocca solo cio' che cambia, e una riga `synced` assente dallo snapshot e' una
# cancellazione qualunque sia stato il motivo dell'attivita'.
clear_daily_cache = trakt_cache.clear_daily_cache
clear_trakt_hidden_data = trakt_cache.clear_trakt_hidden_data
# LOTTO 119: qui vivevano anche clear_trakt_recommendations, clear_trakt_list_data e
# clear_trakt_favorites. Erano usate SOLO dai rami della sincronizzazione ora rimossi (vedi la nota
# 'strumenti morti' in trakt_sync_activities): le funzioni restano in caches/trakt_cache per chi le
# chiama da altrove, ma qui non ha piu' senso legarle a ogni import del modulo.
empty_setting_check = (None, 'empty_setting', '')
standby_date = '2050-01-01T01:00:00.000Z'
res_format = '%Y-%m-%dT%H:%M:%S.%fZ'
API_ENDPOINT = 'https://api.trakt.tv/%s'
history_page_limit = 250
timeout = 20
EXPIRY_1_DAY, EXPIRY_1_WEEK = 24, 168

def no_client_key():
	notification('Please set a valid Trakt Client ID Key')
	return None

def no_secret_key():
	notification('Please set a valid Trakt Client Secret Key')
	return None

# =============================================================================================
# L'AUTENTICAZIONE TRAKT (lotti 233-237)
#
# Il guasto da cui nasce questo blocco, dal log della Shield del 10/09 alle 21:11:43: quattro
# interpreti diversi -- il servizio e tre invocazioni del plugin -- hanno spedito a Trakt LO STESSO
# refresh token nello stesso decimo di secondo. Uno ha vinto, tre hanno preso 400; nella seconda
# ondata i perdenti hanno riletto il token appena ruotato e se lo sono giocato a loro volta. In
# 1,4 secondi il token e' stato ruotato tre volte e riusato cinque. Per Trakt il refresh token e'
# MONOUSO e ogni riuso e' un tentativo di replay.
#
# Tre proprieta' che questo blocco garantisce, e che prima non garantiva nessuno:
#
#   ATOMICITA'    access, refresh e scadenza sono UN valore solo, scritto una volta sola. Prima
#                 erano tre set_setting consecutivi: chi leggeva fra il primo e il secondo vedeva
#                 un refresh token nuovo accanto a un access token scaduto, concludeva 'ha gia'
#                 rinnovato qualcun altro', rispediva la richiesta con il token vecchio e
#                 riprendeva 401 -- ed e' QUELLO, non un token morto, ad aprire il dialogo di
#                 riautenticazione. Chi leggeva fra il secondo e il terzo trovava token nuovi ma
#                 scadenza vecchia e rinnovava di nuovo: e' cosi' che le ondate si alimentavano.
#   UNICITA'      un solo rinnovo per volta sulla macchina, arbitrato da una riga di settings.db.
#                 Chi non ottiene il lucchetto ASPETTA l'esito altrui invece di spendere il token.
#   LEGGIBILITA'  un 400 di Trakt e' una risposta, non un guasto: porta `error` e
#                 `error_description`. raise_for_status lo trasformava in eccezione, call_trakt
#                 tornava None e il ramo invalid_grant era codice irraggiungibile -- ogni rifiuto
#                 finiva a log come 'Trakt unreachable'.
#
# Riferimento: docs.trakt.tv/docs/authentication-oauth -- access token 7 giorni (erano 90, poi 24
# ore da marzo 2025), refresh token monouso e senza scadenza per inattivita'.
# =============================================================================================
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'
# Solo un ripiego per una risposta senza expires_in: il valore vero arriva sempre da Trakt, che
# l'ha gia' cambiato tre volte e lo cambiera' ancora. Non va usato per dedurre una scadenza.
TOKEN_LIFETIME_FALLBACK = 604800
RENEW_MARGIN = 86400
# Deve superare il tempo peggiore di UNA richiesta, altrimenti un altro processo puo' rubare il
# lucchetto mentre il primo e' ancora in volo -- ed e' esattamente la doppia rotazione da evitare.
# http_client non riprova i timeout ma puo' riaprire una connessione riciclata, quindi il peggio e'
# circa due volte `timeout`. Il prezzo di un valore alto e' che un processo ucciso a meta' rotazione
# blocca i rinnovi fino alla scadenza: costa un giro di servizio, non l'autenticazione.
ROTATION_LOCK_TTL = (timeout * 2) + 5
ROTATION_WAIT = 8
ROTATION_POLL = 250
AUTH_SETTING = 'trakt.auth'
AUTH_PROP = 'fenlight.trakt.auth'
# Il token che Trakt ha gia' rifiutato in questa sessione, con il VERDETTO davanti: ripresentarlo a
# ogni widget aggiunge solo tentativi di replay al conto che tiene lui. Si azzera da solo appena il
# token cambia, perche' e' memorizzato insieme al token a cui si riferisce.
REJECTED_PROP = 'fenlight.trakt.rotation_rejected'
PROMPTED_PROP = 'fenlight.trakt.reauth_prompted'
# La tabella e' definita in caches/base_cache.TRAKT_AUTH_LOCK_CREATE, con il perche'.
ROTATION_LOCK_ACQUIRE = 'UPDATE trakt_auth_lock SET expires = ? WHERE id = 1 AND expires < ?'
# Il rilascio e' CONDIZIONATO alla scadenza che avevamo scritto noi: fa da gettone di
# proprieta'. Senza, un processo rimasto indietro (richiesta piu' lunga della scadenza, lucchetto
# nel frattempo ripreso da un altro) libererebbe il lucchetto di chi sta ancora ruotando.
ROTATION_LOCK_RELEASE = 'UPDATE trakt_auth_lock SET expires = 0 WHERE id = 1 AND expires = ?'
ROTATION_LOCK_STATE = 'SELECT expires FROM trakt_auth_lock WHERE id = 1'
_bootstrapped = [False]
_lock_ready = [False]

def _auth_decode(raw):
	if not raw: return '', '', 0.0
	try:
		record = json.loads(raw)
		return record.get('access') or '', record.get('refresh') or '', float(record.get('expires') or 0)
	except Exception:
		logger('FenLight Trakt', 'record di autenticazione illeggibile, trattato come assente')
		return '', '', 0.0

def _auth_read():
	"""(access, refresh, scadenza) coerenti fra loro: o tutti e tre, o nessuno."""
	if not _bootstrapped[0]: _auth_bootstrap()
	return _auth_decode(get_setting(AUTH_PROP))

def _auth_read_stored():
	"""Come _auth_read ma salta la proprieta' di finestra e va al database.

	Serve dentro il lucchetto: la proprieta' e' una copia pubblicata, e una copia non puo' fare da
	arbitro -- sync_settings, per esempio, ripubblica in blocco una fotografia delle impostazioni.
	"""
	return _auth_decode(settings_cache.get(AUTH_SETTING))

def _auth_write(access, refresh, expires):
	"""Una scrittura sola, quindi nessuno puo' osservare uno stato misto. Vero se e' riuscita."""
	try:
		set_setting(AUTH_SETTING, json.dumps({'access': access, 'refresh': refresh, 'expires': round(float(expires), 3)}))
		checkpoint_database('settings_db')
		return True
	except Exception as e:
		# Non c'e' niente da recuperare: Trakt ha gia' ruotato dalla sua parte, quindi il token che
		# abbiamo in mano e' morto e il suo sostituto e' andato perso. Va detto forte.
		logger('FenLight Trakt', "SCRITTURA DEL RECORD FALLITA (%s): il token appena ruotato e' perduto" % e)
		return False

def _auth_clear():
	# Azzerare e' scrivere un record vuoto, non un percorso a parte: uno scrittore solo significa
	# una sola gestione dell'errore e una sola garanzia di durata.
	_auth_write('', '', 0)
	clear_property(REJECTED_PROP)
	clear_property(PROMPTED_PROP)

def _auth_bootstrap():
	"""Migrazione una tantum, una volta per interprete. Non tocca nulla se non c'e' nulla da fare."""
	_bootstrapped[0] = True
	try:
		legacy = [get_setting('fenlight.trakt.%s' % k) for k in ('token', 'refresh')]
		if not get_setting(AUTH_PROP) and all(v and v not in empty_setting_check and v != '0' for v in legacy):
			try: expires = float(get_setting('fenlight.trakt.expires', '0'))
			except (TypeError, ValueError): expires = 0.0
			if _auth_write(legacy[0], legacy[1], expires):
				logger('FenLight Trakt', 'record di autenticazione migrato dai tre setting separati')
		# I tre id restano dichiarati in settings_cache (sync_settings cancella gli id che non
		# conosce) ma svuotati: due copie dello stesso stato sono esattamente il difetto che questi
		# lotti chiudono, e un valore fossile che riaffiora fra un anno e' peggio di nessun valore.
		for setting_id in ('trakt.token', 'trakt.refresh', 'trakt.expires'):
			if get_setting('fenlight.%s' % setting_id) not in ('0', ''): set_setting(setting_id, '0')
		# Residuo delle chiavi revocate: trakt_client()/trakt_secret() restituiscono la costante e
		# ignorano l'impostazione, quindi un valore diverso qui e' solo un client id morto mostrato
		# all'utente nel pannello. Sulla Shield era ancora 1038ef32..., revocato da Trakt (403).
		for setting_id, in_use in (('trakt.client', trakt_client()), ('trakt.secret', trakt_secret())):
			if in_use not in empty_setting_check and get_setting('fenlight.%s' % setting_id) != in_use:
				set_setting(setting_id, in_use)
	except Exception as e: logger('FenLight Trakt', "bootstrap dell'autenticazione non riuscito: %s" % e)

def _mark_rejected(verdict, refresh_token):
	"""Ricorda per questa sessione che Trakt ha rifiutato QUESTO token, e con quale verdetto.

	I due verdetti sono quelli che distingue l'API, e la differenza cambia cosa si dice all'utente:

	  'grant'   invalid_grant -- il token dell'utente e' morto. Riautorizzare ripara, e ha senso
	            chiederlo: e' il caso della migrazione OAuth di luglio 2026.
	  'client'  invalid_client -- e' la CHIAVE dell'applicazione a non valere piu'. Riautorizzare
	            fallirebbe allo stesso modo, quindi non si disturba nessuno: e' successo davvero il
	            12/08/2026, quando Trakt cancello' l'app originale di Fen Light.
	"""
	set_property(REJECTED_PROP, '%s|%s' % (verdict, refresh_token))

def _rejection_verdict(refresh_token):
	"""(rifiutato, esito). L'esito e' gia' nella forma che restituisce trakt_refresh_token."""
	marked = get_property(REJECTED_PROP)
	if not marked or not marked.endswith('|%s' % refresh_token): return False, None
	return True, (False if marked.startswith('grant|') else None)

def _needs_renewal(access, refresh, expires):
	"""Il rinnovo anticipato si fa solo quando SAPPIAMO che la scadenza e' vicina.

	Una scadenza sconosciuta (0: per esempio un record migrato dai vecchi setting) non significa
	'rinnova adesso'. Con la rete assente si tradurrebbe in un tentativo di rotazione da venti secondi
	davanti a ogni chiamata; e se il token e' davvero morto lo dice Trakt con un 401, che costa una
	richiesta sola e non consuma nessuna rotazione.
	"""
	return bool(access and refresh and expires and time.time() > expires - RENEW_MARGIN)

def _expires_in(payload):
	try: return int(payload.get('expires_in') or TOKEN_LIFETIME_FALLBACK)
	except (TypeError, ValueError): return TOKEN_LIFETIME_FALLBACK

def _oauth_post(path, data):
	"""Le rotte oauth/* NON passano da call_trakt, e non e' un dettaglio di stile.

	call_trakt e' il trasporto dell'API: bearer, rinnovo su 401, attesa su 429, paginazione. Qui non
	serve niente di tutto questo, e il rinnovo su 401 sarebbe per giunta circolare. Soprattutto: qui
	un 400 non e' un errore da sollevare, e' la risposta che dice PERCHE'.

	Torna (stato, payload). Stato 0 significa che non siamo arrivati a Trakt.
	"""
	CLIENT_ID = trakt_client()
	if CLIENT_ID in empty_setting_check: return 0, {}
	headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': CLIENT_ID}
	try: response = _get_session().post(API_ENDPOINT % path, json=data, headers=headers, timeout=timeout)
	except Exception as e:
		logger('FenLight Trakt', '%s non raggiungibile: %s' % (path, e))
		return 0, {}
	try: payload = response.json()
	except Exception: payload = {}
	return response.status_code, payload if isinstance(payload, dict) else {}

def _rotation_lock_acquire():
	"""Torna la scadenza scritta se il lucchetto e' nostro, 0 altrimenti.

	L'UPDATE condizionato e' atomico fra processi: o cambia una riga (preso) o zero (di qualcun
	altro). Un lucchetto scaduto viene ripreso dalla stessa istruzione, senza codice di recupero.
	La scadenza restituita va ripassata a _rotation_lock_release: e' il gettone di proprieta'.
	"""
	now = time.time()
	deadline = now + ROTATION_LOCK_TTL
	try:
		dbcon = connect_database('settings_db')
		if not _lock_ready[0]:
			# make_databases() gira all'avvio del servizio, ma un interprete del plugin puo' non
			# averlo mai chiamato: la tabella si crea qui, una volta per interprete.
			for command in TRAKT_AUTH_LOCK_CREATE: dbcon.execute(command)
			_lock_ready[0] = True
		return deadline if dbcon.execute(ROTATION_LOCK_ACQUIRE, (deadline, now)).rowcount == 1 else 0
	except Exception as e:
		# Senza arbitro si preferisce NON ruotare: un rinnovo saltato costa una chiamata fallita,
		# un rinnovo in corsa costa l'autenticazione.
		logger('FenLight Trakt', 'lucchetto del rinnovo non disponibile (%s)' % e)
		return 0

def _rotation_lock_release(deadline):
	try: connect_database('settings_db').execute(ROTATION_LOCK_RELEASE, (deadline,))
	except Exception as e: logger('FenLight Trakt', "rilascio del lucchetto fallito (%s), scadra' da solo" % e)

def _rotation_lock_held():
	try: return connect_database('settings_db').execute(ROTATION_LOCK_STATE).fetchone()[0] > time.time()
	except Exception: return False

def _ask_to_authorize():
	"""Una sola richiesta per sessione di Kodi, e mai durante una riproduzione.

	Prima ogni interprete poteva aprirne una per conto suo: con quattro processi in corsa sullo
	stesso token, l'utente si trovava davanti quattro dialoghi identici.
	"""
	if xbmc_player().isPlaying(): return False
	if get_property(PROMPTED_PROP) == 'true': return False
	set_property(PROMPTED_PROP, 'true')
	return confirm_dialog(heading='Authorize Trakt', text='You must authenticate with Trakt. Do you want to authenticate now?')

def call_trakt(path, params=None, data=None, is_delete=False, with_auth=True, method=None, pagination=False, page_no=1):
	def send_query():
		resp = None
		if with_auth:
			access, refresh, expires = _auth_read()
			# Il rinnovo anticipato legge un record coerente, quindi non puo' piu' innescarsi perche'
			# ha visto una scadenza vecchia accanto a un token nuovo.
			if _needs_renewal(access, refresh, expires):
				trakt_refresh_token()
				access = _auth_read()[0]
			if access: headers['Authorization'] = 'Bearer ' + access
		try:
			if method:
				if method == 'post':
					resp = _get_session().post(API_ENDPOINT % path, headers=headers, timeout=timeout)
				elif method == 'delete':
					resp = _get_session().delete(API_ENDPOINT % path, headers=headers, timeout=timeout)
				elif method == 'sort_by_headers':
					resp = _get_session().get(API_ENDPOINT % path, params=params, headers=headers, timeout=timeout)
			elif data is not None:
				resp = _get_session().post(API_ENDPOINT % path, json=data, headers=headers, timeout=timeout)
			elif is_delete: resp = _get_session().delete(API_ENDPOINT % path, headers=headers, timeout=timeout)
			else: resp = _get_session().get(API_ENDPOINT % path, params=params, headers=headers, timeout=timeout)
			if resp.status_code not in (401, 429): resp.raise_for_status()
		except Exception as e: return logger('Trakt Error', str(e))
		return resp
	if params is None: params = {}
	CLIENT_ID = trakt_client()
	if CLIENT_ID in empty_setting_check: return no_client_key()
	headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': CLIENT_ID}
	if pagination: params['page'] = page_no
	response = send_query()
	try: status_code = response.status_code
	except: return None
	if status_code == 401:
		# Una 401 senza credenziali non si ripara rinnovando: e' la chiave dell'applicazione a non
		# andare bene, e il rinnovo non la tocca.
		if not with_auth: return None
		logger('FenLight Trakt', '401 su path=%s - si tenta il rinnovo' % path)
		refreshed = trakt_refresh_token()
		if refreshed is None:
			# Non sappiamo se i token siano morti: puo' essere rete assente, o il rinnovo di un
			# altro processo che non si e' concluso in tempo. Nel dubbio non si disturba l'utente.
			return logger('FenLight Trakt', "rinnovo non concluso su path=%s - nessuna richiesta all'utente" % path)
		if refreshed:
			response = send_query()
			try: status_code = response.status_code
			except: return None
		if status_code == 401:
			if not (_ask_to_authorize() and trakt_authenticate()): return None
			response = send_query()
			try: status_code = response.status_code
			except: return None
	elif status_code == 429:
		retry_headers = response.headers
		if 'Retry-After' in retry_headers:
			sleep(1000 * int(retry_headers.get('Retry-After', 5)))
			response = send_query()
	try:
		response.encoding = 'utf-8'
		result = response.json()
	except: return None
	resp_headers = response.headers
	if method == 'sort_by_headers' and 'X-Sort-By' in resp_headers and 'X-Sort-How' in resp_headers:
		try: result = sort_list(resp_headers['X-Sort-By'], resp_headers['X-Sort-How'], result)
		except: pass
	if pagination: return (result, resp_headers['X-Pagination-Page-Count'])
	else: return result

def trakt_get_device_code():
	CLIENT_ID = trakt_client()
	if CLIENT_ID in empty_setting_check: return no_client_key()
	data = {'client_id': CLIENT_ID}
	result = call_trakt('oauth/device/code', data=data, with_auth=False)
	if not result or 'device_code' not in result:
		error = (result or {}).get('error_description') or (result or {}).get('error') or 'no response from Trakt'
		logger('FenLight Trakt', 'device code request FAILED: %s' % error)
		notification('Trakt: %s' % error, 4000)
		return None
	return result

def trakt_get_device_token(device_codes):
	CLIENT_ID = trakt_client()
	if CLIENT_ID in empty_setting_check: return no_client_key()
	CLIENT_SECRET = trakt_secret()
	if CLIENT_SECRET in empty_setting_check: return no_secret_key()
	result = None
	try:
		headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': CLIENT_ID}
		data = {'code': device_codes['device_code'], 'client_id': CLIENT_ID, 'client_secret': CLIENT_SECRET}
		start = time.time()
		expires_in = device_codes['expires_in']
		sleep_interval = device_codes['interval']
		user_code = str(device_codes['user_code'])
		try: copy2clip(user_code)
		except: pass
		content = '[CR]Navigate to: [B]%s[/B][CR]Enter the following code: [B]%s[/B]' % (str(device_codes['verification_url']), user_code)
		progressDialog = progress_dialog('Trakt Authorize', get_icon('trakt_qrcode'))
		progressDialog.update(content, 0)
		try:
			time_passed = 0
			while not progressDialog.iscanceled() and time_passed < expires_in:
				sleep(max(sleep_interval, 1)*1000)
				response = _get_session().post(API_ENDPOINT % 'oauth/device/token', data=json.dumps(data), headers=headers, timeout=timeout)
				status_code = response.status_code
				if status_code == 200:
					result = response.json()
					break
				elif status_code == 400:
					time_passed = time.time() - start
					progress = int(100 * time_passed/expires_in)
					progressDialog.update(content, progress)
				else:
					logger('FenLight Trakt', 'device token poll returned %s: %s' % (status_code, response.text[:200]))
					break
		except Exception as e: logger('FenLight Trakt', 'device token poll error: %s' % e)
		try: progressDialog.close()
		except: pass
	except Exception as e: logger('FenLight Trakt', 'device token request FAILED: %s' % e)
	return result

def trakt_refresh_token():
	"""Rinnova la coppia di token. Tre esiti, e la differenza fra loro conta:

	  True   c'e' un access token valido adesso -- l'abbiamo ruotato noi o l'ha ruotato un altro
	  False  Trakt ha RIFIUTATO: serve una nuova autorizzazione, ed e' l'unico caso in cui abbia
			 senso disturbare l'utente
	  None   non si e' concluso (rete assente, o il rinnovo di un altro non finito in tempo): i
			 token memorizzati possono essere ancora buoni, quindi non si chiede niente a nessuno
	"""
	# Prima si guarda se c'e' qualcosa da rinnovare: senza account le chiavi non c'entrano nulla, e
	# annunciare 'Please set a valid Trakt Client ID Key' sarebbe indicare la causa sbagliata.
	refresh_token = _auth_read()[1]
	if not refresh_token: return False
	CLIENT_ID, CLIENT_SECRET = trakt_client(), trakt_secret()
	if CLIENT_ID in empty_setting_check:
		no_client_key()
		return False
	if CLIENT_SECRET in empty_setting_check:
		no_secret_key()
		return False
	rejected, verdict = _rejection_verdict(refresh_token)
	if rejected: return verdict
	deadline = _rotation_lock_acquire()
	if not deadline: return _await_rotation(refresh_token)
	try:
		# Dentro il lucchetto si rilegge dal database, non dalla proprieta': fra il momento in cui
		# abbiamo letto e quello in cui abbiamo ottenuto il lucchetto puo' essersi infilato un
		# rinnovo altrui, e ruotare due volte lo stesso token e' il difetto che stiamo chiudendo.
		stored_refresh = _auth_read_stored()[1]
		if not stored_refresh: return False
		if stored_refresh != refresh_token: return True
		return _rotate(CLIENT_ID, CLIENT_SECRET, stored_refresh)
	finally: _rotation_lock_release(deadline)

def _rotate(CLIENT_ID, CLIENT_SECRET, refresh_token):
	data = {
		'client_id': CLIENT_ID, 'client_secret': CLIENT_SECRET, 'redirect_uri': REDIRECT_URI,
		'grant_type': 'refresh_token', 'refresh_token': refresh_token}
	status, payload = _oauth_post('oauth/token', data)
	if status == 200:
		access, new_refresh = payload.get('access_token'), payload.get('refresh_token')
		if not (access and new_refresh):
			# A log finiscono le CHIAVI, mai i valori: qui dentro passano dei segreti.
			logger('FenLight Trakt', 'rinnovo: 200 senza coppia completa, campi ricevuti %s' % sorted(payload))
			return None
		expires_in = _expires_in(payload)
		if not _auth_write(access, new_refresh, time.time() + expires_in): return None
		clear_property(REJECTED_PROP)
		logger('FenLight Trakt', 'token ruotato, valido per %s secondi' % expires_in)
		return True
	if status in (400, 401, 403):
		error, description = payload.get('error') or '?', payload.get('error_description') or '?'
		if error == 'invalid_client':
			_mark_rejected('client', refresh_token)
			logger('FenLight Trakt', "rinnovo RIFIUTATO: non vale la chiave dell'applicazione (%s %s: %s) - "
					'riautorizzare non riparerebbe nulla' % (status, error, description))
			return None
		_mark_rejected('grant', refresh_token)
		logger('FenLight Trakt', 'rinnovo RIFIUTATO da Trakt (%s %s: %s) - serve una nuova autorizzazione'
				% (status, error, description))
		return False
	logger('FenLight Trakt', 'rinnovo non concluso (stato %s) - i token memorizzati restano validi' % (status or 'nessuna risposta'))
	return None

def _await_rotation(stale_refresh):
	"""Chi non ha preso il lucchetto ASPETTA l'esito altrui invece di spendere il token.

	E' il passo che mancava: nel log del 10/09 i perdenti rileggevano il token appena ruotato e lo
	bruciavano a loro volta, un'ondata dopo l'altra. Chi aspetta eredita anche il verdetto, perche'
	un rifiuto vale per tutti: e' lo stesso token.
	"""
	deadline = time.time() + ROTATION_WAIT
	while time.time() < deadline:
		sleep(ROTATION_POLL)
		if _auth_read_stored()[1] not in ('', stale_refresh): return True
		if not _rotation_lock_held(): break
	rejected, verdict = _rejection_verdict(stale_refresh)
	return verdict if rejected else None

def trakt_ensure_token():
	"""Rinnova in anticipo, se serve. La chiama il servizio a ogni giro.

	Il servizio esiste prima dei widget e vive quanto Kodi: se il rinnovo avviene qui, gli
	interpreti del plugin trovano un token gia' buono e non si mettono nemmeno in coda. Non
	sostituisce il lucchetto -- all'avvio servizio e widget partono insieme, e nel log del 10/09 li
	separavano centodieci millisecondi -- ma fa in modo che il lucchetto sia raramente conteso.
	"""
	access, refresh, expires = _auth_read()
	if not (access and refresh): return False
	if not _needs_renewal(access, refresh, expires): return True
	return trakt_refresh_token() is True

def trakt_authenticate(dummy=''):
	code = trakt_get_device_code()
	if not code: return False
	token = trakt_get_device_token(code) or {}
	access, refresh = token.get('access_token'), token.get('refresh_token')
	if not (access and refresh):
		# Senza refresh token l'autorizzazione muore alla prima scadenza e non e' rinnovabile:
		# meglio dichiararla fallita adesso che scoprirlo fra sette giorni. Prima si scriveva
		# l'access token e SOLO POI si leggeva token["refresh_token"]: se fosse mancato restava un
		# access token orfano, e con lui una riautenticazione forzata ogni settimana.
		if token: logger('FenLight Trakt', 'autorizzazione senza coppia completa, campi ricevuti %s' % sorted(token))
		notification('Trakt Error Authorizing', 3000)
		return False
	if not _auth_write(access, refresh, time.time() + _expires_in(token)):
		notification('Trakt Error Authorizing', 3000)
		return False
	clear_property(REJECTED_PROP)
	clear_property(PROMPTED_PROP)
	set_setting('watched_indicators', '1')
	sleep(1000)
	try:
		user = call_trakt('users/me')
		set_setting('trakt.user', str(user['username']))
	except: pass
	notification('Trakt Account Authorized', 3000)
	trakt_sync_activities(force_update=True)
	return True

def trakt_revoke_authentication(dummy=''):
	# L'ordine e' tutto: il token va CATTURATO prima di essere cancellato. Prima la revoca partiva
	# dopo l'azzeramento e spediva a Trakt un token vuoto -- da noi l'account risultava scollegato,
	# su Trakt la sessione restava viva.
	access = _auth_read()[0]
	_auth_clear()
	set_setting('trakt.user', 'empty_setting')
	set_setting('watched_indicators', '0')
	clear_all_trakt_cache_data(silent=True, refresh=False)
	notification('Trakt Account Authorization Reset', 3000)
	if not access: return
	CLIENT_ID, CLIENT_SECRET = trakt_client(), trakt_secret()
	if CLIENT_ID in empty_setting_check: return no_client_key()
	if CLIENT_SECRET in empty_setting_check: return no_secret_key()
	status = _oauth_post('oauth/revoke', {'token': access, 'client_id': CLIENT_ID, 'client_secret': CLIENT_SECRET})[0]
	logger('FenLight Trakt', 'revoca della sessione su Trakt: stato %s' % (status or 'nessuna risposta'))

def trakt_movies_trending(page_no):
	string = 'trakt_movies_trending_%s' % page_no
	params = {'path': 'movies/trending/%s', 'params': {'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_movies_trending_recent(page_no):
	current_year = get_datetime().year
	years = '%s-%s' % (str(current_year-1), str(current_year))
	string = 'trakt_movies_trending_recent_%s' % page_no
	params = {'path': 'movies/trending/%s', 'params': {'limit': 20, 'years': years}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_movies_top10_boxoffice(page_no):
	string = 'trakt_movies_top10_boxoffice'
	params = {'path': 'movies/boxoffice/%s', 'pagination': False}
	return lists_cache_object(get_trakt, string, params)

def trakt_movies_most_watched(page_no):
	string = 'trakt_movies_most_watched_%s' % page_no
	params = {'path': 'movies/watched/daily/%s', 'params': {'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_movies_most_favorited(page_no):
	string = 'trakt_movies_most_favorited%s' % page_no
	params = {'path': 'movies/favorited/daily/%s', 'params': {'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_recommendations(media_type):
	string = 'trakt_recommendations_%s' % (media_type)
	params = {'path': '/recommendations/%s', 'path_insert': media_type, 'with_auth': True,
			'params': {'limit': 50, 'ignore_collected': 'true', 'ignore_watchlisted': 'true'}, 'pagination': False}
	return cache_trakt_object(get_trakt, string, params)

def trakt_tv_trending(page_no):
	string = 'trakt_tv_trending_%s' % page_no
	params = {'path': 'shows/trending/%s', 'params': {'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_tv_trending_recent(page_no):
	current_year = get_datetime().year
	years = '%s-%s' % (str(current_year-1), str(current_year))
	string = 'trakt_tv_trending_recent_%s' % page_no
	params = {'path': 'shows/trending/%s', 'params': {'limit': 20, 'years': years}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_tv_most_watched(page_no):
	string = 'trakt_tv_most_watched_%s' % page_no
	params = {'path': 'shows/watched/daily/%s', 'params': {'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_tv_most_favorited(page_no):
	string = 'trakt_tv_most_favorited_%s' % page_no
	params = {'path': 'shows/favorited/daily/%s', 'params': {'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_tv_certifications(certification, page_no):
	string = 'trakt_tv_certifications_%s_%s' % (certification, page_no)
	params = {'path': 'shows/collected/all%s', 'params': {'certifications': certification, 'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params, expiration= EXPIRY_1_WEEK)

def trakt_anime_trending(page_no):
	string = 'trakt_anime_trending_%s' % page_no
	params = {'path': 'shows/trending/%s', 'params': {'genres': 'anime', 'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_anime_trending_recent(page_no):
	current_year = get_datetime().year
	years = '%s-%s' % (str(current_year-1), str(current_year))
	string = 'trakt_anime_trending_recent_%s' % page_no
	params = {'path': 'shows/trending/%s', 'params': {'genres': 'anime', 'limit': 20, 'years': years}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_anime_most_watched(page_no):
	string = 'trakt_anime_most_watched_%s' % page_no
	params = {'path': 'shows/watched/daily/%s', 'params': {'genres': 'anime', 'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_anime_most_favorited(page_no):
	string = 'trakt_anime_most_favorited_%s' % page_no
	params = {'path': 'shows/favorited/daily/%s', 'params': {'genres': 'anime', 'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params)

def trakt_anime_certifications(certification, page_no):
	string = 'trakt_anime_certifications_%s_%s' % (certification, page_no)
	params = {'path': 'shows/collected/all%s', 'params': {'certifications': certification, 'genres': 'anime', 'limit': 20}, 'page_no': page_no}
	return lists_cache_object(get_trakt, string, params, expiration= EXPIRY_1_WEEK)

def trakt_get_hidden_items(list_type):
	def _get_trakt_ids(item):
		tmdb_id = get_trakt_tvshow_id(item['show']['ids'])
		results_append(tmdb_id)
	def _process(params):
		hidden_data = get_trakt(params)
		threads = list(make_thread_list(_get_trakt_ids, hidden_data))
		[i.join() for i in threads]
		return results
	results = []
	results_append = results.append
	string = 'trakt_hidden_items_%s' % list_type
	params = {'path': 'users/hidden/%s', 'path_insert': list_type, 'params': {'limit': 1500, 'type': 'show'}, 'with_auth': True, 'pagination': False}
	return cache_trakt_object(_process, string, params)

def trakt_watched_status_mark(action, media, media_id, tvdb_id=0, season=None, episode=None, key='tmdb'):
	if action == 'mark_as_watched': url, result_key = 'sync/history', 'added'
	else: url, result_key = 'sync/history/remove', 'deleted'
	if media == 'movies':
		success_key = 'movies'
		data = {'movies': [{'ids': {key: media_id}}]}
	else:
		success_key = 'episodes'
		if media == 'episode': data = {'shows': [{'seasons': [{'episodes': [{'number': int(episode)}], 'number': int(season)}], 'ids': {key: media_id}}]}
		elif media =='shows': data = {'shows': [{'ids': {key: media_id}}]}
		else: data = {'shows': [{'ids': {key: media_id}, 'seasons': [{'number': int(season)}]}]}#season
	result = call_trakt(url, data=data)
	if not result: return logger('FenLight Trakt', 'watched status update FAILED for %s %s' % (media, media_id))
	success = result.get(result_key, {}).get(success_key, 0) > 0
	if not success:
		if media != 'movies' and tvdb_id != 0 and key != 'tvdb': return trakt_watched_status_mark(action, media, tvdb_id, 0, season, episode, 'tvdb')
	return success

def trakt_progress(action, media, media_id, percent, season=None, episode=None, resume_id=None, refresh_trakt=False):
	if action == 'clear_progress':
		url = 'sync/playback/%s' % resume_id
		result = call_trakt(url, is_delete=True)
	else:
		url = 'scrobble/pause'
		if media in ('movie', 'movies'): data = {'movie': {'ids': {'tmdb': media_id}}, 'progress': float(percent)}
		else: data = {'show': {'ids': {'tmdb': media_id}}, 'episode': {'season': int(season), 'number': int(episode)}, 'progress': float(percent)}
		try: resume_id = (call_trakt(url, data=data) or {}).get('id', 0)
		except: resume_id = 0
	if refresh_trakt: trakt_sync_activities()
	return resume_id

def trakt_scrobble_start(media, media_id, season=None, episode=None, progress=0.0):
	try:
		if media in ('movie', 'movies'): data = {'movie': {'ids': {'tmdb': media_id}}, 'progress': float(progress)}
		else: data = {'show': {'ids': {'tmdb': media_id}}, 'episode': {'season': int(season), 'number': int(episode)}, 'progress': float(progress)}
		call_trakt('scrobble/start', data=data)
	except: pass

def trakt_scrobble_stop(media, media_id, percent, season=None, episode=None):
	try:
		if media in ('movie', 'movies'): data = {'movie': {'ids': {'tmdb': media_id}}, 'progress': float(percent)}
		else: data = {'show': {'ids': {'tmdb': media_id}}, 'episode': {'season': int(season), 'number': int(episode)}, 'progress': float(percent)}
		call_trakt('scrobble/stop', data=data)
	except: pass

def trakt_collection_lists(media_type, list_type=None):
	data = trakt_fetch_collection_watchlist('collection', media_type)
	if list_type == 'recent':
		data.sort(key=lambda k: k['collected_at'], reverse=True)
		data = data[:20]
	return data

def trakt_watchlist_lists(media_type, list_type=None):
	data = trakt_fetch_collection_watchlist('watchlist', media_type)
	if list_type == 'recent':
		data.sort(key=lambda k: k['collected_at'], reverse=True)
		data = data[:20]
	return data

def trakt_collection(media_type, dummy_arg):
	data = trakt_fetch_collection_watchlist('collection', media_type)
	sort_order = lists_sort_order('collection')
	if sort_order == 0: data = sort_for_article(data, 'title')
	elif sort_order == 1: data.sort(key=lambda k: k['collected_at'], reverse=True)
	else: data.sort(key=lambda k: k['released'], reverse=True)
	return data

def trakt_watchlist(media_type, dummy_arg):
	data = trakt_fetch_collection_watchlist('watchlist', media_type)
	if not show_unaired_watchlist():
		current_date = get_datetime()
		str_format = '%Y-%m-%d' if media_type in ('movie', 'movies') else res_format
		data = [i for i in data if i.get('released', None) and js2date(i.get('released'), str_format, remove_time=True) <= current_date]
	sort_order = lists_sort_order('watchlist')
	if sort_order == 0: data = sort_for_article(data, 'title')
	elif sort_order == 1: data.sort(key=lambda k: k['collected_at'], reverse=True)
	else: data.sort(key=lambda k: k.get('released'), reverse=True)
	return data

def trakt_fetch_collection_watchlist(list_type, media_type, rinnova=False):
	def _process(params):
		data = get_trakt(params)
		# Nel log della Shield del 10/09: due 'BUILD FALLITA ... NoneType object is not iterable' di
		# fila, cioe' il widget della watchlist che esplode mentre il token si stava rinnovando.
		# Una chiamata non riuscita non e' una watchlist vuota: si torna None, cache_trakt_object
		# non memorizza, e il giro dopo si riprova.
		if data is None: return None
		if list_type == 'watchlist': data = [i for i in data if i['type'] == key]
		return [{'media_ids': {'tmdb': i[key]['ids'].get('tmdb', ''), 'imdb': i[key]['ids'].get('imdb', ''), 'tvdb': i[key]['ids'].get('tvdb', '')}, 'title': i[key]['title'],
				'collected_at': i.get(collected_at), 'released': i[key].get(r_key) if i[key].get(r_key) else ('2050-01-01' if media_type in ('movie', 'movies') else standby_date)}
				for i in data]
	key, r_key, string_insert = ('movie', 'released', 'movie') if media_type in ('movie', 'movies') else ('show', 'first_aired', 'tvshow')
	collected_at = 'listed_at' if list_type == 'watchlist' else 'collected_at' if media_type in ('movie', 'movies') else 'last_collected_at'
	string = 'trakt_%s_%s' % (list_type, string_insert)
	path = 'sync/%s/%s?extended=full'
	params = {'path': path, 'path_insert': (list_type, media_type), 'with_auth': True, 'pagination': False}
	return cache_trakt_object(_process, string, params, rinnova) or []

def _tmdb_ids_from_data(data):
	# I dati spediti a Trakt hanno forma {'movies'|'shows': [{'ids': {'tmdb'|'imdb'|'tvdb': id}}]}.
	# Al refresh mirato servono i soli tmdb_id, perche' sono quelli che paginator pubblica per ogni
	# contenitore. Se l'elemento era identificato per imdb o tvdb la lista esce vuota e il chiamante
	# resta sul refresh globale: nessun caso peggiora rispetto a prima.
	ids = []
	try:
		for items in data.values():
			for item in items:
				tmdb_id = item.get('ids', {}).get('tmdb')
				if tmdb_id: ids.append(str(tmdb_id))
	except: pass
	return ids

def _refresh_for_data(data):
	# Togliere un titolo da una lista cambia i widget che quel titolo lo contengono, non tutti gli
	# altri. Dentro una finestra di directory (my_lists, watchlist, collection) il sondaggio dei
	# contenitori 500-520 non trova nulla e kodi_refresh_ids ricade da sola sul globale, che li' e'
	# proprio quello che serve per rileggere la cartella aperta.
	ids = _tmdb_ids_from_data(data)
	if ids: kodi_refresh_ids(ids, coalesce=False)
	else: kodi_refresh(coalesce=False)

def _refresh_watchlist(data):
	# SOLO per AZIONE: il widget della watchlist del tipo di media toccato, che cambia composizione.
	# In AGGIUNTA il suo elenco di id non contiene ancora il titolo, quindi la regola per id lo
	# scarterebbe proprio mentre va ricostruito.
	#
	# LOTTO 312 -- gli ID non si mandano piu'. Servivano a far ricostruire i widget che GIA' mostrano
	# il titolo, perche' la loro voce di menu passasse da "Aggiungi" a "Rimuovi": all'utente non
	# cambia niente a schermo (l'appartenenza alla watchlist non e' contrassegnata in nessun modo) e
	# in cambio si ricostruivano righe da centinaia di elementi. Misurato il 16/09 alle 01:27:34:
	# aggiungere un film ricostruiva 1101.501 (la watchlist, giusto) e 1101.502 (Horror, inutile).
	# L'AZIONE e' comunque giusta: watchlist_toggle non si fida piu' dell'URL e rilegge l'appartenenza
	# al momento del clic. Dal 18/09 anche l'ETICHETTA, nelle righe di home, hub e ricerca: non e' piu'
	# scritta nell'elemento, la chiede a una proprieta' che il watcher tiene giusta (vedi
	# modules/watchlist_label.py). Fuori da quelle righe resta quella della costruzione.
	# coalesce=False: e' sempre un comando dell'utente. Vedi kodi_refresh in kodi_utils.
	# L'azione e' QUALIFICATA per tipo di media (lotto 119): la watchlist sono due widget e i dati
	# spediti a Trakt dicono gia' quale dei due e' stato toccato -- 'movies' e/o 'shows'. Aggiungere un
	# film non ha motivo di ricostruire la watchlist delle serie.
	actions = set()
	try:
		if data.get('movies'): actions.add(kodi_utils.qualify_action(kodi_utils.WATCHLIST_ACTION, 'movie'))
		if data.get('shows'): actions.add(kodi_utils.qualify_action(kodi_utils.WATCHLIST_ACTION, 'tvshow'))
	except: pass
	# Se i dati non dicono di che tipo sono, si torna al nome nudo: non qualificato vuol dire
	# 'entrambi i widget', cioe' il comportamento di prima. Vedi paginator._action_matches.
	if not actions: actions.add(kodi_utils.WATCHLIST_ACTION)
	kodi_refresh_ids((), tuple(sorted(actions)), coalesce=False)

def add_to_list(user, slug, data):
	result = call_trakt('/users/%s/lists/%s/items' % (user, slug), data=data)
	if result['existing']['movies'] + result['existing']['shows'] > 0: return notification('Already In List', 3000)
	if result['added']['movies'] + result['added']['shows'] == 0: return notification('Error', 3000)
	notification('Success', 3000)
	trakt_sync_activities()
	return result

def remove_from_list(user, slug, data):
	result = call_trakt('/users/%s/lists/%s/items/remove' % (user, slug), data=data)
	if result['deleted']['movies'] + result['deleted']['shows'] == 0: return notification('Error', 3000)
	notification('Success', 3000)
	trakt_sync_activities()
	if path_check('my_lists') or external(): _refresh_for_data(data)
	return result

def add_to_watchlist(data, refresh=True):
	result = call_trakt('/sync/watchlist', data=data)
	if result['existing']['movies'] + result['existing']['shows'] > 0: return notification('Already In List', 3000)
	if result['added']['movies'] + result['added']['shows'] == 0: return notification('Error', 3000)
	notification('Success', 3000)
	trakt_sync_activities()
	# Simmetrico a remove_from_watchlist: prima qui non c'era alcun refresh, quindi togliere un titolo
	# aggiornava subito il widget e aggiungerlo no. refresh=False quando chiama watchlist_toggle, che
	# deve invalidare la cache PRIMA di ricostruire.
	if refresh and (path_check('trakt_watchlist') or external()): _refresh_watchlist(data)
	return result

def remove_from_watchlist(data, refresh=True):
	result = call_trakt('/sync/watchlist/remove', data=data)
	if result['deleted']['movies'] + result['deleted']['shows'] == 0: return notification('Error', 3000)
	notification('Success', 3000)
	trakt_sync_activities()
	if refresh and (path_check('trakt_watchlist') or external()): _refresh_watchlist(data)
	return result

def rinnova_watchlist(media_type):
	"""Rilegge da Trakt la watchlist di questo tipo e sostituisce la copia (lotto 334).

	La chiama chi sa che la watchlist e' cambiata: il clic, "segna come visto" (Trakt toglie i visti dalla
	watchlist) e la sincronizzazione. Le costruzioni la leggono senza rete, quindi la copia deve esserci.
	media_type: 'movie' | 'movies' | 'tvshow' | 'shows'.
	"""
	trakt_fetch_collection_watchlist('watchlist', 'movies' if media_type in ('movie', 'movies') else 'shows', rinnova=True)
	# Dopo la sostituzione, non prima: il watcher rilegge la copia appena vede il segnale, e deve
	# trovare quella nuova. E' cio' che tiene giusta la voce del menu nelle righe che non si
	# ricostruiscono -- vedi modules/watchlist_label.py.
	from modules.watchlist_label import bump
	bump()

def watchlist_tmdb_ids(media_type='movies'):
	# Insieme dei tmdb_id gia' in watchlist, letto una volta sola per costruzione di lista (come
	# watched_info e bookmarks). Passa da cache_trakt_object, quindi e' una lettura da SQLite:
	# nessuna chiamata di rete per elemento.
	try: return {str(i['media_ids']['tmdb']) for i in trakt_fetch_collection_watchlist('watchlist', media_type) if i['media_ids'].get('tmdb')}
	except: return set()

def watchlist_toggle(params):
	# Voce unica del menu contestuale: aggiunge o toglie dalla watchlist a seconda di dov'e' gia'.
	# Sostituisce il gestore liste completo, che chiedeva quale lista prima di fare qualsiasi cosa.
	if not trakt_user_active(): return notification('No Active Trakt Account', 3500)
	media_type = params.get('media_type', 'movie')
	key = 'movies' if media_type == 'movie' else 'shows'
	try: media_id = int(params['tmdb_id'])
	except: return notification('Error', 3000)
	data = {key: [{'ids': {'tmdb': media_id}}]}
	# refresh=False: la ricostruzione la ordina questa funzione, DOPO l'invalidazione della cache.
	# Nell'ordine opposto il widget si ridisegnerebbe leggendo ancora la watchlist vecchia. Finora la
	# rimozione funzionava perche' trakt_sync_activities ripuliva la cache in tempo: una corsa vinta,
	# non una garanzia.
	# L'appartenenza si RILEGGE adesso (lettura da SQLite, nessuna rete): l'URL della voce di menu
	# porta lo stato di quando la riga e' stata costruita, e dal lotto 312 quella riga non viene piu'
	# ricostruita a ogni aggiunta. Se la lettura non riesce si ricade sul valore dell'URL, cioe' sul
	# comportamento di prima.
	dentro = params.get('in_watchlist') == 'true'
	try:
		attuali = watchlist_tmdb_ids(key)
		if attuali: dentro = str(media_id) in attuali
	except: pass
	if dentro: remove_from_watchlist(data, refresh=False)
	else: add_to_watchlist(data, refresh=False)
	rinnova_watchlist(key)
	# Non piu' un kodi_refresh globale (ricostruirebbe TUTTI i widget per una sola etichetta), ma
	# nemmeno l'attesa della prossima ricostruzione naturale: mirato, e quindi immediato.
	_refresh_watchlist(data)

def add_to_collection(data, multi=False):
	result = call_trakt('/sync/collection', data=data)
	if not multi:
		if result['existing']['movies'] + result['existing']['episodes'] > 0: return notification('Already In List', 3000)
		if result['added']['movies'] + result['added']['episodes'] == 0: return notification('Error', 3000)
		notification('Success', 3000)
		trakt_sync_activities()
	return result

def remove_from_collection(data):
	result = call_trakt('/sync/collection/remove', data=data)
	if result['deleted']['movies'] + result['deleted']['episodes'] == 0: return notification('Error', 3000)
	notification('Success', 3000)
	trakt_sync_activities()
	if path_check('trakt_collection') or external(): _refresh_for_data(data)
	return result

def hide_unhide_progress_items(params):
	action, media_type, media_id, list_type = params['action'], params['media_type'], params['media_id'], params['section']
	media_type = 'movies' if media_type in ('movie', 'movies') else 'shows'
	url = 'users/hidden/%s' % list_type if action == 'hide' else 'users/hidden/%s/remove' % list_type
	data = {media_type: [{'ids': {'tmdb': media_id}}]}
	call_trakt(url, data=data)
	trakt_sync_activities()
	# Nascondere o riesporre un titolo nel 'continua a guardare' tocca il widget che lo contiene:
	# l'id ce l'abbiamo gia' nei parametri, non c'e' motivo di ricostruire l'intera home.
	# Con l'azione (lotto 114) il widget si ricostruisce anche quando il titolo RIENTRA, cioe' quando
	# il suo id non e' ancora nell'elenco pubblicato.
	kodi_refresh_ids([media_id], (kodi_utils.CONTINUE_WATCHING_ACTION,), coalesce=False)

def trakt_search_lists(search_title, page_no):
	def _process(dummy_arg):
		return call_trakt('search', params={'type': 'list', 'fields': 'name,description', 'query': search_title, 'limit': 50}, pagination=True, page_no=page_no)
	string = 'trakt_search_lists_%s_%s' % (search_title, page_no)
	return cache_object(_process, string, 'dummy_arg', False, 4)

def trakt_favorites(media_type, dummy_arg):
	def _process(params):
		return [{'media_ids': {'tmdb': i[i['type']]['ids'].get('tmdb', ''), 'imdb': i[i['type']]['ids'].get('imdb', ''), 'tvdb': i[i['type']]['ids'].get('tvdb', '')}} \
					for i in get_trakt(params)]
	media_type = 'movies' if media_type in ('movie', 'movies') else 'shows'
	string = 'trakt_favorites_%s' % media_type
	params = {'path': 'users/me/favorites/%s/%s', 'path_insert': (media_type, 'title'), 'with_auth': True, 'pagination': False}
	return cache_trakt_object(_process, string, params)

def trakt_lists_with_media(media_type, imdb_id):
	def _process(foo):
		data = [i for i in get_trakt(params) if i['item_count'] > 0 and i['ids']['slug'] not in ('', 'None', None) and i['privacy'] == 'public']
		return [remove_keys(i, with_media_removals) for i in data]
	results = []
	results_append = results.append
	template = '[B]%02d. [I]%s - %s likes[/I]'
	media_type = 'movies' if media_type in ('movie', 'movies') else 'shows'
	string = 'trakt_lists_with_media_%s' % imdb_id
	params = {'path': '%s/%s/lists/personal', 'path_insert': (media_type, imdb_id), 'params': {'limit': 100}, 'pagination': False}
	return cache_object(_process, string, 'foo', False, 168)

def get_trakt_list_contents(list_type, user, slug, with_auth):
	def _process(params):
		results = []
		results_append = results.append
		for c, i in enumerate(get_trakt(params)):
			try:
				_type = i['type']
				if _type in ('movie', 'show'): data = {'media_ids': i[_type]['ids'], 'title': i[_type]['title'], 'type': _type, 'order': c}
				elif _type == 'season':
					data = {'tmdb_id': i['show']['ids']['tmdb'], 'season': i[_type]['number'], 'type': _type, 'custom_order': c}
				elif _type == 'episode':
					data = {'media_ids': i['show']['ids'], 'title': i['show']['title'], 'type': _type, 'season': i[_type]['season'], 'episode': i[_type]['number'], 'custom_order': c}
				results_append(data)
			except: pass
		return results
	string = 'trakt_list_contents_%s_%s_%s' % (list_type, user, slug)
	if user == 'Trakt Official': params = {'path': 'lists/%s/items', 'path_insert': slug, 'params': {'extended':'full'}, 'method': 'sort_by_headers'}
	else: params = {'path': 'users/%s/lists/%s/items', 'path_insert': (user, slug), 'params': {'extended':'full'}, 'with_auth': with_auth, 'method': 'sort_by_headers'}
	return cache_trakt_object(_process, string, params)

def trakt_trending_popular_lists(list_type, page_no):
	string = 'trakt_%s_user_lists_%s' % (list_type, page_no)
	params = {'path': 'lists/%s', 'path_insert': list_type, 'params': {'limit': 50}, 'page_no': page_no}
	return cache_object(get_trakt, string, params, False)

def trakt_get_lists(list_type):
	if list_type == 'my_lists':
		string = 'trakt_my_lists'
		path = 'users/me/lists%s'
	elif list_type == 'liked_lists':
		string = 'trakt_liked_lists'
		path = 'users/likes/lists%s'
	params = {'path': path, 'params': {'limit': 1000}, 'pagination': False, 'with_auth': True}
	return cache_trakt_object(get_trakt, string, params)

def get_trakt_list_selection(list_choice=None):
	my_lists = [{'name': item['name'], 'display': '[B]PERSONAL:[/B] [I]%s[/I]' % item['name'].upper(), 'user': item['user']['ids']['slug'], 'slug': item['ids']['slug']} \
																											for item in trakt_get_lists('my_lists')]
	my_lists.sort(key=lambda k: k['name'])
	if list_choice == 'nav_edit':
		liked_lists = [{'name': item['list']['name'], 'display': '[B]LIKED:[/B] [I]%s[/I]' % item['list']['name'].upper(), 'user': item['list']['user']['ids']['slug'],
								'slug': item['list']['ids']['slug']} for item in trakt_get_lists('liked_lists')]
		liked_lists.sort(key=lambda k: (k['display']))
		my_lists.extend(liked_lists)
	else:
		my_lists.insert(0, {'name': 'Collection', 'display': '[B][I]COLLECTION [/I][/B]', 'user': 'Collection', 'slug': 'Collection'})
		my_lists.insert(0, {'name': 'Watchlist', 'display': '[B][I]WATCHLIST [/I][/B]',  'user': 'Watchlist', 'slug': 'Watchlist'})
	list_items = [{'line1': item['display']} for item in my_lists]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Select', 'narrow_window': 'true'}
	selection = select_dialog(my_lists, **kwargs)
	if selection == None: return None
	return selection

def make_new_trakt_list(params):
	list_title = kodi_dialog().input('')
	if not list_title: return
	list_name = kodi_utils.unquote(list_title)
	data = {'name': list_name, 'privacy': 'private', 'allow_comments': False}
	call_trakt('users/me/lists', data=data)
	trakt_sync_activities()
	notification('Success', 3000)
	# Comando esplicito dell'utente: mai accorpato. Vedi kodi_refresh in kodi_utils.
	kodi_refresh(coalesce=False)

def delete_trakt_list(params):
	user = params['user']
	list_slug = params['list_slug']
	if not confirm_dialog(): return
	url = 'users/%s/lists/%s' % (user, list_slug)
	call_trakt(url, is_delete=True)
	trakt_sync_activities()
	notification('Success', 3000)
	# Comando esplicito dell'utente: mai accorpato. Vedi kodi_refresh in kodi_utils.
	kodi_refresh(coalesce=False)

def trakt_add_to_list(params):
	tmdb_id, tvdb_id, imdb_id, media_type = params['tmdb_id'], params['tvdb_id'], params['imdb_id'], params['media_type']
	if media_type == 'movie':
		key, media_key, media_id = ('movies', 'tmdb', int(tmdb_id))
	else:
		key = 'shows'
		media_ids = [(tmdb_id, 'tmdb'), (imdb_id, 'imdb'), (tvdb_id, 'tvdb')]
		media_id, media_key = next(item for item in media_ids if item[0] not in ('None', None, ''))
		if media_id in (tmdb_id, tvdb_id): media_id = int(media_id)
	selected = get_trakt_list_selection()
	if selected is not None:
		data = {key: [{'ids': {media_key: media_id}}]}
		if selected['user'] == 'Watchlist': add_to_watchlist(data)
		elif selected['user'] == 'Collection': add_to_collection(data)
		else:
			user = selected['user']
			slug = selected['slug']
			add_to_list(user, slug, data)

def trakt_remove_from_list(params):
	tmdb_id, tvdb_id, imdb_id, media_type = params['tmdb_id'], params['tvdb_id'], params['imdb_id'], params['media_type']
	if media_type == 'movie':
		key, media_key, media_id = ('movies', 'tmdb', int(tmdb_id))
	else:
		key = 'shows'
		media_ids = [(tmdb_id, 'tmdb'), (imdb_id, 'imdb'), (tvdb_id, 'tvdb')]
		media_id, media_key = next(item for item in media_ids if item[0] not in ('None', None, ''))
		if media_id in (tmdb_id, tvdb_id): media_id = int(media_id)
	selected = get_trakt_list_selection()
	if selected is not None:
		data = {key: [{'ids': {media_key: media_id}}]}
		if selected['user'] == 'Watchlist': remove_from_watchlist(data)
		elif selected['user'] == 'Collection': remove_from_collection(data)
		else:
			user = selected['user']
			slug = selected['slug']
			remove_from_list(user, slug, data)

def trakt_like_a_list(params):
	user = params['user']
	list_slug = params['list_slug']
	refresh = params.get('refresh', 'true') == 'true'
	try:
		call_trakt('/users/%s/lists/%s/like' % (user, list_slug), method='post')
		notification('Success - Trakt List Liked', 3000)
		trakt_sync_activities()
		if refresh: kodi_refresh(coalesce=False)
		return True
	except:
		notification('Error', 3000)
		return False

def trakt_unlike_a_list(params):
	user = params['user']
	list_slug = params['list_slug']
	refresh = params.get('refresh', 'true') == 'true'
	try:
		call_trakt('/users/%s/lists/%s/like' % (user, list_slug), method='delete')
		notification('Success - Trakt List Unliked', 3000)
		trakt_sync_activities()
		if refresh: kodi_refresh(coalesce=False)
		return True
	except:
		notification('Error', 3000)
		return False

def get_trakt_movie_id(item):
	if item['tmdb']: return item['tmdb']
	tmdb_id = None
	api_key = tmdb_api_key()
	if item['imdb']:
		try:
			meta = movie_meta_external_id('imdb_id', item['imdb'], api_key)
			tmdb_id = meta['id']
		except: pass
	return tmdb_id

def get_trakt_tvshow_id(item):
	if item['tmdb']: return item['tmdb']
	tmdb_id = None
	api_key = tmdb_api_key()
	if item['imdb']:
		try: 
			meta = tvshow_meta_external_id('imdb_id', item['imdb'], api_key)
			tmdb_id = meta['id']
		except: tmdb_id = None
	if not tmdb_id:
		if item['tvdb']:
			try: 
				meta = tvshow_meta_external_id('tvdb_id', item['tvdb'], api_key)
				tmdb_id = meta['id']
			except: tmdb_id = None
	return tmdb_id

_SYNC_PAGE_LIMIT = 100   # massimo per pagina consentito da Trakt su questi endpoint
_SYNC_PAGE_CAP = 200     # freno di sicurezza: 20.000 elementi, ben oltre qualsiasi libreria reale

def _get_all_sync_pages(path, with_auth=True):
	# Trakt ha iniziato a paginare gli endpoint sync/watched/*. Chiamandoli con pagination=False si
	# ottiene SOLO la prima pagina, cioe' i 100 titoli piu' recenti: tutto il resto della cronologia
	# spariva dalla cache e i film visti piu' indietro nel tempo perdevano il badge "visto", senza alcuna
	# discriminante visibile. E' la stessa classe di cambiamento che aveva gia' colpito la ripartizione
	# stagioni/episodi di sync/watched/shows.
	#
	# Se l'endpoint NON e' paginato, la prima pagina contiene gia' tutto e page_count vale 1: il ciclo
	# fa una sola richiesta e il comportamento resta identico a prima. La modifica e' quindi sicura in
	# entrambi gli scenari. Se gli header di paginazione mancano del tutto si ripiega sulla chiamata
	# secca storica.
	items, page_no, page_count = [], 1, 1
	while page_no <= page_count and page_no <= _SYNC_PAGE_CAP:
		try: response = call_trakt(path, params={'limit': _SYNC_PAGE_LIMIT}, with_auth=with_auth, pagination=True, page_no=page_no)
		except Exception: response = None
		if not response:
			# Prima pagina fallita: si ripiega sulla chiamata secca storica. Se fallisce anche quella
			# non e' un account senza nulla, e' un GUASTO, e va detto a chi chiama: None, non [].
			# Con `or []` i due casi finivano sullo stesso valore e la guardia del chiamante trattava
			# un account legittimamente vuoto come una risposta sospetta, senza far mai avanzare il
			# segnalibro. Misurato il 30/08 sul profilo Maurizio: dopo la riautorizzazione di Trakt
			# (16:12:24, account senza niente di visto) ogni giro rileggeva 0 elementi, non avanzava,
			# e ordinava un UpdateLibrary globale -- 12 ricostruzioni complete della home in 7 minuti,
			# finite solo quando il primo film visto ha dato al segnalibro qualcosa su cui appoggiarsi.
			if page_no == 1:
				fallback = call_trakt(path, with_auth=with_auth, pagination=False)
				if fallback is None:
					logger('FenLight Trakt', '%s: richiesta FALLITA' % path)
					return None
				return fallback
			break
		page_items, pages = response
		if page_items: items.extend(page_items)
		try: page_count = int(pages)
		except: page_count = page_no
		page_no += 1
	logger('FenLight Trakt', '%s: %s elementi su %s pagine' % (path, len(items), min(page_count, _SYNC_PAGE_CAP)))
	return items

# Quanto resta valido il timbro di "questa modifica e' nostra". Stretto apposta: se scade si
# ricostruisce come prima, quindi il caso peggiore e' il comportamento vecchio, mai un dato perso.
# Finestra entro cui una marcatura fatta da noi puo' RIMANDARE una ricostruzione (non piu' annullarla:
# vedi restore_activity e lotto 58). Poiche' ora il lavoro rimandato viene comunque svolto alla
# scadenza, questa costante non decide piu' "cosa si perde" ma solo "quanto si aspetta": era 120 s,
# cioe' fino a 2 minuti di ritardo per una modifica fatta dall'app Trakt. A 45 s si conserva
# l'accorpamento di piu' marcature consecutive -- il motivo per cui la guardia esiste -- e si dimezza
# abbondantemente l'attesa nel caso peggiore.
TRAKT_SELF_MARK_SECONDS = 45

def self_mark_recent(cache_media_type=None):
	"""Vero se la marcatura appena fatta da NOI e' abbastanza recente. Senza tipo: una qualsiasi.

	IL LOTTO 142 L'AVEVA LASCIATA SENZA CHIAMANTI, IL 143 LE HA DATO UN RUOLO NUOVO -- e opposto.
	Come OROLOGIO serviva a RIMANDARE il lavoro indovinando ("l'ho marcato io da poco, probabilmente
	non c'e' niente da fare"), ed e' stata tolta tre volte perche' quella era la domanda sbagliata.
	Come TESTIMONE serve a dire CHI ha fatto la modifica, e risponde a una domanda che nessun conteggio
	puo' porre: `sync/last_activities` si e' mosso, quindi qualcosa e' cambiato di sicuro; se il conto
	dice "tutto uguale" i due si contraddicono, e sapere se siamo stati noi decide se quel silenzio e'
	credibile. Vedi decide_rebuild_episodi.
	Non decide piu' nulla da sola e non rimanda niente: nel dubbio si verifica, mai si tace.

	Con gli indicatori Trakt, watched_status_mark scrive nello stesso database che le sincronizzazioni
	qui sotto ricostruiscono (indicators_dict: 1 -> trakt_db). Quindi ogni nostra marcatura fa
	scattare l'attivita' remota che ci sveglia, e il rebuild integrale ricalcola un dato che in locale
	e' gia' esatto. Il tipo va confrontato o la guardia di un tipo zittirebbe quella dell'altro.
	"""
	try:
		raw = get_property('fenlight.trakt.self_mark') or ''
		if not raw: return False
		parts = raw.split('|')
		stamp = float(parts[0])
		kind = parts[1] if len(parts) > 1 else ''
		# Timbro vecchio stile (solo l'istante): non sapendo il tipo non si puo' escludere niente.
		# cache_media_type None = "una marcatura qualsiasi", che e' cio' che serve al monitor: li' la
		# domanda non e' quale database ricostruire, ma se c'e' qualcosa di nuovo DA MOSTRARE.
		if cache_media_type and kind and kind != cache_media_type: return False
		return (time.time() - stamp) < TRAKT_SELF_MARK_SECONDS
	except: return False

# -------------------------------------------------------------------------------------------------
# LOTTO 142 -- il numero certo al posto dell'orologio, anche per gli episodi.
#
# `users/me/stats` NON e' paginato, pesa 457 byte e la sua dimensione non dipende da quanto e' grande
# l'account: restituisce direttamente episodes.watched / episodes.plays / movies.watched /
# movies.plays. Misurato il 03/09 sull'account vero: 1279 / 1291 / 598 / 614, cioe' esattamente i
# numeri che il rebuild integrale otteneva scaricando 6 pagine e 121 KB di cronologia.
#
# Il dubbio da sciogliere era se quei valori fossero precalcolati e quindi in RITARDO rispetto a
# sync/last_activities, che e' cio' che ci sveglia: leggerli vecchi significherebbe concludere 'non e'
# cambiato niente' e perdere il dato per sempre, cioe' il guasto del lotto 88. Misurato con un
# rilevatore in sola lettura ogni 2 s, mentre la marcatura veniva fatta a mano da Kodi:
#     58.1s  ATTIVITA ea 18:42:53 -> 19:25:51 | STATS ew 1279 -> 1280, ep 1291 -> 1292
#     96.8s  ATTIVITA ea 19:25:51 -> 19:26:29 | STATS ew 1280 -> 1279, ep 1292 -> 1291
# Nello stesso campione in cui si muove l'attivita', stats e' GIA' aggiornato, in entrambe le
# direzioni, mai indietro. La risoluzione e' 2 s: si puo' affermare che stats non e' in ritardo di
# PIU' di 2 s, non che sia simultaneo -- ma 2 s stanno molto sotto qualunque intervallo di sondaggio.
#
# La riga che conta di piu' e' la seconda: togliendo il 'visto', episodes.watched CALA. Quello e' il
# segnale che dalla cronologia non si puo' ottenere in alcun modo, perche' una rimozione non aggiunge
# un play -- ed e' esattamente cio' che costringeva gli episodi al rebuild integrale.
_STATS_MEMO = [0.0, None]
_STATS_MEMO_SECONDS = 10

def _stats_trakt():
	"""I conteggi ufficiali di Trakt in una richiesta sola. None se non e' disponibile.

	Memo cortissimo perche' film ed episodi vengono valutati nello STESSO giro di
	trakt_sync_activities: senza, la stessa risposta verrebbe chiesta due volte. Il memo viene
	azzerato esplicitamente all'inizio di ogni giro, cosi' due sondaggi ravvicinati non possono
	condividere una lettura vecchia -- il TTL qui sotto e' solo la seconda cintura.
	Un fallimento NON viene memorizzato: si riprova al prossimo giro.
	"""
	_ora = time.time()
	if _STATS_MEMO[1] is not None and (_ora - _STATS_MEMO[0]) < _STATS_MEMO_SECONDS: return _STATS_MEMO[1]
	try:
		_raw = call_trakt('users/me/stats', with_auth=True) or {}
		_ep, _mo = _raw['episodes'], _raw['movies']
		_out = {'episodi_visti': int(_ep['watched']), 'episodi_play': int(_ep['plays']),
				'film_visti': int(_mo['watched']), 'film_play': int(_mo['plays'])}
	except: return None
	_STATS_MEMO[0], _STATS_MEMO[1] = _ora, _out
	return _out

def _azzera_memo_stats():
	_STATS_MEMO[0], _STATS_MEMO[1] = 0.0, None

# La chiave porta la versione, e cambiarla e' il modo di dire "quel che sapevo non vale piu'".
# Col lotto 145 la mappa cambia, quindi cambiano sia le righe locali sia lo scarto: lo scarto
# memorizzato (4 sulla stick) coprirebbe ESATTAMENTE le righe perse dalla mappa vecchia, il conto
# tornerebbe, e non si ricostruirebbe mai -- la tabella resterebbe sbagliata per sempre.
# Con la chiave nuova _conti_noti() torna vuoto, decide_rebuild_episodi dice 'nessun conteggio
# memorizzato', e il primo sondaggio fa un rebuild integrale che riscrive tutto con la mappa giusta.
# _v3 col lotto 149: nella chiave _v2 e' rimasto memorizzato uno scarto di 210 NON spiegato, che
# nasconde 210 episodi di Dragon Ball Z -- con quel valore il conto torna e non si ricostruisce mai
# piu'. Cambiare la chiave e' il modo di dire "quel che sapevo era sbagliato".
_CONTI_KEY = 'fenlight_conti_trakt_v3'
# ATTENZIONE: qui `trakt_cache` e' il MODULO caches.trakt_cache (vedi l'import in testa), non
# l'istanza. Lo store chiave/valore e' `trakt_cache.trakt_cache`, lo stesso che tiene il segnalibro
# delle attivita'. Senza questo alias le due funzioni qui sotto sollevano AttributeError, che il
# try/except inghiotte: _conti_noti tornerebbe sempre {} e si ricostruirebbe a ogni sondaggio.
_kv = trakt_cache.trakt_cache

def _conti_noti():
	try: return _kv.get(_CONTI_KEY) or {}
	except: return {}

def _registra_conti(**campi):
	_d = _conti_noti()
	_d.update(campi)
	try: _kv.set(_CONTI_KEY, _d)
	except: pass

def decide_rebuild_episodi(stats, locali, noti, nostra=False):
	"""Pure. Serve ricostruire gli episodi? Torna (bool, motivo). Nessun orologio, solo numeri.

	Il confronto NON puo' essere `locali == stats['episodi_visti']` come per i film: la nostra
	tabella perde qualche riga per strada (rimappaggio TVDB non iniettivo piu' chiave unica, misurato
	il 03/09: 1275 righe locali contro 1279 su Trakt, tutte e quattro su Hunter x Hunter). Un
	confronto assoluto direbbe 'divergono' a ogni singolo sondaggio, per sempre, e ricostruirebbe
	SEMPRE -- peggio di quello che facciamo oggi.

	Si confronta quindi con lo SCARTO misurato all'ultimo rebuild integrale, che e' l'unico momento in
	cui la tabella locale e' per costruzione la verita' completa. Con lo scarto:
	  - una marcatura NOSTRA muove +1 sia il conto locale sia quello remoto: restano allineati e non
	    si ricostruisce (e' cio' che prima faceva l'orologio self_mark_recent, indovinando);
	  - una rimozione altrove muove SOLO il remoto: i due divergono e si ricostruisce;
	  - una marcatura da un ALTRO dispositivo muove solo il remoto: si prosegue, e a valle e' la via
	    incrementale a occuparsene, non il rebuild.
	Se lo scarto cambia (un anime nuovo che collide), si ricostruisce una volta e lo scarto si
	rimisura da solo: converge sempre, e il caso peggiore e' il comportamento di prima.

	L'ORDINE DEI DUE CONTROLLI NON E' INDIFFERENTE, ed e' costato un rebuild inutile misurato sulla
	stick il 03/09 alle 22:26. Nella prima stesura i `play` venivano guardati PRIMA del conto:

	    22:26:12  marcatura fatta a mano sulla stick (riga gia' scritta in locale)
	    22:26:20  si prosegue, i play sono cambiati (1291 memorizzati, 1292 su Trakt)
	    22:26:23  rebuild completo, motivo: nessun play piu' recente del piu' recente locale
	    22:26:25  titoli cambiati: 0 | azioni: nessuna        <- cinque secondi e sei pagine per niente

	I conti in quel momento coincidevano perfettamente (1276 locali contro 1280 remoti con scarto 4):
	l'insieme degli episodi visti era gia' quello giusto. A far proseguire e' stato il canale dei play,
	che si muove anche quando la modifica e' NOSTRA e gia' applicata -- cioe' il caso piu' frequente in
	assoluto, ed esattamente la malattia che il vecchio orologio curava.

	Quindi: **se i conti coincidono non si ricostruisce, qualunque cosa facciano i play**. Il conto
	risponde alla domanda che conta (l'insieme degli episodi visti e' allineato?); i play distinguono
	solo il PERCHE', e servono a scriverlo nel log.
	Il prezzo, dichiarato: una RIVISIONE fatta altrove muove i play ma non i visti, quindi da qui non
	si aggiorna `last_played`. Non e' un dato perso -- il confine della via incrementale resta piu'
	indietro, e al primo cambiamento vero quella strada trova qualche play in piu' da riscrivere. E'
	l'errore nella direzione sicura: lavoro in piu' domani, mai un badge sbagliato oggi.
	"""
	if stats is None: return (True, 'conteggi Trakt non disponibili')
	if locali is None: return (True, 'conteggio locale non disponibile')
	_scarto, _play_noti = noti.get('episodi_scarto'), noti.get('episodi_play')
	if _scarto is None or _play_noti is None: return (True, 'nessun conteggio memorizzato')
	_atteso = stats['episodi_visti'] - _scarto
	if locali != _atteso:
		return (True, 'il conto NON coincide (%s in locale, attesi %s da %s su Trakt con scarto noto %s)'
					% (locali, _atteso, stats['episodi_visti'], _scarto))
	_come = 'il conto coincide (%s in locale, %s su Trakt, scarto noto %s)' % (locali, stats['episodi_visti'], _scarto)
	# IL CONTO E' UNA SOMMA, E UNA SOMMA PERDE CIO' CHE L'HA COMPOSTA (lotto 143).
	# `+1 -1` e `0` danno lo stesso numero. Se fra due sondaggi un episodio viene marcato e un ALTRO
	# smarcato, il conto non si muove: noi salteremmo, e resteremmo con due badge sbagliati -- e per
	# giunta con il "prossimo episodio" storto su due serie, che e' proprio cio' per cui esiste
	# 'continua a guardare'. Non e' il caso di uno STESSO elemento marcato e poi tolto: quello torna
	# davvero a 'mai visto' e il conto dice il vero.
	#
	# Ma noi qui ci siamo arrivati perche' `sync/last_activities` ha mosso `episodes.watched_at`:
	# QUALCOSA e' cambiato di sicuro. Un conto immobile e un'attivita' che si muove si contraddicono, e
	# la contraddizione e' un indizio -- che finora buttavamo via.
	# Manca solo saper riconoscere il caso in cui la contraddizione e' normale, ed e' il piu' frequente
	# di tutti: la marcatura fatta da NOI su questo dispositivo, gia' scritta in locale, per cui i conti
	# coincidono a ragione. Lo dice il timbro `self_mark`, lasciato in piedi apposta dal lotto 142.
	# Non e' l'orologio tornato: quello RIMANDAVA il lavoro indovinando. Questo e' lo stesso dato usato
	# al contrario, come TESTIMONE DI CHI HA FATTO LA MODIFICA, per decidere se il silenzio del conto
	# e' credibile. Se non siamo stati noi, il silenzio non e' credibile e si guarda davvero.
	if not nostra:
		return (True, '%s, ma la modifica NON e' % _come + "'" + ' nostra: un conto immobile puo'
					+ "'" + ' nascondere due cambiamenti che si compensano -- si verifica')
	if stats['episodi_play'] != _play_noti:
		return (False, '%s e la modifica e' % _come + "'" + ' nostra, gia'
					+ "'" + ' applicata in locale (play %s -> %s)' % (_play_noti, stats['episodi_play']))
	return (False, '%s e nessun play nuovo' % _come)

def scarto_da_memorizzare(misurato, spiegato, tentativi, limite=5):
	"""Quale scarto si memorizza dopo un rebuild, e quanti tentativi si sono usati.

	Lo scarto memorizzato entra in `decide_rebuild_episodi` come `atteso = visti_su_trakt - scarto`.
	Memorizzare uno scarto NON SPIEGATO significa quindi dichiarare "questa differenza e' normale", e
	da quel momento il conto torna e non si ricostruisce piu': la differenza sparisce dalla vista
	invece di essere risolta.

	E' successo davvero, sul Mac il 04/09 alle 03:59. Dragon Ball Z segnato visto su Trakt (291
	episodi), il rebuild ne scrive 81 perche' la cronologia scaricata era incompleta, e i 210 mancanti
	vengono memorizzati come scarto. Da li' in avanti `1570 - 210 = 1360` coincide con le 1360 righe
	locali, e i 210 episodi restano invisibili PER SEMPRE.

	La regola: si memorizza solo cio' che si sa spiegare. Finche' resta un residuo, si tiene lo scarto
	SPIEGATO -- il conto continuera' a non tornare e il giro dopo si ricostruira' ancora, che e'
	esattamente quello che serve quando la causa e' transitoria (Trakt che sta ancora propagando una
	marcatura in blocco, una pagina persa).

	Il limite esiste perche' "si ritenta per sempre" non e' gratis: sul Mi Stick un rebuild costa 3-5
	secondi ogni 30. Dopo `limite` tentativi consecutivi si accetta il valore misurato e lo si dice
	nel log a chiare lettere -- meglio un difetto dichiarato e rumoroso che un ciclo silenzioso.

	Torna `(scarto, tentativi, esito)` con esito in 'spiegato' / 'ritento' / 'rinuncio'.
	"""
	try: tentativi = int(tentativi or 0)
	except: tentativi = 0
	# `spiegato is None` = il chiamante non e' in grado di dirlo (per esempio l'allineamento a vuoto):
	# non e' un residuo, e' un'assenza di informazione, e non deve far scattare nessun tentativo.
	if spiegato is None: return misurato, 0, 'spiegato'
	if spiegato == misurato: return misurato, 0, 'spiegato'
	if tentativi < limite: return spiegato, tentativi + 1, 'ritento'
	return misurato, tentativi, 'rinuncio'

def cronologia_completa(pagine, page_count, limite):
	"""La cronologia scaricata e' la fotografia INTERA, o solo un pezzo?

	`pagine` e' {numero_pagina: elenco} -- `None` o assente significa "quella richiesta e' fallita".

	Il difetto che chiude, misurato sul Mac il 04/09 alle 03:59. Le pagine si scaricano in parallelo
	e si concatenavano alla cieca: `history_extend(get_trakt(params) or [])`. Una pagina che tornava
	vuota per un guasto di rete spariva senza lasciare traccia, e il rebuild proseguiva con una
	cronologia PIU' CORTA -- scrivendo una tabella incompleta e trattandola come completa. Nel log:
	`pagine=7`, quindi su Trakt c'erano almeno 1501 elementi, e ne sono stati assemblati 1373.
	Poi 210 episodi mancanti sono stati memorizzati come "scarto", cioe' benedetti.

	La verifica non costa una richiesta in piu': Trakt impagina a `limite` fisso, quindi TUTTE le
	pagine tranne l'ultima devono avere esattamente `limite` elementi. Una pagina corta o assente si
	riconosce senza sapere quanti elementi ci fossero in totale.

	Torna `(completa, motivo)`. Su `False` il chiamante NON deve scrivere: rimanda, e lascia intatta
	la tabella locale. E' la stessa regola del lotto 88 -- una richiesta fallita non e' una risposta --
	applicata a una risposta PARZIALE, che e' il caso piu' insidioso perche' sembra valida.
	"""
	try: page_count = int(page_count)
	except: return False, 'numero di pagine illeggibile'
	if page_count < 1: return False, 'nessuna pagina'
	mancanti, corte = [], []
	for numero in range(1, page_count + 1):
		elenco = (pagine or {}).get(numero)
		if elenco is None:
			mancanti.append(numero)
			continue
		# L'ultima pagina e' l'unica che puo' essere piu' corta: e' il resto della divisione.
		if numero < page_count and len(elenco) != limite: corte.append((numero, len(elenco)))
	if mancanti: return False, 'pagine mancanti: %s' % mancanti
	if corte: return False, 'pagine corte (attesi %s elementi): %s' % (limite, corte)
	if page_count > 1 and not (pagine or {}).get(page_count): return False, 'ultima pagina vuota'
	return True, 'tutte le %s pagine intere' % page_count

def serve_riallineamento(noti):
	"""Il conto locale degli episodi non e' mai stato verificato con la mappa in uso: si ricostruisce.

	`trakt_indicators_tv` viene chiamata SOLO quando `last_activities` dice che
	`episodes.watched_at` si e' mosso, ed e' giusto: senza attivita' non c'e' niente da
	sincronizzare. Ma quando cambia il RIMAPPAGGIO -- e col lotto 145 e' cambiato -- la tabella
	locale e' sbagliata **senza che su Trakt sia successo niente**, e nessuna attivita' verra' mai a
	dircelo. Misurato sul Mac il 04/09: mappa nuova e corretta in cache, e le righe di Hunter x
	Hunter ancora quelle della mappa vecchia -- stagione 2 numerata `1,2,3,4,17..40,45,67..78,99..136`
	e stagione 3 per niente tradotta, quindi senza badge. La correzione era pronta e aspettava un
	evento scollegato.

	`_conti_noti()` vuoto vuol dire esattamente "non ho memoria di un allineamento fatto con QUESTA
	versione dei conti": la chiave porta la versione, e invalidarla e' il modo di dichiarare che quel
	che sapevamo non vale piu'. La condizione e' la stessa che dentro `decide_rebuild_episodi` porta a
	'nessun conteggio memorizzato', e le due devono restare gemelle: se una dicesse di ricostruire e
	l'altra di no, si tornerebbe ad aspettare.

	Non e' un ciclo: un rebuild riuscito chiama `_registra_conti`, e da li' in poi torna False.
	"""
	if not isinstance(noti, dict): return True
	return noti.get('episodi_scarto') is None or noti.get('episodi_play') is None

def _misura_scarto_episodi(stats, quando, spiegato=None):
	"""Rimisura lo scarto fra il conto locale e quello di Trakt. Va chiamata SOLO dopo un allineamento
	integrale, dove la tabella locale e' per costruzione la verita' completa.

	Fino al lotto 145 lo scarto era un numero misurato e NON spiegato: valeva 4 sulla stick e 0 sul
	Mac, sullo stesso account nello stesso momento, perche' dipendeva dallo stato della mappa in cache
	su ciascun dispositivo. Erano righe che il rimappaggio posizionale faceva collidere sulla chiave
	unica (db_type, media_id, season, episode), dove INSERT OR REPLACE tiene solo l'ultimo.
	Adesso la mappa nasce dalla giuntura per identita' ed e' iniettiva per costruzione, quindi quelle
	collisioni non esistono piu'. Cio' che resta e' dichiarato: gli episodi che su Trakt esistono e da
	noi no (Detective Conan (1,1207..1210), One Piece (15,590) -- 6 su 5962 nel corpus misurato).
	Il parametro `spiegato` porta proprio quel numero, contato dalla mappa: se coincide con lo scarto
	misurato, il conto e' compreso fino in fondo; se non coincide, la differenza e' l'unica cosa che
	non sappiamo, ed e' scritta nel log.

	`stats` e' la lettura fatta all'INIZIO del giro, non una nuova: se nel frattempo qualcosa si e'
	mosso, al prossimo sondaggio i play non combaceranno e si ricostruira' una volta di troppo. E' il
	verso giusto dell'errore -- un rebuild in piu', mai un cambiamento perso.
	"""
	if stats is None: return
	_dopo = trakt_watched_cache.watched_episode_count()
	if _dopo is None: return
	_misurato = stats['episodi_visti'] - _dopo
	_scarto, _tentativi, _esito = scarto_da_memorizzare(_misurato, spiegato, _conti_noti().get('episodi_tentativi'))
	_registra_conti(episodi_play=stats['episodi_play'], episodi_scarto=_scarto, episodi_tentativi=_tentativi)
	# LO SCARTO MISURATO CONTRO QUELLO SPIEGATO (lotto 145). `spiegato` e' il numero di episodi che
	# la mappa ha dichiarato senza corrispondenza -- calcolato PRIMA di scrivere, non dedotto dopo.
	# Si continua a memorizzare quello MISURATO, perche' e' l'unico che garantisce la convergenza del
	# confronto anche se ci fosse ancora una perdita che non conosciamo. Ma se i due divergono, la
	# differenza e' esattamente cio' che non sappiamo spiegare, ed e' il dato che serve alla
	# riparazione mirata: da qui in avanti "il conto non torna" smette di essere ambiguo.
	# UNA riga sola, e dice sempre la stessa cosa: quanto manca e quanto di quel manco sappiamo
	# spiegare. Prima ce n'erano due, e dal lotto 145 si contraddicevano: la seconda chiamava lo
	# scarto "righe perse dal rimappaggio, da correggere", che era vero finche' la mappa era
	# posizionale e non lo e' piu'. Uno scarto spiegato non e' un difetto: sono gli episodi che su
	# Trakt esistono e da noi no, e sono dichiarati.
	try:
		_base = 'watched episodes: scarto locale/Trakt = %s (%s in locale, %s su Trakt) %s' \
				% (_misurato, _dopo, stats['episodi_visti'], quando)
		if _esito == 'spiegato':
			if spiegato: logger('FenLight Trakt', '%s -- tutto spiegato dalla mappa (episodi che Trakt ha e noi no)' % _base)
			else: logger('FenLight Trakt', _base)
		elif _esito == 'ritento':
			logger('FenLight Trakt', '%s -- la mappa ne spiega %s, restano %s SENZA spiegazione: memorizzo %s e riprovo (tentativo %s)'
									% (_base, spiegato, _misurato - spiegato, spiegato, _tentativi))
		else:
			logger('FenLight Trakt', '%s -- la mappa ne spiega %s, restano %s SENZA spiegazione dopo %s tentativi: ACCETTO il valore misurato. Da qui il conto tornera e questi %s episodi non verranno piu cercati.'
									% (_base, spiegato, _misurato - spiegato, _tentativi, _misurato - spiegato))
	except: pass

def _conta_film_su_trakt():
	"""Quanti film Trakt considera visti. Torna None se non si sa: mai zero.

	Dal lotto 142 il numero arriva da `users/me/stats`, che nello stesso giro serve anche agli
	episodi: una richiesta invece di due. Verificato che i due valori coincidono (598 e 598).
	Resta come riserva la sonda storica: `sync/watched/movies` con `limit=1`, dove l'intestazione
	X-Pagination-Page-Count vale esattamente il numero di film visti perche' ogni pagina ne contiene
	uno. Il lato locale, `watched_movie_count()`, e' DERIVATO dai dati, non un contatore tenuto a mano.
	"""
	_s = _stats_trakt()
	if _s is not None: return _s['film_visti']
	try:
		_probe = call_trakt('sync/watched/movies', params={'limit': 1}, with_auth=True, pagination=True, page_no=1)
		return int(_probe[1]) if _probe else None
	except: return None

def trakt_indicators_movies():
	# I film sono stati fino al lotto 107 l'unico percorso senza via incrementale: nessun confronto con
	# la cronologia, solo il rebuild integrale a ogni cambio di attivita'. Nel log della stick del
	# 22/08 alle 23:16:13 sono state scaricate 6 pagine per ottenere '599 da Trakt, 599 in cache,
	# 0 scartati' -- cioe' per non cambiare una riga -- e per giunta mentre la stessa CPU stava
	# costruendo la lista stagioni. Il rebuild resta qui sotto come strada di riserva, e serve ancora:
	# e' l'unica che si accorge delle RIMOZIONI.
	# VIA INCREMENTALE (lotto 107), gemella di quella che le serie hanno gia' in trakt_indicators_tv.
	# La cronologia arriva dal piu' recente al piu' vecchio: tutto cio' che sta sopra il play piu'
	# recente gia' in locale e' esattamente cio' che e' cambiato. Se il confine cade DENTRO la prima
	# pagina, allora tutto il resto lo abbiamo gia', e non c'e' niente da ricostruire.
	# Il guardiano `len(new_plays) < len(history)` non e' un dettaglio: se la prima pagina fosse tutta
	# nuova non sapremmo se la seconda ne contiene altre, e salteremmo dei play. In quel caso si passa
	# dal rebuild come prima.
	# Le RIMOZIONI non compaiono nella cronologia (togliere un film da "visti" non aggiunge un play):
	# quando non c'e' nessun play nuovo si cade sul rebuild completo, che e' l'unico modo di accorgersi
	# di una riga sparita. Il caso peggiore resta quindi il comportamento di prima.
	# Misura che motiva tutto questo: nel log del 29/08 alle 03:25 la sincronizzazione ha scaricato
	# 6 pagine, '599 da Trakt, 599 in cache, 0 scartati', ~10 s di rete, per scoprire UN titolo
	# cambiato -- ed e' il pezzo piu' grosso dei 21 s che separano l'avvio dall'allineamento a Trakt.
	try: _first = call_trakt('sync/history/movies', params={'limit': history_page_limit}, with_auth=True, pagination=True, page_no=1)
	except: _first = None
	if _first:
		_history = list(_first[0] or [])
		_last_synced = trakt_watched_cache.last_watched_movie_date()
		_new_plays = [i for i in _history if i.get('watched_at', '') > _last_synced] if _last_synced else []
		if _new_plays and len(_new_plays) < len(_history):
			_rows = []
			# DAL PIU' VECCHIO AL PIU' RECENTE. La cronologia arriva al contrario, e per i film la
			# chiave della tabella e' (tipo, id, '', ''): due visioni dello stesso film finiscono sulla
			# STESSA riga, e WATCHED_UPSERT e' un INSERT OR REPLACE. Inserendoli nell'ordine di arrivo
			# l'ultimo a vincere sarebbe il piu' VECCHIO, e last_played resterebbe indietro -- cioe'
			# proprio il valore che al giro successivo decide cosa e' nuovo.
			for _item in reversed(_new_plays):
				try:
					_movie = _item['movie']
					_tmdb_id = get_trakt_movie_id(_movie['ids'])
					if not _tmdb_id: continue
					_rows.append(('movie', _tmdb_id, '', '', _item['watched_at'], _movie['title']))
				except: pass
			if _rows:
				# CONTROLLO DI COMPLETEZZA (lotto 108). La cronologia racconta solo cio' che e' stato
				# AGGIUNTO: se nella stessa finestra un film e' stato visto e un altro TOLTO dai visti,
				# i play nuovi ci sono, la via incrementale scatta, e la rimozione non verrebbe notata
				# mai piu' -- il giro dopo le attivita' non cambiano e non si guarda piu' indietro.
				# Il conto remoto lo si ottiene con UNA richiesta da un solo elemento: con limit=1
				# l'intestazione X-Pagination-Page-Count vale esattamente il numero di film visti.
				# Se i due conti non coincidono, o se la richiesta non riesce, si passa dal rebuild:
				# il caso peggiore resta il comportamento di prima, mai un dato sbagliato.
				_remote_count = _conta_film_su_trakt()
				if _remote_count is not None:
					_changed = trakt_watched_cache.add_movie_watched(_rows)
					_local_count = trakt_watched_cache.watched_movie_count()
					if _local_count == _remote_count:
						logger('FenLight Trakt', 'watched movies: %s play nuovi aggiunti, nessun rebuild (via incrementale) | %s visti, coincide con Trakt' % (len(_rows), _local_count))
						return _changed
					logger('FenLight Trakt', 'watched movies: via incrementale INSUFFICIENTE, %s in locale contro %s su Trakt -- si ricostruisce' % (_local_count, _remote_count))
				else:
					logger('FenLight Trakt', 'watched movies: conto remoto non disponibile, si ricostruisce per sicurezza')
		elif _last_synced and not _new_plays:
			# NESSUN PLAY NUOVO. Due situazioni diverse, e fino al lotto 141 le separava un OROLOGIO
			# (`self_mark_recent('movie')`), cioe' la domanda sbagliata -- 'ho marcato di recente?'
			# invece di 'e' gia' applicato in locale?':
			#   - non e' cambiato niente PER NOI. Tipicamente una marcatura NOSTRA: watched_status l'ha
			#     gia' scritta in locale, quindi il play piu' recente in tabella E' la marcatura stessa
			#     e nessun play remoto risulta piu' recente;
			#   - qualcosa e' stato TOLTO dai visti altrove. Le rimozioni non lasciano traccia nella
			#     cronologia -- togliere un film non aggiunge un play -- quindi da qui sono invisibili.
			# Il conto le distingue senza orologi, ed e' esatto in entrambe le direzioni: una marcatura
			# nostra muove di +1 SIA il conto locale SIA quello remoto, quindi restano uguali; una
			# rimozione altrove muove solo quello remoto, e i due divergono.
			# Costo: una richiesta da un elemento invece di sei pagine e ~4 s di rete e CPU sulla stick.
			# Se il conto non e' disponibile si ricostruisce, come prima: mai un dato sbagliato.
			_remote_count = _conta_film_su_trakt()
			_local_count = trakt_watched_cache.watched_movie_count()
			if _remote_count is not None and _local_count == _remote_count:
				logger('FenLight Trakt', 'watched movies: nessun play nuovo e il conto coincide (%s visti): niente da ricostruire' % _local_count)
				return set()
			logger('FenLight Trakt', 'watched movies: nessun play nuovo ma il conto NON coincide (%s in locale contro %s su Trakt): si ricostruisce'
					% (_local_count, _remote_count if _remote_count is not None else '?'))
		try:
			if not _last_synced: _why = 'nessuna cronologia locale'
			elif not _new_plays: _why = 'nessun play piu' + "'" + ' recente del piu' + "'" + ' recente locale (rimozioni?)'
			else: _why = 'prima pagina tutta nuova (%s su %s)' % (len(_new_plays), len(_history))
			logger('FenLight Trakt', 'watched movies: rebuild completo, motivo: %s | ultimo locale=%s' % (_why, _last_synced))
		except: pass
	# Due canali silenziosi facevano sparire il badge "visto" da un sottoinsieme apparentemente casuale
	# di film, senza lasciare traccia nel log: get_trakt_movie_id restituisce None quando l'id TMDb non
	# e' risolvibile (e il film veniva saltato), e pool.submit non rilancia mai le eccezioni sollevate
	# dentro _process (il Future non viene letto). Ora entrambi finiscono in un conteggio loggato.
	dropped = []
	def _process(item):
		try:
			movie = item['movie']
			tmdb_id = get_trakt_movie_id(movie['ids'])
			if not tmdb_id:
				dropped.append('%s ids=%s' % (movie.get('title'), movie.get('ids')))
				return
			insert_append(('movie', tmdb_id, '', '', item['last_watched_at'], movie['title']))
		except Exception as e:
			dropped.append('%s -> %s' % ((item.get('movie') or {}).get('title'), e))
	insert_list = []
	insert_append = insert_list.append
	result = _get_all_sync_pages('sync/watched/movies')
	if result is None:
		# set_bulk_movie_watched esegue DELETE + INSERT: pubblicare una lista vuota azzererebbe l'intera
		# cache dei visti e farebbe sparire TUTTI i badge fino alla sincronizzazione successiva. Un errore
		# di rete arriva qui come None; una risposta 200 con lista vuota e' indistinguibile da "non ho
		# visto nulla", ma su un account gia' popolato e' quasi sempre un guasto: meglio non toccare nulla.
		# Non basta lasciare intatta la cache: va anche RIMANDATO il segnalibro delle attivita'.
		# Senza questa riga (lotto 88) reset_activity ha gia' fatto avanzare il segnalibro all'inizio
		# di trakt_sync_activities, quindi il giro dopo il confronto dice 'nessuna modifica' e il
		# cambiamento non viene piu' richiesto MAI PIU'. Misurato il 25/08: cache dei film visti ferma
		# all'8 agosto mentre Trakt dichiarava un'attivita' del 25, e 17 'No Changes Needed' di fila.
		# Un guasto momentaneo di rete diventava una perdita permanente.
		_SYNC_DEFERRED.add('movies')
		logger('FenLight Trakt', 'watched movies: richiesta FALLITA, cache intatta e segnalibro NON avanzato')
		return
	# Vuoto CERTO (HTTP 200 con zero elementi). Sono due situazioni diverse e la cache locale le separa:
	#  - anche in locale non c'e' niente -> l'account non ha davvero film visti. Allinearsi non perde
	#    nulla e soprattutto fa AVANZARE il segnalibro, unico modo perche' la sincronizzazione converga.
	#    set_bulk su una cache gia' vuota restituisce un insieme vuoto, che il chiamante pubblica come
	#    '-' -> nessuna ricostruzione. E' il caso che il 30/08 ha prodotto 12 UpdateLibrary globali.
	#  - in locale ci sono dei visti -> un vuoto da Trakt e' quasi sempre un guasto (vedi la nota sopra):
	#    non si tocca niente, esattamente come prima. Il confronto e' con 0 e non con la verita' di
	#    watched_movie_count perche' la funzione restituisce None quando il conteggio NON e' disponibile,
	#    e in quel caso l'unica scelta prudente e' non toccare la cache.
	if not result:
		# Vuoto CERTO: la richiesta e' RIUSCITA e Trakt dichiara zero film visti. Da quando i guasti
		# tornano come None (vedi _get_all_sync_pages) questo caso non e' piu' ambiguo e va preso per
		# buono: ci si allinea, e soprattutto il segnalibro AVANZA. Il sospetto di "e' quasi sempre un
		# guasto" nasceva proprio dal fatto che `or []` faceva arrivare qui anche gli errori: tolta
		# quella confusione alla radice, tenere anche la diffidenza qui NON proteggerebbe piu' niente e
		# reintrodurrebbe il ciclo -- un account svuotato non convergerebbe mai, ogni giro tornerebbe
		# 'rebuild completo' con UpdateLibrary globale (30/08: 12 ricostruzioni della home in 7 minuti).
		# Azzerare una cache popolata e' la risposta giusta a una cronologia cancellata su Trakt. Se
		# invece fosse un 200 anomalo il danno e' transitorio e si ripara da solo: la sincronizzazione
		# successiva riscarica l'elenco vero e i badge tornano. La perdita PERMANENTE che la nota del
		# lotto 88 temeva era quella del segnalibro, ed e' il ramo None qui sopra a impedirla.
		logger('FenLight Trakt', 'watched movies: Trakt non ha film visti, cache allineata a vuoto (ne conteneva %s)' % trakt_watched_cache.watched_movie_count())
	make_thread_list(_process, result)
	logger('FenLight Trakt', 'watched movies: %s da Trakt, %s in cache, %s scartati%s'
			% (len(result), len(insert_list), len(dropped), (' -> %s' % dropped[:10]) if dropped else ''))
	return trakt_watched_cache.set_bulk_movie_watched(insert_list)

def trakt_indicators_tv():
	# Trakt no longer returns the seasons/episodes breakdown in sync/watched/shows, so the watched episodes
	# are rebuilt from the play history (250 per page). The newest page is fetched first: when it only holds
	# plays that are newer than what is already stored, those are appended and the rebuild is skipped.
	# GUARDIANO (lotto 142). Prima di toccare la cronologia -- la cui PRIMA pagina da sola pesa 121 KB e
	# quasi un secondo, e il rebuild integrale ne scarica sei -- si chiede a Trakt il numero certo, che
	# costa 457 byte e non cresce con l'account. Se combacia con quello che ci aspettiamo non c'e'
	# NIENTE da scaricare: e' qui che sparisce la proporzionalita' fra il costo del controllo e la
	# dimensione dello storico. La decisione sta in decide_rebuild_episodi, che e' pura e provata.
	_stats = _stats_trakt()
	_locali_prima = trakt_watched_cache.watched_episode_count()
	_ricostruire, _motivo = decide_rebuild_episodi(_stats, _locali_prima, _conti_noti(), self_mark_recent('tvshow'))
	if not _ricostruire:
		# I play si registrano ANCHE quando non si ricostruisce: il conto ci dice che l'insieme dei
		# visti e' gia' allineato, quindi il valore nuovo e' quello buono da cui ripartire. Lo SCARTO
		# invece non si tocca mai qui -- si misura solo dopo un rebuild integrale.
		if _stats is not None: _registra_conti(episodi_play=_stats['episodi_play'])
		# set() vuoto, non None: per declare_change None significa 'non so cosa e' cambiato' e fa
		# scattare un refresh GLOBALE dell'interfaccia, mentre qui sappiamo con certezza che non e'
		# cambiato niente.
		logger('FenLight Trakt', 'watched episodes: %s -- niente da scaricare' % _motivo)
		return set()
	logger('FenLight Trakt', 'watched episodes: si prosegue, %s' % _motivo)
	remap_cache = {}
	def _episode_remap(tmdb_id):
		# looked up once per show, not once per play
		if tmdb_id in remap_cache: return remap_cache[tmdb_id]
		try:
			from modules.metadata import tvshow_meta as _tm
			from modules.settings import mpaa_region as _mr
			_meta = _tm('tmdb_id', tmdb_id, tmdb_api_key(), _mr(), get_datetime())
			# Due cose, non una (lotto 145): la mappa E gli esclusi. Un episodio che su Trakt esiste e
			# da noi no NON ha una riga locale possibile, e prima ne otteneva comunque una per
			# identita' -- che poteva cadere sulla riga di un altro episodio e farlo sparire per via
			# di INSERT OR REPLACE sulla chiave unica.
			remap_cache[tmdb_id] = ((_meta.get('tmdb_to_tvdb_ep') or {}),
									(_meta.get('ep_esclusi_trakt') or set())) if _meta else ({}, set())
		except: remap_cache[tmdb_id] = ({}, set())
		return remap_cache[tmdb_id]
	def _make_row(item, tmdb_id, title, ep_remap):
		# Torna None quando l'episodio non ha corrispondenza da noi: chi chiama DEVE saltare.
		# La cardinalita' di quei salti e' lo scarto -- vedi _misura_scarto_episodi.
		season_no, episode_no = item['episode']['season'], item['episode']['number']
		_coppia = traduci_episodio(ep_remap[0], ep_remap[1], season_no, episode_no)
		if _coppia is None: return None
		return ('episode', tmdb_id, _coppia[0], _coppia[1], item['watched_at'], title)
	def _process_show(item):
		show = item['show']
		trakt_id = show['ids'].get('trakt')
		tmdb_id = get_trakt_tvshow_id(show['ids'])
		if not tmdb_id or not trakt_id: return
		shows_info[trakt_id] = (tmdb_id, show['title'], item.get('reset_at') or None, _episode_remap(tmdb_id))
	# Le pagine si raccolgono PER NUMERO e non si concatenano alla cieca (lotto 149): un elenco
	# concatenato non ricorda piu' quali pezzi lo compongono, quindi una pagina persa e' invisibile.
	pagine_cronologia = {}
	def _get_history_page(page_no):
		params = {'path': 'sync/history/episodes%s', 'params': {'limit': history_page_limit}, 'with_auth': True, 'pagination': True, 'page_no': page_no}
		try: pagine_cronologia[page_no] = get_trakt(params)
		except:
			pagine_cronologia[page_no] = None
			logger('FenLight Trakt', 'watched history page %s FAILED' % page_no)
	try: first_page = call_trakt('sync/history/episodes', params={'limit': history_page_limit}, with_auth=True, pagination=True, page_no=1)
	except: first_page = None
	if not first_page:
		# Vedi la nota gemella in trakt_indicators_movies (lotto 88): senza rimandare il segnalibro,
		# questo guasto momentaneo diventa una perdita permanente. Nel log zb questa riga compare due
		# volte, ed e' li' che gli episodi visti hanno smesso di aggiornarsi.
		_SYNC_DEFERRED.add('episodes')
		return logger('FenLight Trakt', 'watched history request FAILED - episodi intatti, segnalibro NON avanzato')
	history = list(first_page[0] or [])
	pagine_cronologia[1] = history
	try: page_count = int(first_page[1])
	except: page_count = 1
	# Trakt returns the history newest first, so anything above the newest stored play is what changed.
	last_synced = trakt_watched_cache.last_watched_episode_date()
	new_plays = [i for i in history if i.get('watched_at', '') > last_synced] if last_synced else []
	if new_plays and len(new_plays) < len(history):
		insert_list = []
		for item in new_plays:
			try:
				tmdb_id = get_trakt_tvshow_id(item['show']['ids'])
				if not tmdb_id: continue
				_riga = _make_row(item, tmdb_id, item['show']['title'], _episode_remap(tmdb_id))
				if _riga is not None: insert_list.append(_riga)
			except: pass
		if insert_list:
			_changed = trakt_watched_cache.add_tvshow_watched(insert_list)
			# Via incrementale: si aggiornano SOLO i play, mai lo scarto. Lo scarto si rimisura
			# esclusivamente dopo un rebuild integrale (vedi in fondo), perche' e' l'unico momento in
			# cui la tabella locale e' per costruzione completa. Rimisurarlo qui, dove la tabella e'
			# fresca solo per le righe appena scritte, permetterebbe a una rimozione avvenuta nello
			# stesso istante di finire ASSORBITA nello scarto e non essere piu' notata.
			if _stats is not None: _registra_conti(episodi_play=_stats['episodi_play'])
			logger('FenLight Trakt', 'watched episodes sync: %s new plays added, no rebuild needed' % len(insert_list))
			return _changed
	# QUI NON C'E' PIU' L'OROLOGIO self_mark_recent('tvshow'), ed e' il punto del lotto 142.
	# Diceva: 'ho marcato qualcosa da meno di 45 secondi, quindi la modifica e' probabilmente mia ed e'
	# gia' applicata in locale, rimando il rebuild'. Era una SCOMMESSA, resa necessaria dal fatto che
	# per gli episodi non esisteva un numero confrontabile: watched_status_mark scrive nello stesso
	# database che last_watched_episode_date() legge, quindi dopo ogni nostra marcatura new_plays esce
	# vuota e si cadeva sul rebuild integrale -- ogni marcatura si autoinnescava 6 pagine.
	# La scommessa a volte pagava (stick 20:42:36 del 03/09: rimanda, e al giro dopo trova il play
	# dell'altro dispositivo, rebuild evitato) e a volte no (Mac 20:42:53: rimanda per 63 secondi e poi
	# paga comunque il rebuild, che riporta 'titoli cambiati: 0').
	# Adesso la domanda giusta viene posta PRIMA, in cima alla funzione, e ha una risposta certa invece
	# di una probabilita': se il conto combacia non si scarica niente, se non combacia si ricostruisce
	# subito, senza aspettare 45 secondi. Vedi decide_rebuild_episodi.
	# full rebuild: no stored history, plays were removed, or more new plays than a single page holds
	# PERF: il rebuild completo scarica 6 pagine di cronologia e ricostruisce 1274 episodi. Sul Mi
	# Stick costa 2-6 s di rete e CPU, e nel log del 22/08 e' partito a OGNI marcatura mentre la via
	# incrementale e' scattata una volta sola in tutta la sessione. Qui si registra PERCHE' si e'
	# finiti sul rebuild: senza questo dato la causa si puo' solo indovinare, e le tre ipotesi
	# plausibili (nessun play nuovo / play rimossi / prima pagina tutta nuova) portano a correzioni
	# diverse.
	try:
		if not last_synced: _why = 'nessuna cronologia locale'
		elif not new_plays: _why = 'nessun play piu' + "'" + ' recente del piu' + "'" + ' recente locale (rimozioni?)'
		else: _why = 'prima pagina tutta nuova (%s su %s)' % (len(new_plays), len(history))
		logger('FenLight Trakt', 'rebuild completo, motivo: %s | ultimo locale=%s | pagine=%s' % (_why, last_synced, page_count))
	except: pass
	shows_info = {}
	# Anche qui la chiamata era limitata alla prima pagina: oltre le 100 serie, gli episodi di quelle
	# escluse venivano scartati dal filtro shows_info, pur essendo presenti nella cronologia.
	shows = _get_all_sync_pages('sync/watched/shows')
	if shows is None:
		# Prima di questa guardia un guasto su sync/watched/shows cadeva su set_bulk_tvshow_watched([]),
		# cioe' DELETE di tutti gli episodi visti: un errore di rete cancellava la cronologia delle serie.
		# E' la stessa distinzione della gemella sui film, che qui mancava del tutto.
		_SYNC_DEFERRED.add('episodes')
		return logger('FenLight Trakt', 'watched shows: richiesta FALLITA, episodi intatti e segnalibro NON avanzato')
	if not shows:
		# Come per i film: riuscita con zero elementi e' un dato, non un sospetto. Il guasto e' il ramo
		# None qui sopra, che prima non esisteva affatto e lasciava che un errore di rete cadesse qui
		# dentro cancellando l'intera cronologia degli episodi.
		logger('FenLight Trakt', 'watched shows: Trakt non ha serie viste, episodi allineati a vuoto (ne conteneva %s)' % trakt_watched_cache.watched_episode_count())
		_esito = trakt_watched_cache.set_bulk_tvshow_watched([])
		# Anche l'allineamento a vuoto e' un allineamento riuscito: senza rimisurare qui, lo scarto
		# resterebbe quello di una tabella piena e si ricostruirebbe a ogni sondaggio.
		_misura_scarto_episodi(_stats, 'dopo l' + "'" + 'allineamento a vuoto')
		return _esito
	make_thread_list(_process_show, shows)
	if page_count > 1: make_thread_list(_get_history_page, range(2, page_count + 1))
	# UNA CRONOLOGIA PARZIALE NON E' UNA FOTOGRAFIA (lotto 149). Prima di qui si scriveva comunque, e
	# una pagina persa diventava una tabella locale piu' corta -- poi benedetta dallo scarto. Adesso
	# si rimanda: la tabella resta quella di prima, il segnalibro non avanza, e al giro dopo si rifa'.
	_completa, _perche = cronologia_completa(pagine_cronologia, page_count, history_page_limit)
	if not _completa:
		_SYNC_DEFERRED.add('episodes')
		return logger('FenLight Trakt', 'cronologia INCOMPLETA (%s) - episodi intatti, segnalibro NON avanzato' % _perche)
	history = [voce for numero in range(1, page_count + 1) for voce in pagine_cronologia[numero]]
	watched_episodes = {}
	# Gli episodi VISTI su Trakt per cui non esiste una riga locale possibile. E' lo scarto, contato
	# mentre si costruisce invece che dedotto dopo. Insieme, non lista: la cronologia ha piu' play
	# per lo stesso episodio, e uno che manca manca una volta sola.
	_saltati = set()
	for item in history:
		try:
			info = shows_info.get(item['show']['ids'].get('trakt'))
			if not info: continue
			tmdb_id, title, reset_at, ep_remap = info
			watched_at = item['watched_at']
			if reset_at and watched_at < reset_at: continue
			key = (item['episode']['season'], item['episode']['number'], tmdb_id)
			if key in watched_episodes and watched_episodes[key][4] >= watched_at: continue
			_riga = _make_row(item, tmdb_id, title, ep_remap)
			if _riga is None:
				_saltati.add(key)
				continue
			watched_episodes[key] = _riga
		except: pass
	insert_list = list(watched_episodes.values())
	logger('FenLight Trakt', 'watched episodes rebuild: %s shows, %s history plays over %s pages, %s episodes' \
			% (len(shows), len(history), page_count, len(insert_list)))
	_esito = trakt_watched_cache.set_bulk_tvshow_watched(insert_list)
	_misura_scarto_episodi(_stats, 'dopo il rebuild integrale', spiegato=len(_saltati))
	return _esito

def trakt_episode_index(tmdb_id):
	"""Gli episodi di una serie su Trakt come `(stagione, numero, id_tvdb, data)`.

	E' il DIZIONARIO della giuntura del lotto 145, non la sua destinazione. Skyhook conosce solo
	l'id TVDB; dal lato TMDb non esiste una chiamata che dia l'id TVDB di ogni episodio (c'e' solo
	/tv/<id>/season/<n>/episode/<m>/external_ids, cioe' una richiesta PER EPISODIO: 1246 per
	Detective Conan). `seasons?extended=episodes,full` porta invece `ids.tvdb` e `ids.tmdb` sulla
	STESSA riga, in una risposta sola -- 26 KB per Hunter x Hunter.

	Che la numerazione di Trakt sia quella di TMDb non e' un'assunzione: e' stato misurato il 04/09 su
	18 serie e 4747 episodi, zero divergenze, zero episodi Trakt senza id TMDb. Quindi la mappa che
	esce di qui e' insieme TVDB<->Trakt e TVDB<->TMDb.

	Torna None se non si e' potuto sapere -- e None NON e' una lista vuota: chi chiama deve rinunciare
	al rimappaggio, non concludere che la serie non ha episodi. E' la stessa distinzione del lotto 88.

	La chiamata si paga una volta per serie, sul ramo di rete di tvshow_meta: la cache della meta e'
	la sua cache.
	"""
	try:
		trovate = call_trakt('search/tmdb/%s' % tmdb_id, params={'type': 'show'}, with_auth=False)
		if not trovate: return None
		slug = trovate[0]['show']['ids'].get('slug') or trovate[0]['show']['ids'].get('trakt')
		if not slug: return None
		stagioni = call_trakt('shows/%s/seasons' % slug, params={'extended': 'episodes,full'}, with_auth=False)
		if not stagioni: return None
		fuori = []
		for stagione in stagioni:
			for episodio in stagione.get('episodes') or ():
				fuori.append((stagione.get('number'), episodio.get('number'),
								(episodio.get('ids') or {}).get('tvdb'), episodio.get('first_aired')))
		return fuori or None
	except: return None

def chiave_voce_playback(item):
	"""L'identita' della COSA in pausa, non della voce di playback. None se non si sa dirla.

	E' la stessa chiave con cui la tabella `progress` e' unica -- (media_id, stagione, episodio) --
	ma detta nei numeri di Trakt, che sono gli unici disponibili qui senza toccare la rete. Per gli
	episodi NON si usa il rimappaggio TMDb<->TVDB: serve `tvshow_meta`, e questa funzione gira a ogni
	poll da 30 s. Due voci con lo stesso id di serie, stagione e numero sono lo stesso episodio in
	qualunque numerazione, e questo basta per il lavoro che deve fare.
	"""
	try:
		if item['type'] == 'movie': return ('movie', item['movie']['ids']['trakt'])
		return ('episode', item['show']['ids']['trakt'], item['episode']['season'], item['episode']['number'])
	except: return None

def _quando_in_pausa(item):
	# Ordinamento lessicografico su un ISO8601 in Z: e' cronologico senza dover convertire niente.
	try: return item.get('paused_at') or ''
	except: return ''

def dedup_playback(progress_info):
	"""Una voce per chiave, come la tabella. Torna (snapshot, quante voci scartate).

	LOTTO 238 -- IL DIFETTO 9.2 DI TRAKT.md, LA RUOTA DA 30 SECONDI. `progress_out_of_sync` chiede
	"lo snapshot ha un resume_id che noi non abbiamo?" e la riparazione, `set_bulk_*_progress`,
	scrive UNA riga per chiave. Due alfabeti diversi: quando Trakt tiene due voci per lo stesso film
	-- e le tiene, e' il difetto 9.1 che le crea a ogni chiusura sotto soglia -- la tabella puo'
	contenerne una sola, l'altra risulta "in piu' su Trakt" e la riparazione non potra' MAI toglierla.

	Misurato sulla stick il 10/09: 21 giri in 28 minuti, uno ogni 30 s, dalle 21:53 alle 22:21 senza
	interruzione, 16 dei quali con un `refresh MIRATO su 0 titoli` dietro. Ogni giro accende un
	interprete Python nuovo (`reuselanguageinvoker` e' false e deve restarlo): 928 ms di orologio,
	538 di cpu, di cui 465 solo per diventare Python. Mezzo secondo di cpu ogni trenta, riproduzione
	compresa.

	LA REGOLA GENERALE, che vale oltre questo caso: un rilevatore di differenze puo' segnalare solo
	differenze che la sua stessa riparazione sa togliere. Se le due cose parlano alfabeti diversi il
	ciclo non e' un rischio, e' una certezza. Qui si allinea l'alfabeto alla sorgente, cosi' TUTTI i
	consumatori dello snapshot -- il confronto, la ricostruzione, gli id per il ridisegno -- vedono
	la stessa cosa. Ripararlo nel solo confronto avrebbe zittito il sintomo lasciando la
	ricostruzione a scegliere a caso quale gemello scrivere.

	QUALE DEI DUE VINCE, e perche' deve essere deciso e non casuale. Prima di questo lotto la scelta
	la faceva l'ordine di arrivo dei thread dentro `trakt_progress_movies`: la tabella finiva con l'uno
	o con l'altro a caso, e il giro dopo il confronto si lamentava dell'altro. Vince la voce messa in
	pausa PIU' TARDI, che e' anche la risposta giusta per l'utente -- e' l'ultimo punto in cui ha
	davvero smesso di guardare; a parita' di istante, l'id piu' alto, cioe' il record allocato dopo.

	Una voce di cui non si sa dire la chiave si TIENE. Nel dubbio si preferisce una riga in piu' da
	riconciliare a una pausa dell'utente buttata via qui dentro (regola 9 di TRAKT.md §8).
	"""
	if not progress_info: return progress_info, 0
	migliori, senza_chiave, ordine = {}, [], []
	for item in progress_info:
		_k = chiave_voce_playback(item)
		if _k is None:
			senza_chiave.append(item)
			continue
		_vecchio = migliori.get(_k)
		if _vecchio is None:
			migliori[_k] = item
			ordine.append(_k)
		elif (_quando_in_pausa(item), item.get('id') or 0) > (_quando_in_pausa(_vecchio), _vecchio.get('id') or 0):
			migliori[_k] = item
	_fuori = [migliori[_k] for _k in ordine] + senza_chiave
	return _fuori, len(progress_info) - len(_fuori)

# LOTTO 239 -- LO STESSO DIFETTO DI FORMA DI §9.2, SU UN SECONDO ASSE, e questa volta l'ha trovato
# la riga di log che il 238 aveva aggiunto: `film [1 in piu' su Trakt [1844144333]]`, ogni 30 s,
# sempre lo stesso id, con ZERO voci gemelle accorpate. Non erano i doppioni.
#
# Il ricostruttore tiene solo le voci sopra l'1% (`progress_items`, sotto): una pausa a meta' del
# primo minuto non e' un 'continua a guardare', e non deve comparire. Il confronto invece contava
# TUTTE le voci dello snapshot. Una voce sotto l'1% risultava quindi "in piu' su Trakt" per sempre,
# perche' la ricostruzione non la scrivera' mai -- per scelta, non per errore.
# La prova sta nel log: `DIAG progress movie: da Trakt 4 | in locale 4 (4 synced)` mentre il
# confronto ne vedeva 5.
#
# LA REGOLA E' LA STESSA DEL 238, e vale la pena scriverla una volta sola: un rilevatore di
# differenze puo' segnalare solo differenze che la sua riparazione sa togliere. Qui non si ripete la
# soglia in due posti sperando che restino uguali -- si usa la STESSA funzione da entrambe le parti,
# cosi' l'invariante non e' una convenzione ma una conseguenza.
PROGRESSO_MINIMO = 1

def voci_da_tenere(progress_info, tipo):
	"""Le voci dello snapshot che la ricostruzione terrebbe davvero. L'unica definizione.

	Una voce senza `progress` leggibile vale zero e resta fuori da entrambe le parti: non potrebbe
	essere scritta in tabella, quindi non deve nemmeno poter far dichiarare una differenza.
	"""
	try:
		return [i for i in (progress_info or []) if i.get('type') == tipo
					and (i.get('progress') or 0) > PROGRESSO_MINIMO]
	except: return []

def trakt_playback_progress():
	params = {'path': 'sync/playback%s', 'with_auth': True, 'pagination': False}
	_snapshot = get_trakt(params)
	# `None` non e' una lista vuota (regola 3 di TRAKT.md §8): "non lo so" deve restare distinguibile
	# da "non c'e' niente in pausa" fino in fondo alla catena, perche' a valle decide se ricostruire.
	if _snapshot is None: return None
	_snapshot, _doppi = dedup_playback(_snapshot)
	# Questa riga e' la spia del difetto 9.1 sul campo: finche' compare, Trakt sta accumulando voci
	# gemelle e la causa e' a monte, nella doppia scrittura a fine riproduzione.
	if _doppi:
		logger('FenLight Trakt', 'snapshot di avanzamento: %s voci gemelle accorpate (una per chiave)' % _doppi)
	return _snapshot

def trakt_comments(media_type, imdb_id):
	def _process(foo):
		data = get_trakt(params)
		for count, item in enumerate(data, 1):
			try:
				rating = '%s/10 - ' % item['user_rating'] if item['user_rating'] else ''
				comment = template % \
				(count, rating, item['user']['username'].upper(), js2date(item['created_at'], date_format, True).strftime('%d %B %Y'), replace_html_codes(item['comment']))
				if item['spoiler']: comment = spoiler_template + comment
				all_comments_append(comment)
			except: pass
		return all_comments
	all_comments = []
	all_comments_append = all_comments.append
	template, spoiler_template, date_format = '[B]%02d. [I]%s%s - %s[/I][/B][CR][CR]%s', '[B][COLOR red][CONTAINS SPOILERS][/COLOR][CR][/B]', '%Y-%m-%dT%H:%M:%S.000Z'
	media_type = 'movies' if media_type in ('movie', 'movies') else 'shows'
	string = 'trakt_comments_%s %s' % (media_type, imdb_id)
	params = {'path': '%s/%s/comments', 'path_insert': (media_type, imdb_id), 'params': {'limit': 1000, 'sort': 'likes'}, 'pagination': False}
	return cache_object(_process, string, 'foo', False, 168)

def trakt_progress_movies(progress_info):
	def _process(item):
		tmdb_id = get_trakt_movie_id(item['movie']['ids'])
		if not tmdb_id: return
		obj = ('movie', str(tmdb_id), '', '', str(round(item['progress'], 1)), 0, item['paused_at'], item['id'], item['movie']['title'])
		insert_append(obj)
	insert_list = []
	insert_append = insert_list.append
	progress_items = voci_da_tenere(progress_info, 'movie')
	# Torna QUALI film hanno cambiato avanzamento, per la ricarica mirata (lotto 119). Anche il caso
	# 'nessun film in corso' e' un cambiamento da mostrare -- e' l'ultimo film che ESCE da 'continua a
	# guardare' -- quindi passa dallo stesso calcolo invece di uscire a mani vuote.
	if not progress_items: return trakt_watched_cache.set_bulk_movie_progress([])
	threads = list(make_thread_list(_process, progress_items))
	[i.join() for i in threads]
	return trakt_watched_cache.set_bulk_movie_progress(insert_list)

def trakt_progress_tv(progress_info):
	def _process_show(show):
		tmdb_id = get_trakt_tvshow_id(show['ids'])
		if not tmdb_id: return
		try:
			from modules.metadata import tvshow_meta as _tm
			from modules.settings import mpaa_region as _mr
			_meta = _tm('tmdb_id', tmdb_id, tmdb_api_key(), _mr(), get_datetime())
			_ep_remap = ((_meta.get('tmdb_to_tvdb_ep') or {}),
							(_meta.get('ep_esclusi_trakt') or set())) if _meta else ({}, set())
		except: _ep_remap = ({}, set())
		shows_info[show['ids'].get('trakt')] = (tmdb_id, _ep_remap)
	def _process():
		for p_item in progress_items:
			try:
				# matched on the trakt id: two different shows can share the same title
				info = shows_info.get(p_item['show']['ids'].get('trakt'))
				if not info: continue
				tmdb_id, ep_remap = info
				season, ep_num = p_item['episode']['season'], p_item['episode']['number']
				_coppia = traduci_episodio(ep_remap[0], ep_remap[1], season, ep_num)
				if _coppia is None: continue
				tvdb_s, tvdb_e = _coppia
				if tvdb_s > 0: yield ('episode', str(tmdb_id), tvdb_s, tvdb_e, str(round(p_item['progress'], 1)),
									0, p_item['paused_at'], p_item['id'], p_item['show']['title'])
			except: pass
	shows_info = {}
	progress_items = voci_da_tenere(progress_info, 'episode')
	# Gemella di trakt_progress_movies: torna le triple 'tmdb:stagione:episodio' cambiate, non i soli
	# id di serie. Vedi kodi_utils.episode_uid per il perche' della tripla.
	if not progress_items: return trakt_watched_cache.set_bulk_tvshow_progress([])
	all_shows = {i['show']['ids'].get('trakt'): i['show'] for i in progress_items}
	make_thread_list(_process_show, list(all_shows.values()))
	return trakt_watched_cache.set_bulk_tvshow_progress(list(_process()))

OFFICIAL_STATUS_PROP = 'fenlight.trakt.official_status.%s'

def trakt_official_status(media_type):
	"""script.trakt sta gia' facendo lui lo scrobble di questo tipo di media?

	LA RISPOSTA E' MEMORIZZATA, e non e' un'ottimizzazione opportunistica (lotto 125). Misurato sulla
	stick il 02/09 alle 14:22: questa funzione da sola e' costata 2347 ms dei 2380 della scrittura
	dello stato locale -- la INSERT ne ha presi 1. Il motivo non e' il lavoro che fa, e' QUANDO lo fa:
	addon_installed e addon_enabled sono due getCondVisibility, cioe' chiedono il lock della GUI, e
	set_bookmark gira alla chiusura del player, mentre il thread grafico smonta il decoder, rinegozia
	l'HDMI e ricostruisce la finestra. Il costo e' contesa, non calcolo.
	E' una domanda di CONFIGURAZIONE: quale addon e' installato, abilitato, autorizzato e con quali
	preferenze di scrobble. Non cambia durante una riproduzione, quindi non ha nessun motivo di
	essere posta nell'unico istante in cui costa. Il valore lo semina il servizio a intervalli
	tranquilli (vedi service.refresh_official_status); qui resta il calcolo diretto come ripiego per
	la primissima chiamata, se il servizio non ha ancora girato.
	La conseguenza da tenere presente: cambiando le impostazioni di script.trakt il valore vecchio
	resta valido finche' il servizio non rigira. E' un ciclo del TraktMonitor, non una sessione.
	"""
	key = 'movie' if media_type in ('movie', 'movies') else 'episode'
	cached = kodi_utils.get_property(OFFICIAL_STATUS_PROP % key)
	if cached: return cached == 'true'
	return compute_official_status(media_type, store=True)

def compute_official_status(media_type, store=False):
	result = _compute_official_status(media_type)
	if store:
		key = 'movie' if media_type in ('movie', 'movies') else 'episode'
		try: kodi_utils.set_property(OFFICIAL_STATUS_PROP % key, 'true' if result else 'false')
		except: pass
	return result

def _compute_official_status(media_type):
	if not addon_installed('script.trakt'): return True
	if not addon_enabled('script.trakt'): return True
	trakt_addon = addon('script.trakt')
	try: authorization = trakt_addon.getSetting('authorization')
	except: authorization = ''
	if authorization == '': return True
	try: exclude_http = trakt_addon.getSetting('ExcludeHTTP')
	except: exclude_http = ''
	if exclude_http in ('true', ''): return True
	media_setting = 'scrobble_movie' if media_type in ('movie', 'movies') else 'scrobble_episode'
	try: scrobble = trakt_addon.getSetting(media_setting)
	except: scrobble = ''
	if scrobble in ('false', ''): return True
	return False

def trakt_get_my_calendar(recently_aired, current_date):
	def _process(dummy):
		data = get_trakt(params)
		data = [{'sort_title': '%s s%s e%s' % (i['show']['title'], str(i['episode']['season']).zfill(2), str(i['episode']['number']).zfill(2)),
				'media_ids': i['show']['ids'], 'season': i['episode']['season'], 'episode': i['episode']['number'], 'first_aired': i['first_aired']} \
									for i in data if i['episode']['season'] > 0]
		data = [i for n, i in enumerate(data) if i not in data[n + 1:]] # remove duplicates
		return data
	start, finish = trakt_calendar_days(recently_aired, current_date)
	string = 'trakt_get_my_calendar_%s_%s' % (start, finish)
	params = {'path': 'calendars/my/shows/%s/%s', 'path_insert': (start, finish), 'with_auth': True, 'pagination': False}
	return cache_trakt_object(_process, string, params)

def trakt_calendar_days(recently_aired, current_date):
	if recently_aired: start, finish = (current_date - timedelta(days=14)).strftime('%Y-%m-%d'), '14'
	else:
		previous_days = int(get_setting('fenlight.trakt.calendar_previous_days', '0'))
		future_days = int(get_setting('fenlight.trakt.calendar_future_days', '7'))
		start = (current_date - timedelta(days=previous_days)).strftime('%Y-%m-%d')
		finish = str(previous_days + future_days)
	return start, finish

def make_trakt_slug(name):
	import re
	name = name.strip()
	name = name.lower()
	name = re.sub('[^a-z0-9_]', '-', name)
	name = re.sub('--+', '-', name)
	return name

def trakt_get_activity():
	params = {'path': 'sync/last_activities%s', 'with_auth': True, 'pagination': False}
	return get_trakt(params)

def get_trakt(params):
	result = call_trakt(params['path'] % params.get('path_insert', ''), params=params.get('params', {}), data=params.get('data'), is_delete=params.get('is_delete', False),
						with_auth=params.get('with_auth', False), method=params.get('method'), pagination=params.get('pagination', True), page_no=params.get('page_no'))
	return result[0] if params.get('pagination', True) else result

def _publish_changed(changed_ids, changed_actions, changed_unknown):
	"""Pubblica COSA e' cambiato, perche' il monitor ricarichi i soli contenitori interessati.

	Due proprieta', due criteri diversi, e vanno lette insieme (service.TraktMonitor):

	  fenlight.trakt.changed_ids      ''  = non lo sappiamo          -> ricostruzione globale
	                                  '-' = lo sappiamo, nessun id   -> nessun id da colpire
	                                  ... = le identita' cambiate    -> mirato per contenuto
	  fenlight.trakt.changed_actions  ''  = nessuna azione
	                                  ... = i widget che cambiano COMPOSIZIONE

	Il '-' e' un'AFFERMAZIONE, non un'assenza, ed e' esattamente qui che il lotto 59 sbagliava: lo
	pubblicava anche quando i rami che avevano lavorato non alimentavano changed_ids -- l'avanzamento,
	la watchlist -- cioe' dichiarava 'non e' cambiato niente' per un cambiamento vero. Il monitor gli
	credeva e non ricostruiva nulla. Ora ogni ramo vivo alimenta almeno uno dei due canali, e
	changed_unknown resta l'unico modo di dire 'non lo so'.

	Le identita' possono contenere ':' (livello episodio, kodi_utils.episode_uid): la separazione e'
	sulla virgola e le due cose non si confondono.
	"""
	try:
		_ids = '' if changed_unknown else (','.join(sorted(str(i) for i in changed_ids if i)) or '-')
		_actions = ','.join(sorted(str(a) for a in changed_actions if a))
		kodi_utils.set_property('fenlight.trakt.changed_ids', _ids)
		kodi_utils.set_property('fenlight.trakt.changed_actions', _actions)
		if changed_unknown:
			logger('FenLight Trakt', 'cambiamento di natura ignota: si ricostruisce tutto')
		else:
			logger('FenLight Trakt', 'titoli cambiati: %d%s | azioni: %s'
					% (len(changed_ids), (' -> %s' % sorted(changed_ids)[:10]) if changed_ids else '',
						_actions or 'nessuna'))
	except: pass

# Quante riparazioni remote per giro. Il tetto esiste perche' un guasto prolungato di rete puo'
# accumularne parecchie, e ripartire con una raffica di chiamate sarebbe il modo peggiore di
# rientrare: si smaltiscono poche per volta, e quello che resta torna al giro dopo.
REMOTE_REPAIRS_PER_CYCLE = 5

def _drain_remote_repairs():
	"""Ripete le chiamate a Trakt che la riconciliazione ha scoperto mancanti (lotto 133).

	Due code, due guasti diversi, entrambi silenziosi fino a ieri:
	  PENDING_REMOTE_DELETES  l'utente ha azzerato l'avanzamento, la DELETE remota non e' passata e
	                          Trakt elenca ancora il segnalibro. Senza questa ripetizione la riga
	                          resterebbe `pending_delete` per sempre e Trakt non lo saprebbe mai.
	  PENDING_REMOTE_PUSHES   l'utente ha messo in pausa, la spinta non e' mai stata confermata
	                          (rete assente, token, eccezione ingoiata). La riga resta visibile in
	                          locale -- non si cancella la pausa di qualcuno per un guasto di rete --
	                          e va rispinta finche' non passa.
	"""
	deletes = [trakt_cache.PENDING_REMOTE_DELETES.pop(0) for _ in range(min(len(trakt_cache.PENDING_REMOTE_DELETES), REMOTE_REPAIRS_PER_CYCLE))]
	pushes = [trakt_cache.PENDING_REMOTE_PUSHES.pop(0) for _ in range(min(len(trakt_cache.PENDING_REMOTE_PUSHES), REMOTE_REPAIRS_PER_CYCLE))]
	if not deletes and not pushes: return
	from threading import Thread
	from caches.base_cache import connect_database
	def _work():
		for db_type, key, resume_id in deletes:
			try:
				trakt_progress('clear_progress', db_type, key[0], 0, key[1], key[2], resume_id)
				logger('Fen Light', 'cancellazione remota ripetuta per %s %s' % (db_type, key[0]))
			except Exception as e: logger('Fen Light', 'cancellazione remota di %s FALLITA di nuovo: %s' % (key[0], e))
		for db_type, key in pushes:
			try:
				row = connect_database('trakt_db').execute(
					'SELECT resume_point FROM progress WHERE db_type = ? AND media_id = ? AND season = ? AND episode = ?',
					(db_type, key[0], key[1], key[2])).fetchone()
				if not row: continue
				resume_id = trakt_progress('set_progress', db_type, key[0], float(row[0]), key[1], key[2]) or 0
				if resume_id:
					connect_database('trakt_db').execute(
						'UPDATE progress SET resume_id = ? WHERE db_type = ? AND media_id = ? AND season = ? AND episode = ?',
						(resume_id, db_type, key[0], key[1], key[2]))
					logger('Fen Light', 'spinta ripetuta e confermata per %s %s' % (db_type, key[0]))
			except Exception as e: logger('Fen Light', 'spinta ripetuta di %s FALLITA: %s' % (key[0], e))
	Thread(target=_work).start()

def declare_change(ids, rimandato):
	"""Cosa dichiarare dopo un costruttore di indicatori. Torna (azione, ids, ignoto).

	Pura, e separata proprio perche' la stessa decisione era scritta due volte -- film ed episodi --
	e sbagliata in entrambe (lotto 141). Tre esiti, non due:

	  ids = None, RIMANDATO   non e' stato applicato niente e il segnalibro torna indietro: si tace.
	                          Il giro dopo si rifa' e allora si dichiarera' cio' che e' cambiato.
	  ids = None, non rimandato  fallito e basta: lo stato locale e' incerto, il globale e' l'unica rete.
	  ids = insieme VUOTO     il lavoro e' stato fatto e non e' cambiato nulla: niente da ridisegnare.
	  ids = insieme pieno     si dichiarano azione e id.

	Prima, `None` finiva sempre su 'ricostruisci tutto' e l'azione si dichiarava comunque: una
	ricostruzione globale per un lavoro che non era stato fatto. `None` puo' voler dire una cosa sola
	-- niente applicato -- perche' tutti i ritorni anticipati dei costruttori escono PRIMA della
	scrittura, e la scrittura vera e' in transazione (trakt_cache._atomic), quindi non lascia mai
	stati parziali.
	"""
	if ids is None: return (not rimandato, frozenset(), not rimandato)
	if not ids: return (False, frozenset(), False)
	return (True, ids, False)

def activity_rollback(latest, cached, categorie):
	"""Il segnalibro da riscrivere quando una parte del giro e' stata rimandata.

	Solo le categorie rimandate tornano al valore VECCHIO; le altre restano al valore nuovo, cosi' il
	lavoro riuscito in questo giro non si rifa'. Prima si rimetteva indietro il blocco INTERO, quindi
	un rinvio sui film buttava anche watchlist ed episodi gia' allineati.

	'all' torna SEMPRE indietro: e' il cancello d'ingresso di trakt_sync_activities, e senza rimettere
	indietro anche quello il giro successivo non entrerebbe nemmeno a guardare le categorie.
	"""
	indietro = dict(latest)
	indietro['all'] = cached.get('all', latest.get('all'))
	for cat in categorie:
		if cat in cached: indietro[cat] = cached[cat]
	return indietro

def trakt_sync_activities(force_update=False):
	# def clear_watched_tvshow_cache():
	# 	from modules.watched_status import clear_cache_watched_tvshow_status
	# 	clear_cache_watched_tvshow_status(watched_indicators=1)
	def clear_properties(media_type):
		for item in ((True, True), (True, False), (False, True), (False, False)): clear_property('1_%s_%s_%s_watched' % (media_type, item[0], item[1]))
	def _get_timestamp(date_time):
		return int(time.mktime(date_time.timetuple()))
	def _compare(latest, cached):
		try: result = _get_timestamp(js2date(latest, res_format)) > _get_timestamp(js2date(cached, res_format))
		except: result = True
		return result
	def _check_daily_expiry():
		return int(time.time()) >= int(get_setting('fenlight.trakt.next_daily_clear', '0'))
	# Il memo di users/me/stats vale UN giro solo: film ed episodi lo condividono, ma due sondaggi
	# ravvicinati non devono mai riusare la stessa lettura, o una modifica avvenuta fra i due
	# risulterebbe invisibile. Azzerarlo qui rende il TTL nel memo una semplice seconda cintura.
	_azzera_memo_stats()
	if force_update: clear_all_trakt_cache_data(silent=True, refresh=False)
	elif _check_daily_expiry():
		clear_daily_cache()
		set_setting('trakt.next_daily_clear', str(int(time.time()) + (24*3600)))
	if not trakt_user_active() and not force_update: return 'no account'
	# LE RIPARAZIONI REMOTE SI SMALTISCONO QUI, ALL'INIZIO, e la posizione e' il punto (lotto 140).
	# Stavano in fondo, dopo tutto il lavoro, e da li' erano IRRAGGIUNGIBILI sul percorso tranquillo:
	# il ramo 'niente e' cambiato su Trakt' esce con `return` molto prima -- ed e' proprio il ramo in
	# cui la riconciliazione gira per le cancellazioni, cioe' quello che le riparazioni le PRODUCE.
	# Conseguenza misurabile su un account tranquillo: una spinta mai confermata (hai messo in pausa,
	# la chiamata a Trakt e' fallita) restava in coda finche' non capitava un cambiamento NON
	# CORRELATO. Un'azione dell'utente persa in silenzio, che e' la categoria che continuiamo a colpire.
	# All'inizio invece ci passa ogni giro, qualunque strada prenda poi. Il prezzo e' che una
	# riparazione nata in questo giro parte al prossimo, cioe' entro l'intervallo di poll: per una
	# ripetizione di rete e' irrilevante, e in cambio non dipende piu' da quale ramo l'ha prodotta.
	# Se le due code sono vuote la chiamata torna subito, quindi sul giro normale non costa nulla.
	_drain_remote_repairs()
	try: latest = trakt_get_activity()
	except: return 'failed'
	if not latest: return 'failed'
	cached = reset_activity(latest)
	# reset_activity fa avanzare il segnalibro "visto fino a qui" QUI, prima che il lavoro sia fatto.
	# Se una guardia self_mark salta poi una ricostruzione, il cambiamento risulta gia' visto e non
	# torna mai piu': il giro dopo il confronto da 'not needed', per sempre. Misurato il 24/08 (log q1,
	# 14:24:40 e 14:25:16): due 'success', cioe' due cambiamenti veri arrivati da Trakt, entrambi
	# consumati e persi. Il flag viene azzerato qui e riletto in fondo. Vedi lotto 58.
	_SYNC_DEFERRED.clear()
	# IL RIALLINEAMENTO SI DECIDE QUI, PRIMA DEL CANCELLO (lotto 145 quater). La prima stesura del
	# 145 ter metteva questa domanda solo accanto al confronto su episodes.watched_at, cioe' DENTRO
	# il ramo -- e su un account tranquillo a quel ramo non ci si arriva mai, perche' il cancello qui
	# sotto esce con 'not needed' molto prima. Misurato sul Mac: otto minuti dopo il riavvio, zero
	# righe 'FenLight Trakt' nel log e i conti ancora sulla chiave vecchia. La correzione era
	# installata e continuava a non partire, per la seconda volta di fila e per un motivo diverso.
	# La lezione, che e' la stessa del 145 ter: verificare che una correzione sia giusta non basta,
	# bisogna verificare che il codice che la applica venga ESEGUITO.
	_riallinea_episodi = serve_riallineamento(_conti_noti())
	if not _compare(latest['all'], cached['all']) and not _riallinea_episodi:
		# IL CANCELLO E' VOLUTO, e con la domanda ora simmetrica va motivato. Senza righe di
		# avanzamento in locale l'unica cosa che potrebbe sfuggirci e' un'AGGIUNTA fatta altrove -- ma
		# un'aggiunta muove `paused_at`, quindi non finisce qui dentro: la prende il ramo normale. Il
		# residuo e' una finestra sotto il secondo fra la lettura dello snapshot e la memorizzazione
		# della marca. In cambio, chi non ha nessun avanzamento non paga una richiesta ogni 30 s.
		if trakt_watched_cache.has_any_progress():
			progress_info = trakt_playback_progress()
			if progress_info is not None:
				# LOTTO 239 -- gli STESSI insiemi che vedra' la ricostruzione, non tutto lo snapshot.
				movie_ids = {i['id'] for i in voci_da_tenere(progress_info, 'movie')}
				ep_ids = {i['id'] for i in voci_da_tenere(progress_info, 'episode')}
				# Simmetrica dal lotto 140: non piu' 'Trakt ha tolto qualcosa?' ma 'lo snapshot e noi
				# diciamo cose diverse?'. Lo snapshot lo scarichiamo intero comunque, quindi l'altra
				# meta' dell'informazione era gia' in mano. Vedi trakt_cache.progress_out_of_sync.
				movie_differs = trakt_watched_cache.progress_out_of_sync('movie', movie_ids)
				ep_differs = trakt_watched_cache.progress_out_of_sync('episode', ep_ids)
				if movie_differs or ep_differs:
					logger('FenLight Trakt', 'avanzamento fuori sincrono senza cambio di attivita\': film [%s] | episodi [%s]'
							% (movie_differs or '-', ep_differs or '-'))
				changed_ids, changed_unknown = set(), False
				if movie_differs:
					clear_properties('movie')
					_ids = trakt_progress_movies(progress_info)
					if _ids is None: changed_unknown = True
					else: changed_ids |= _ids
				if ep_differs:
					clear_properties('episode')
					_ids = trakt_progress_tv(progress_info)
					if _ids is None: changed_unknown = True
					else: changed_ids |= _ids
				if movie_differs or ep_differs:
					# Un titolo USCITO dall'avanzamento cambia la composizione di 'continua a guardare':
					# l'id da solo non basta, perche' il widget lo mostra ancora e la regola per id lo
					# troverebbe -- ma solo finche' non e' stato ricostruito da qualcun altro. L'azione
					# lo copre in entrambe le direzioni. Vedi kodi_utils.CONTINUE_WATCHING_ACTION.
					_publish_changed(changed_ids, {kodi_utils.CONTINUE_WATCHING_ACTION}, changed_unknown)
					return 'success'
		return 'not needed'
	refresh_movies_progress, refresh_shows_progress = False, False
	cached_movies, latest_movies = cached['movies'], latest['movies']
	cached_shows, latest_shows = cached['shows'], latest['shows']
	cached_episodes, latest_episodes = cached['episodes'], latest['episodes']
	# LOTTO 119 -- STRUMENTI MORTI RIMOSSI. Qui c'erano sei confronti in piu': 'recommendations',
	# 'favorites', 'collected_at' (film e serie) e le liste 'updated_at'/'liked_at'. Sono funzioni che
	# questa installazione non usa: nessun widget le mostra e nessuna schermata legge quelle cache,
	# quindi non c'era niente da invalidare e tanto meno da ricostruire. Sei _compare in meno a ogni
	# poll da 30 s, e -- soprattutto -- sei rami in meno capaci di dichiarare 'e' cambiato qualcosa'
	# senza saper dire cosa, che e' il modo in cui un refresh mirato degenera in globale.
	# Restano i tre eventi che governano widget veri: visto, avanzamento, watchlist.
	# Raccolta di cosa e' cambiato, per il refresh mirato. Due canali distinti e non intercambiabili:
	#  - changed_ids: CHI e' cambiato. Colpisce i widget che gia' lo contengono.
	#  - changed_actions: QUALE widget cambia composizione. Colpisce il widget per quello che E',
	#    ed e' l'unico criterio che funziona quando il titolo non e' ANCORA nella lista (un film che
	#    entra in 'continua a guardare', un titolo aggiunto alla watchlist da un altro dispositivo).
	# `None` da una ricostruzione significa "non so quali", e allora si ricade sul refresh globale:
	# e' diverso da un insieme vuoto, che significa "nessun titolo e' cambiato davvero".
	changed_ids, changed_actions, changed_unknown = set(), set(), False
	# NASCONDI/RIESPONI una serie dal 'continua a guardare'. Spostato qui sotto perche' anche questo
	# ramo deve DICHIARARE cosa ha toccato: prima invalidava la cache e usciva muto, quindi se era
	# l'unico cambiamento del giro il payload finiva a '-' e il widget non si ricostruiva mai --
	# lo stesso difetto dell'avanzamento, sullo stesso widget. Solo l'azione e nessun id: nascondere
	# TOGLIE la serie dalla lista e riesporla ce la rimette, e in nessuno dei due casi l'id da solo
	# risponde alla domanda giusta. Trakt non dice QUALE serie e' stata nascosta.
	if _compare(latest_shows['hidden_at'], cached_shows['hidden_at']):
		clear_properties('episode')
		clear_trakt_hidden_data('progress_watched')
		changed_actions.add(kodi_utils.CONTINUE_WATCHING_ACTION)
	if _compare(latest_movies['watched_at'], cached_movies['watched_at']):
		clear_properties('movie')
		# L'AZIONE ACCOMPAGNA GLI ID (lotto 134). Segnare un film come visto lo fa USCIRE da 'continua
		# a guardare': e' un cambiamento di COMPOSIZIONE, e la regola per id da sola non lo copre --
		# per la stessa ragione, parola per parola, gia' scritta in watched_status.refresh_container_for
		# e nel ramo dell'avanzamento qui sotto. Il percorso LOCALE l'azione la mandava da sempre;
		# questo, che e' il percorso di cio' che arriva DA UN ALTRO DISPOSITIVO, no.
		# NON SI DICHIARA LAVORO CHE NON E' STATO FATTO (lotto 141). `None` da un costruttore vuol
		# dire una cosa sola -- non e' stato applicato NIENTE -- perche' tutti i suoi ritorni anticipati
		# escono PRIMA della scrittura e la scrittura vera e' in transazione, quindi non lascia stati
		# parziali. Prima quel None diventava `changed_unknown`, cioe' 'ricostruisci tutto', per un
		# lavoro che non c'era stato: niente da mostrare e una ricostruzione globale per mostrarlo.
		#   - RIMANDATO (il segnalibro torna indietro): si tace. Il giro dopo si rifa' e allora si
		#     dichiarera' cio' che e' cambiato davvero.
		#   - fallito SENZA rinvio: resta `changed_unknown`, perche' li' lo stato locale e' incerto e
		#     il globale e' l'unica rete.
		# Un insieme VUOTO e' un'altra cosa ancora: il lavoro e' stato fatto e non e' cambiato nulla.
		# Anche li' non c'e' niente da ridisegnare, quindi non si dichiara nessuna azione.
		_azione, _nuovi, _ignoto = declare_change(trakt_indicators_movies(), 'movies' in _SYNC_DEFERRED)
		if _azione: changed_actions.add(kodi_utils.CONTINUE_WATCHING_ACTION)
		changed_ids |= _nuovi
		changed_unknown = changed_unknown or _ignoto
	# L'OR NON E' UNA SCORCIATOIA (lotto 145 ter). Senza, una correzione del rimappaggio resta in
	# attesa di un'attivita' su Trakt che non ha nessun motivo di arrivare. Vedi serve_riallineamento.
	# La stessa bandiera apre ANCHE il cancello su latest['all'], piu' sopra: le due condizioni vanno
	# tenute insieme, perche' aprirne una sola lascia la correzione irraggiungibile -- ed e'
	# esattamente l'errore del 145 ter. Lo sorveglia tests/test_145ter.py, caso E.
	if _compare(latest_episodes['watched_at'], cached_episodes['watched_at']) or _riallinea_episodi:
		clear_properties('episode')
		# QUI IL BUCO ERA PIU' GRAVE CHE PER I FILM (lotto 134). Segnare visto un episodio fa entrare
		# in 'continua a guardare' l'episodio SUCCESSIVO, che e' un elemento DIVERSO da quello
		# marcato: il suo id non e' fra i cambiati e non e' ancora nell'elenco pubblicato dal widget,
		# quindi nessuna regola per id puo' trovarlo. Serve l'azione, e mancava.
		# Misurato il 03/09 alle 04:53: episodio segnato visto sulla stick, dove il percorso locale
		# manda l'azione e il prossimo episodio compare subito. Sul Mac arriva da qui --
		# 'titoli cambiati: 1 -> [330320] | azioni: nessuna' -- e il prossimo episodio non e' mai
		# entrato in 'continua a guardare'.
		# Livello SERIE, ed e' voluto: un episodio VISTO fa avanzare la serie, quindi si aggiornano i
		# widget che contengono la serie -- badge, prossimo episodio, 'continua a guardare' (che
		# pubblica anche il tmdb nudo di ogni episodio, vedi paginator._publish_ids).
		# NON SI DICHIARA LAVORO CHE NON E' STATO FATTO (lotto 141). `None` da un costruttore vuol
		# dire una cosa sola -- non e' stato applicato NIENTE -- perche' tutti i suoi ritorni anticipati
		# escono PRIMA della scrittura e la scrittura vera e' in transazione, quindi non lascia stati
		# parziali. Prima quel None diventava `changed_unknown`, cioe' 'ricostruisci tutto', per un
		# lavoro che non c'era stato: niente da mostrare e una ricostruzione globale per mostrarlo.
		#   - RIMANDATO (il segnalibro torna indietro): si tace. Il giro dopo si rifa' e allora si
		#     dichiarera' cio' che e' cambiato davvero.
		#   - fallito SENZA rinvio: resta `changed_unknown`, perche' li' lo stato locale e' incerto e
		#     il globale e' l'unica rete.
		# Un insieme VUOTO e' un'altra cosa ancora: il lavoro e' stato fatto e non e' cambiato nulla.
		# Anche li' non c'e' niente da ridisegnare, quindi non si dichiara nessuna azione.
		_azione, _nuovi, _ignoto = declare_change(trakt_indicators_tv(), 'episodes' in _SYNC_DEFERRED)
		if _azione: changed_actions.add(kodi_utils.CONTINUE_WATCHING_ACTION)
		changed_ids |= _nuovi
		changed_unknown = changed_unknown or _ignoto
	# La WATCHLIST sono DUE widget, non uno: quello dei film e quello delle serie, costruiti dalla
	# stessa azione 'trakt_watchlist' da due classi diverse. Trakt li distingue gia' con due
	# timestamp separati, e fin qui la distinzione si perdeva: aggiungere un film da un altro
	# dispositivo ricostruiva anche la watchlist delle serie. Qui ognuno colpisce il proprio.
	# Solo l'AZIONE, e nessun id: l'evento e' 'la lista e' cambiata', e il titolo entrato non e'
	# ancora nell'elenco pubblicato dal widget -- la regola per id lo scarterebbe.
	if _compare(latest_movies['watchlisted_at'], cached_movies['watchlisted_at']):
		rinnova_watchlist('movie')
		changed_actions.add(kodi_utils.qualify_action(kodi_utils.WATCHLIST_ACTION, 'movie'))
	if _compare(latest_shows['watchlisted_at'], cached_shows['watchlisted_at']):
		rinnova_watchlist('tvshow')
		changed_actions.add(kodi_utils.qualify_action(kodi_utils.WATCHLIST_ACTION, 'tvshow'))
	if _compare(latest_movies['paused_at'], cached_movies['paused_at']): refresh_movies_progress = True
	if _compare(latest_episodes['paused_at'], cached_episodes['paused_at']): refresh_shows_progress = True
	progress_info = None
	if not (refresh_movies_progress and refresh_shows_progress):
		progress_info = trakt_playback_progress()
		if progress_info is not None:
			# Stessa domanda simmetrica del ramo tranquillo: la marca `paused_at` dice se qualcosa e'
			# cambiato, il contenuto dice se e' cambiato QUALCOSA CHE NOI NON ABBIAMO. La seconda non
			# dipende dalla prima, ed e' per questo che una marca mancata o ambigua non fa piu' danno.
			if not refresh_movies_progress:
				trakt_ids = {i['id'] for i in voci_da_tenere(progress_info, 'movie')}   # lotto 239
				_perche = trakt_watched_cache.progress_out_of_sync('movie', trakt_ids)
				if _perche:
					refresh_movies_progress = True
					logger('FenLight Trakt', 'avanzamento film fuori sincrono: %s' % _perche)
			if not refresh_shows_progress:
				trakt_ids = {i['id'] for i in voci_da_tenere(progress_info, 'episode')}   # lotto 239
				_perche = trakt_watched_cache.progress_out_of_sync('episode', trakt_ids)
				if _perche:
					refresh_shows_progress = True
					logger('FenLight Trakt', 'avanzamento episodi fuori sincrono: %s' % _perche)
	if refresh_movies_progress or refresh_shows_progress:
		if progress_info is None: progress_info = trakt_playback_progress()
		# L'AVANZAMENTO era il buco: questi due rami ricostruivano la tabella progress e non
		# dichiaravano NIENTE, quindi il payload usciva '-' -- 'lo sappiamo, non e' cambiato nulla' --
		# ed era falso. Un film lasciato a meta' su un altro dispositivo arrivava nel database della
		# stick e non compariva mai a schermo (log del 01/09, 20:04:45). Ora i due costruttori tornano
		# le identita' che hanno davvero cambiato avanzamento, calcolate sul prima/dopo della tabella.
		# L'azione accompagna sempre gli id, perche' 'continua a guardare' cambia COMPOSIZIONE:
		# in aggiunta il titolo non e' ancora nella lista, in rimozione l'elenco e' quello di prima.
		changed_actions.add(kodi_utils.CONTINUE_WATCHING_ACTION)
		if refresh_movies_progress:
			clear_properties('movie')
			# Identita' di livello FILM: il tmdb nudo.
			_ids = trakt_progress_movies(progress_info)
			if _ids is None: changed_unknown = True
			else: changed_ids |= _ids
		if refresh_shows_progress:
			clear_properties('episode')
			# Identita' di livello EPISODIO ('tmdb:stagione:episodio'): un episodio in pausa non e' la
			# sua serie, e non deve ricostruire ogni widget che contenga quella serie.
			_ids = trakt_progress_tv(progress_info)
			if _ids is None: changed_unknown = True
			else: changed_ids |= _ids
	# Qualcosa e' stato rimandato: il segnalibro torna indietro, cosi' il prossimo giro riprende il
	# lavoro invece di trovare 'nessuna modifica'. La guardia self_mark diventa cosi' un RINVIO e non
	# piu' un cestino: al massimo ritarda di una finestra self_mark, non perde piu' niente.
	if _SYNC_DEFERRED:
		# SOLO le categorie rimandate, piu' 'all' che e' il cancello d'ingresso: senza rimettere
		# indietro anche quello il giro successivo non entrerebbe nemmeno. Le altre categorie restano
		# al valore NUOVO, quindi il lavoro riuscito in questo giro non si rifa'.
		_indietro = activity_rollback(latest, cached, _SYNC_DEFERRED)
		logger('FenLight Trakt', 'segnalibro attivita\' riportato indietro per: %s' % ', '.join(sorted(_SYNC_DEFERRED)))
		_SYNC_DEFERRED.clear()
		restore_activity(_indietro)
	_publish_changed(changed_ids, changed_actions, changed_unknown)
	return 'success'
